import { c as createLucideIcon, G as aidoAgentFaqs, H as clawdTrustThresholdUsd, J as predictionMarketFeeRate, p as predictionMarketTreasuryAddress, K as solanaPaymentAddress, L as officialTokenName, M as officialTokenAddress, N as websiteUrl, O as featuredTools, P as pricingPlans, Q as heroStats, R as aidoAgentAccessAreas, T as contactItems, U as getAgentMemory, V as saveAgentMemory, r as reactExports, j as jsxRuntimeExports, C as Card, a as CardHeader, B as Badge, b as CardTitle, z as CardDescription, e as CardContent, W as Wallet, D as formatWalletAddress, d as Button, X as Clock3, A as Separator } from "./index-C-7_nSR2.js";
import { T as Textarea } from "./textarea-6tc707H_.js";
import { S as Sparkles } from "./sparkles-CaH_qrgu.js";
import { S as Send } from "./send-DmexI6YH.js";
const __iconNode$2 = [
  ["path", { d: "M12 8V4H8", key: "hb8ula" }],
  ["rect", { width: "16", height: "12", x: "4", y: "8", rx: "2", key: "enze0r" }],
  ["path", { d: "M2 14h2", key: "vft8re" }],
  ["path", { d: "M20 14h2", key: "4cs60a" }],
  ["path", { d: "M15 13v2", key: "1xurst" }],
  ["path", { d: "M9 13v2", key: "rq6x2g" }]
];
const Bot = createLucideIcon("bot", __iconNode$2);
const __iconNode$1 = [
  ["path", { d: "M12 18V5", key: "adv99a" }],
  ["path", { d: "M15 13a4.17 4.17 0 0 1-3-4 4.17 4.17 0 0 1-3 4", key: "1e3is1" }],
  ["path", { d: "M17.598 6.5A3 3 0 1 0 12 5a3 3 0 1 0-5.598 1.5", key: "1gqd8o" }],
  ["path", { d: "M17.997 5.125a4 4 0 0 1 2.526 5.77", key: "iwvgf7" }],
  ["path", { d: "M18 18a4 4 0 0 0 2-7.464", key: "efp6ie" }],
  ["path", { d: "M19.967 17.483A4 4 0 1 1 12 18a4 4 0 1 1-7.967-.517", key: "1gq6am" }],
  ["path", { d: "M6 18a4 4 0 0 1-2-7.464", key: "k1g0md" }],
  ["path", { d: "M6.003 5.125a4 4 0 0 0-2.526 5.77", key: "q97ue3" }]
];
const Brain = createLucideIcon("brain", __iconNode$1);
const __iconNode = [
  [
    "path",
    {
      d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
      key: "18887p"
    }
  ],
  ["path", { d: "M14 13a2 2 0 0 0 2-2V9h-2", key: "zjz9hw" }],
  ["path", { d: "M8 13a2 2 0 0 0 2-2V9H8", key: "14e02x" }]
];
const MessageSquareQuote = createLucideIcon("message-square-quote", __iconNode);
const cyrDogeStorageKey = "octopus-market-aido-agent-history-v7";
const cyrDogeQuickPrompts = [
  "What is Octopus Market (OM)?",
  "How does wallet validation work before a launch or prediction action?",
  "What is the official token of the platform?",
  "Guide me through Launch Token, Prediction Market, and List My AI"
];
const aidoAgentStarterFaqs = aidoAgentFaqs.slice(0, 10);
function createWelcomeMessage() {
  return {
    id: "welcome-message",
    role: "assistant",
    language: "en",
    createdAt: Date.now(),
    content: "Hi, I’m Aido Agent. I’m the Octopus Market assistant, and I start in standard English by default. I can answer platform questions, explain Launch Token, Prediction Market, and AI listing flows, share official platform details, and guide users through wallet-validated actions. Connect your wallet to unlock the full utility layer, then ask a question or use one of the FAQ starters below."
  };
}
function readStoredCyrDogeMessages() {
  if (typeof window === "undefined") {
    return null;
  }
  try {
    const rawValue = window.localStorage.getItem(cyrDogeStorageKey);
    if (!rawValue) {
      return null;
    }
    const parsedValue = JSON.parse(rawValue);
    if (!Array.isArray(parsedValue) || parsedValue.length === 0) {
      return null;
    }
    return parsedValue;
  } catch (e) {
    return null;
  }
}
function detectChatLanguage(text) {
  const normalizedText = text.trim().toLowerCase();
  if (!normalizedText) {
    return "en";
  }
  const frenchSignals = [
    "bonjour",
    "salut",
    "je",
    "tu",
    "vous",
    "mon",
    "site",
    "prix",
    "gratuit",
    "marché",
    "plateforme",
    "lancement",
    "paiement",
    "français",
    "visibilité",
    "produit",
    "comment",
    "pourquoi",
    "avec",
    "est",
    "des",
    "les",
    "une",
    "que",
    "quoi",
    "peux",
    "faire",
    "besoin",
    "objectif",
    "projet",
    "aide",
    "compare",
    "écris",
    "résume",
    "explique"
  ];
  const englishSignals = [
    "hello",
    "hi",
    "my",
    "product",
    "pricing",
    "listing",
    "launch",
    "visibility",
    "growth",
    "market",
    "wallet",
    "english",
    "website",
    "help",
    "how",
    "what",
    "why",
    "free",
    "token",
    "compare",
    "positioning",
    "audience",
    "write",
    "summarize",
    "explain",
    "project",
    "goal"
  ];
  const frenchScore = frenchSignals.filter((signal) => normalizedText.includes(signal)).length;
  const englishScore = englishSignals.filter((signal) => normalizedText.includes(signal)).length;
  if (frenchScore > englishScore) {
    return "fr";
  }
  return "en";
}
const annualPlan$1 = pricingPlans.find((plan) => plan.name.toLowerCase().includes("annual"));
const monthlyPlan$1 = pricingPlans.find((plan) => plan.name.toLowerCase().includes("monthly"));
const launchFlowStat = heroStats.find((stat) => stat.label.toLowerCase().includes("launch flows"));
const twitterReference = contactItems.find((item) => {
  var _a;
  return (_a = item.href) == null ? void 0 : _a.includes("x.com");
});
const toolCatalog = featuredTools.map((tool) => ({
  name: tool.name,
  normalizedName: tool.name.toLowerCase(),
  description: tool.description,
  price: tool.price,
  users: tool.users,
  verificationLabel: tool.verificationLabel
}));
function normalizeText(value) {
  return value.toLowerCase().trim();
}
function normalizeQuestionMatch(value) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}
function includesAny$1(text, keywords) {
  return keywords.some((keyword) => text.includes(keyword));
}
function getRecentUserMessages(history) {
  return history.filter((message) => message.role === "user").slice(-4).map((message) => message.content.trim()).filter(Boolean);
}
function detectMentionedTools(text, history) {
  const corpus = [text, ...getRecentUserMessages(history)].join(" ").toLowerCase();
  return toolCatalog.filter((tool) => {
    const simplified = tool.normalizedName.replace(/[^a-z0-9]+/g, " ");
    const shortTokens = simplified.split(" ").filter((token) => token.length > 3);
    return corpus.includes(tool.normalizedName) || shortTokens.some((token) => corpus.includes(token)) || tool.name === "Claude 3.5 Sonnet" && corpus.includes("claude");
  }).map((tool) => tool.name);
}
function detectProductKind(text, history) {
  const corpus = [text, ...getRecentUserMessages(history)].join(" ").toLowerCase();
  if (includesAny$1(corpus, ["agent", "assistant", "chatbot", "copilot", "support bot"])) {
    return "agent";
  }
  if (includesAny$1(corpus, ["image", "visual", "photo", "art", "design"])) {
    return "image";
  }
  if (includesAny$1(corpus, ["trading", "finance", "signal", "market", "portfolio"])) {
    return "finance";
  }
  if (includesAny$1(corpus, ["code", "developer", "dev", "software", "app", "saas"])) {
    return "code";
  }
  if (includesAny$1(corpus, ["token", "launch", "mint", "bags fm", "bags.fm", "solfair", "tokenization"])) {
    return "token";
  }
  return "general";
}
function detectTopics(text, history) {
  const currentText = normalizeText(text);
  const recentContext = getRecentUserMessages(history).join(" ").toLowerCase();
  const corpus = `${currentText} ${recentContext}`;
  const topics = /* @__PURE__ */ new Set();
  if (!currentText) {
    topics.add("general");
  }
  if (includesAny$1(currentText, ["hello", "hi", "hey", "bonjour", "salut", "yo"])) {
    topics.add("greeting");
  }
  if (includesAny$1(corpus, [
    "visibility",
    "audience",
    "grow",
    "growth",
    "discover",
    "traffic",
    "users",
    "visibilité",
    "croissance",
    "impact",
    "conversion",
    "engagement"
  ])) {
    topics.add("visibility");
  }
  if (includesAny$1(corpus, ["price", "pricing", "cost", "plan", "monthly", "annual", "free", "prix", "tarif"])) {
    topics.add("pricing");
  }
  if (includesAny$1(corpus, ["listing", "wallet", "payment", "signature", "payer", "paiement", "solana"])) {
    topics.add("listing");
  }
  if (includesAny$1(corpus, ["launch", "token", "mint", "solfair", "whitepaper", "bags.fm", "bags fm", "tokenization", "launch token"])) {
    topics.add("launch");
  }
  if (includesAny$1(corpus, ["prediction", "binary", "yes", "no", "escrow", "claim", "market resolution"])) {
    topics.add("prediction");
  }
  if (includesAny$1(corpus, ["clawdtrust", "prediction", "rug", "gold badge", "badge gold", "trust"])) {
    topics.add("clawdtrust");
  }
  if (includesAny$1(corpus, ["compare", "versus", "vs", "difference", "better", "comparer", "différence"])) {
    topics.add("comparison");
  }
  if (includesAny$1(corpus, ["position", "positioning", "message", "pitch", "describe", "headline", "angle", "promesse"])) {
    topics.add("positioning");
  }
  if (includesAny$1(corpus, ["agent", "assistant", "chatbot", "copilot"])) {
    topics.add("agent");
  }
  if (topics.size === 0) {
    topics.add("general");
  }
  return Array.from(topics);
}
function detectTaskTypes(text, history) {
  const corpus = [text, ...getRecentUserMessages(history)].join(" ").toLowerCase();
  const taskTypes = /* @__PURE__ */ new Set();
  if (includesAny$1(corpus, ["write", "rewrite", "rédige", "écris", "copy", "headline", "bio", "pitch"])) {
    taskTypes.add("write");
  }
  if (includesAny$1(corpus, ["summarize", "résume", "summary", "recap", "récap"])) {
    taskTypes.add("summarize");
  }
  if (includesAny$1(corpus, ["explain", "explique", "what is", "what does", "pourquoi", "comment"])) {
    taskTypes.add("explain");
  }
  if (includesAny$1(corpus, ["brainstorm", "idea", "idée", "angles", "concept", "naming"])) {
    taskTypes.add("brainstorm");
  }
  if (includesAny$1(corpus, ["analyze", "analyse", "audit", "review", "stats", "performance"])) {
    taskTypes.add("analyze");
  }
  if (includesAny$1(corpus, ["plan", "roadmap", "steps", "checklist", "étapes", "planifie"])) {
    taskTypes.add("plan");
  }
  if (includesAny$1(corpus, ["compare", "versus", "vs", "difference", "comparer", "différence"])) {
    taskTypes.add("compare");
  }
  if (taskTypes.size === 0) {
    taskTypes.add("general");
  }
  return Array.from(taskTypes);
}
function buildProfile(input, history, context) {
  var _a;
  const detectedLanguage = detectChatLanguage(input);
  const preferredLanguage = (_a = context.memory.preferences.languagePreference) != null ? _a : "en";
  const language = detectedLanguage === "fr" ? "fr" : preferredLanguage === "fr" ? "fr" : "en";
  return {
    input,
    language,
    topics: detectTopics(input, history),
    taskTypes: detectTaskTypes(input, history),
    productKind: detectProductKind(input, history),
    mentionedTools: detectMentionedTools(input, history),
    recentUserMessages: getRecentUserMessages(history),
    hasHistory: history.some((message) => message.role === "user"),
    memory: context.memory,
    learnedFacts: context.learnedFacts
  };
}
function formatToolList(tools) {
  if (tools.length === 0) {
    return "";
  }
  if (tools.length === 1) {
    return tools[0];
  }
  if (tools.length === 2) {
    return `${tools[0]} and ${tools[1]}`;
  }
  return `${tools.slice(0, -1).join(", ")}, and ${tools[tools.length - 1]}`;
}
function formatToolListFr(tools) {
  if (tools.length === 0) {
    return "";
  }
  if (tools.length === 1) {
    return tools[0];
  }
  if (tools.length === 2) {
    return `${tools[0]} et ${tools[1]}`;
  }
  return `${tools.slice(0, -1).join(", ")}, et ${tools[tools.length - 1]}`;
}
function formatFactList(facts) {
  var _a;
  if (facts.length <= 1) {
    return (_a = facts[0]) != null ? _a : "";
  }
  return `${facts.slice(0, -1).join(", ")}, and ${facts[facts.length - 1]}`;
}
function getFaqMatch(input) {
  const normalizedInput = normalizeQuestionMatch(input);
  return aidoAgentFaqs.find((faq) => {
    const normalizedQuestion = normalizeQuestionMatch(faq.question);
    return normalizedInput === normalizedQuestion || normalizedInput.includes(normalizedQuestion) || normalizedQuestion.includes(normalizedInput);
  });
}
function createFaqReply(faqQuestion, faqAnswer, language) {
  const intro = language === "fr" ? `Bonne question 👌 Voici la réponse la plus directe sur Octopus Market pour: “${faqQuestion}”` : `Great question 👌 Here is the clearest Octopus Market answer for: “${faqQuestion}”`;
  const followUp = language === "fr" ? "Si tu veux, je peux aussi te guider ensuite vers la bonne zone de la plateforme: Launch Token, Prediction Market, ou List My AI." : "If you want, I can also guide you to the right platform area next: Launch Token, Prediction Market, or List My AI.";
  return `${intro}

${faqAnswer}

${followUp}`;
}
function getOpening(profile) {
  const nameSegment = profile.memory.user.name ? ` ${profile.memory.user.name}` : "";
  if (profile.language === "fr") {
    if (profile.hasHistory) {
      return `Hey${nameSegment} 👋 Je reprends le fil avec ta mémoire Aido Agent pour te répondre de façon plus naturelle, plus autonome, et plus utile.`;
    }
    return `Hey${nameSegment} 👋 Aido Agent est prêt. Je peux t’aider à comprendre, écrire, comparer, résumer, analyser, ou structurer tes idées sans partir en freestyle inutile.`;
  }
  if (profile.hasHistory) {
    return `Hey${nameSegment} 👋 I’m picking up the thread with your Aido Agent memory so I can answer in a more natural, autonomous, and useful way.`;
  }
  return `Hey${nameSegment} 👋 Aido Agent is on. I can help explain, write, compare, summarize, analyze, or structure your ideas without falling into robotic fluff.`;
}
function getLearnedFactsLine(profile) {
  if (profile.learnedFacts.length === 0) {
    return "";
  }
  if (profile.language === "fr") {
    return `Noté ✅ Je grave aussi dans ma mémoire Aido Agent-style: ${formatFactList(profile.learnedFacts)}.`;
  }
  return `Noted ✅ I’m locking this into my Aido Agent memory: ${formatFactList(profile.learnedFacts)}.`;
}
function getMemoryRecallLine(profile) {
  const memoryFacts = [];
  if (profile.memory.user.profession) {
    memoryFacts.push(
      profile.language === "fr" ? `tu es ${profile.memory.user.profession}` : `you are ${profile.memory.user.profession}`
    );
  }
  if (profile.memory.user.location) {
    memoryFacts.push(
      profile.language === "fr" ? `tu es basé vers ${profile.memory.user.location}` : `you are based around ${profile.memory.user.location}`
    );
  }
  if (profile.memory.projectsInProgress[0]) {
    memoryFacts.push(
      profile.language === "fr" ? `tu bosses sur ${profile.memory.projectsInProgress[0]}` : `you’re working on ${profile.memory.projectsInProgress[0]}`
    );
  }
  if (profile.memory.currentGoals[0]) {
    memoryFacts.push(
      profile.language === "fr" ? `ton objectif du moment est ${profile.memory.currentGoals[0]}` : `your current goal is ${profile.memory.currentGoals[0]}`
    );
  }
  if (profile.memory.importantInformation[0]) {
    memoryFacts.push(
      profile.language === "fr" ? `tu m’as aussi dit que tu aimes ${profile.memory.importantInformation[0]}` : `you also told me you like ${profile.memory.importantInformation[0]}`
    );
  }
  if (memoryFacts.length === 0 || profile.learnedFacts.length > 0) {
    return "";
  }
  if (profile.language === "fr") {
    return `Comme tu me l’as déjà dit, je garde en tête que ${formatFactList(memoryFacts)}.`;
  }
  return `From what you told me before, I’m keeping in mind that ${formatFactList(memoryFacts)}.`;
}
function getProductAngle(profile) {
  const kindCopy = {
    fr: {
      agent: "Pour un agent IA, l’angle qui convertit le mieux reste très concret: ce qu’il automatise, ce qu’il sécurise, et quel temps ou risque il fait gagner.",
      image: "Pour un outil image, le bon angle reste la qualité du rendu, la vitesse de production, et la clarté du résultat final.",
      finance: "Pour un produit finance, il faut rassurer vite sur la lisibilité, la confiance, et la vitesse de décision.",
      code: "Pour un produit code, le message qui mord bien mélange gain de temps, qualité de livraison, et baisse de friction pour l’équipe.",
      token: "Pour un projet token, la différence se joue souvent sur la clarté du lancement, la confiance, et la préparation du dossier.",
      general: "Sur Octopus Market, le bon angle reste simple: qui gagne quoi, à quel moment, et pourquoi c’est crédible."
    },
    en: {
      agent: "For an AI agent, the angle that converts best is very concrete: what it automates, what it secures, and what time or risk it saves.",
      image: "For an image tool, the winning angle stays visual quality, production speed, and a clear final output.",
      finance: "For a finance product, the key is fast reassurance around readability, trust, and speed of decision-making.",
      code: "For a code product, the message that bites best blends time saved, delivery quality, and less friction for the team.",
      token: "For a token project, the difference usually comes from launch clarity, trust, and how well the file is prepared.",
      general: "On Octopus Market, the right angle stays simple: who gets what benefit, when they get it, and why it feels credible."
    }
  };
  return kindCopy[profile.language][profile.productKind];
}
function getClawdTrustBlock(profile) {
  if (profile.language === "fr") {
    return "ClawdTrust garde le positionnement le plus différenciant de la catégorie Agent ici: Free/month pour le moment, 492 users, badge gold, lien direct vers clawdtrust.com, et promesse nette autour du prediction market et du rug control sur Solana.";
  }
  return "ClawdTrust keeps the most differentiated angle in the Agent category here: Free/month for now, 492 users, a gold badge, a direct link to clawdtrust.com, and a clear promise around prediction markets and rug control on Solana.";
}
function getPredictionMarketBlock(profile) {
  if (profile.language === "fr") {
    return `Le binary prediction market est maintenant un flux clé d’Octopus Market: 6 sections thématiques, positions Yes ou No, connexion wallet requise, validation par signature Phantom, historique local des positions, puis fee automatique de ${predictionMarketFeeRate}% envoyé vers ${predictionMarketTreasuryAddress} au moment du claim.`;
  }
  return `The binary prediction market is now a core Octopus Market flow: 6 themed sections, Yes or No positions, wallet-required access, Phantom signature approval, local position history, then an automatic ${predictionMarketFeeRate}% claim fee routed to ${predictionMarketTreasuryAddress} at claim time.`;
}
function getPlatformKnowledgeBlock(profile) {
  var _a, _b, _c;
  const launchFlowValue = (_a = launchFlowStat == null ? void 0 : launchFlowStat.value) != null ? _a : "3";
  const accessAreas = aidoAgentAccessAreas.join(", ");
  if (profile.language === "fr") {
    return `Côté plateforme, je suis branché sur les infos utiles d’Octopus Market: ${launchFlowValue} flux actifs, paiement listing via wallet Solana vers ${solanaPaymentAddress}, utilités verrouillées derrière la connexion wallet, ClawdTrust mis en avant dans Agent, référence X ${(_b = twitterReference == null ? void 0 : twitterReference.label) != null ? _b : "@xOctopusMarket"}, token officiel ${officialTokenName}, CA ${officialTokenAddress}, et site officiel ${websiteUrl}. Mes zones de contexte couvrent: ${accessAreas}.`;
  }
  return `On the platform side, I’m grounded in Octopus Market context: ${launchFlowValue} live flows, listing payment through a Solana wallet to ${solanaPaymentAddress}, utility access locked behind wallet connection, ClawdTrust featured in Agent, the X reference ${(_c = twitterReference == null ? void 0 : twitterReference.label) != null ? _c : "@xOctopusMarket"}, the official token ${officialTokenName}, its contract ${officialTokenAddress}, and the official website ${websiteUrl}. My access areas cover: ${accessAreas}.`;
}
function getPricingBlock(profile) {
  if (!annualPlan$1 || !monthlyPlan$1) {
    return "";
  }
  if (profile.language === "fr") {
    return `Pour le listing, le plan ${monthlyPlan$1.name.toLowerCase()} reste le plus simple pour tester vite, alors que le ${annualPlan$1.name.toLowerCase()} devient plus rentable si tu veux une présence durable. Le paiement passe par signature wallet Solana, et la réduction holder s’active au-dessus de ${clawdTrustThresholdUsd}$ en $ClawdTrust.`;
  }
  return `For listing, the ${monthlyPlan$1.name.toLowerCase()} is the simplest way to test quickly, while the ${annualPlan$1.name.toLowerCase()} becomes more efficient if you want lasting visibility. Payment runs through a Solana wallet signature, and the holder discount unlocks above ${clawdTrustThresholdUsd}$ in $ClawdTrust.`;
}
function getVisibilityBlock(profile) {
  if (profile.language === "fr") {
    return "L’impact positif concret d’Octopus Market repose sur trois leviers: plus de visibilité immédiate, plus de confiance via les badges de vérification, et un chemin plus direct vers l’activation ou la monétisation.";
  }
  return "The concrete upside of Octopus Market sits on three levers: more immediate visibility, more trust through verification badges, and a more direct path to activation or monetization.";
}
function getLaunchBlock(profile) {
  if (profile.language === "fr") {
    return "Si tu touches au launch token, le Launch Token flow centralise déjà le nom, le symbole, la description, la mint address, le logo, le whitepaper, les wallets développeur, les liens X, Telegram, Discord, le fee preview, et la passerelle Bags.fm.";
  }
  return "If you’re working on token launch, the Launch Token flow already centralizes the name, symbol, description, mint address, logo, whitepaper, developer wallets, X, Telegram, Discord links, the fee preview, and the Bags.fm handoff.";
}
function getComparisonBlock(profile) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p;
  const tools = profile.mentionedTools.slice(0, 2);
  if (tools.length === 0) {
    if (profile.language === "fr") {
      return "Si tu veux une vraie comparaison utile, donne-moi juste deux noms, et je te dirai lequel est plus fort pour la confiance, la visibilité, ou la conversion sur Octopus Market.";
    }
    return "If you want a genuinely useful comparison, just give me two names, and I’ll tell you which one is stronger for trust, visibility, or conversion on Octopus Market.";
  }
  const comparedTools = toolCatalog.filter((tool) => tools.includes(tool.name));
  if (profile.language === "fr") {
    return `Comparaison rapide entre ${formatToolListFr(tools)}:
• ${(_b = (_a = comparedTools[0]) == null ? void 0 : _a.name) != null ? _b : tools[0]} se démarque surtout par ${(_d = (_c = comparedTools[0]) == null ? void 0 : _c.description.toLowerCase()) != null ? _d : "sa proposition de valeur"}.
• ${(_f = (_e = comparedTools[1]) == null ? void 0 : _e.name) != null ? _f : tools[1]} brille davantage par ${(_h = (_g = comparedTools[1]) == null ? void 0 : _g.description.toLowerCase()) != null ? _h : "son positionnement"}.
• Si ton objectif est la confiance et la différenciation dans Agent, ClawdTrust garde un angle plus unique grâce à son badge gold et à son focus Solana.`;
  }
  return `Quick comparison between ${formatToolList(tools)}:
• ${(_j = (_i = comparedTools[0]) == null ? void 0 : _i.name) != null ? _j : tools[0]} stands out mainly for ${(_l = (_k = comparedTools[0]) == null ? void 0 : _k.description.toLowerCase()) != null ? _l : "its core value proposition"}.
• ${(_n = (_m = comparedTools[1]) == null ? void 0 : _m.name) != null ? _n : tools[1]} is more differentiated around ${(_p = (_o = comparedTools[1]) == null ? void 0 : _o.description.toLowerCase()) != null ? _p : "its positioning"}.
• If your goal is trust and differentiation inside Agent, ClawdTrust keeps the more unique angle thanks to the gold badge and its Solana focus.`;
}
function getPositioningBlock(profile) {
  const referencedTools = profile.mentionedTools.length > 0 ? profile.mentionedTools : [];
  if (profile.language === "fr") {
    if (referencedTools.length > 0) {
      return `Pour ${formatToolListFr(referencedTools)}, je pousserais un message court, concret, et orienté résultat. Pas de blabla de robot: bénéfice clair, preuve rapide, puis appel à l’action visible.`;
    }
    return "Je te conseille un positionnement en trois couches: la promesse en une ligne, la preuve concrète, puis l’action à faire ensuite. C’est souvent là que ça mord bien. 🐶";
  }
  if (referencedTools.length > 0) {
    return `For ${formatToolList(referencedTools)}, I would push a short, concrete, outcome-led message. No robotic fluff: clear benefit, quick proof, then a visible call to action.`;
  }
  return "I’d recommend a three-layer positioning structure: one-line promise, concrete proof, then the next action to take. That usually bites in the right way. 🐶";
}
function getWritingBlock(profile) {
  var _a, _b;
  const subject = (_a = profile.mentionedTools[0]) != null ? _a : profile.memory.projectsInProgress[0] ? profile.memory.projectsInProgress[0] : "your product";
  if (profile.language === "fr") {
    const frenchSubject = (_b = profile.mentionedTools[0]) != null ? _b : profile.memory.projectsInProgress[0] ? profile.memory.projectsInProgress[0] : "ton produit";
    return `Si tu veux un texte plus fort pour ${frenchSubject}, je partirais sur cette structure:
• promesse: une phrase ultra claire sur le résultat,
• preuve: pourquoi c’est crédible maintenant,
• appel à l’action: quoi faire ensuite sans hésiter.
Je peux aussi te le rédiger directement si tu me donnes le ton souhaité.`;
  }
  return `If you want stronger copy for ${subject}, I’d start with this structure:
• promise: one very clear outcome-led sentence,
• proof: why it feels credible right now,
• call to action: what to do next without hesitation.
I can also write it directly if you give me the tone you want.`;
}
function getSummaryBlock(profile) {
  if (profile.language === "fr") {
    return "Version courte de ce que je capte: tu veux une réponse plus autonome, plus utile, et ancrée dans ton contexte plutôt qu’un simple chatbot à réponses fixes.";
  }
  return "Short version of what I’m reading: you want a more autonomous, more useful reply style that adapts to your context instead of acting like a fixed-path chatbot.";
}
function getExplanationBlock(profile) {
  if (profile.language === "fr") {
    return "En version simple: Aido Agent doit comprendre ton intention, réutiliser ta mémoire, te répondre clairement, puis te proposer la meilleure suite au lieu d’attendre passivement la prochaine consigne.";
  }
  return "In simple terms: Aido Agent should understand your intent, reuse memory, answer clearly, and then propose the best next step instead of passively waiting for another command.";
}
function getBrainstormBlock(profile) {
  if (profile.language === "fr") {
    return `Trois pistes rapides que je vois tout de suite:
1. angle résultat: parler d’impact concret avant la techno,
2. angle confiance: mettre en avant badge, preuve, et clarté,
3. angle activation: rendre la prochaine action évidente dès le premier écran.`;
  }
  return `Three quick angles I see right away:
1. outcome angle: talk about concrete impact before the tech,
2. trust angle: lead with badge, proof, and clarity,
3. activation angle: make the next action obvious from the first screen.`;
}
function getAnalysisBlock(profile) {
  const currentGoal = profile.memory.currentGoals[0];
  if (profile.language === "fr") {
    return currentGoal ? `Mon analyse rapide en tenant compte de ton objectif actuel (${currentGoal}): tu gagneras surtout en clarté si tu simplifies la promesse, puis en conversion si tu remontes la preuve sociale et le CTA.` : "Mon analyse rapide: tu gagneras surtout en clarté si tu simplifies la promesse, puis en conversion si tu remontes la preuve sociale et le CTA.";
  }
  return currentGoal ? `My quick analysis, based on your current goal (${currentGoal}): you’ll gain most by simplifying the promise first, then increasing conversion by surfacing social proof and the CTA.` : "My quick analysis: you’ll gain most by simplifying the promise first, then increasing conversion by surfacing social proof and the CTA.";
}
function getPlanningBlock(profile) {
  if (profile.language === "fr") {
    return `Plan simple en 3 temps:
1. clarifier l’objectif,
2. transformer ça en message visible ou en setup concret,
3. lancer la prochaine action sur la plateforme sans attendre.`;
  }
  return `Simple three-step plan:
1. clarify the goal,
2. turn it into visible messaging or concrete setup,
3. launch the next action on the platform without waiting.`;
}
function getGeneralAutonomyBlock(profile) {
  if (profile.language === "fr") {
    return "Je peux maintenant répondre plus librement comme un mini copilote: expliquer, reformuler, structurer, analyser, comparer, ou proposer des idées, tout en gardant ta mémoire utilisateur active.";
  }
  return "I can now answer more freely like a mini copilot: explain, rewrite, structure, analyze, compare, or suggest ideas while keeping your user memory active.";
}
function getActionPlan(profile) {
  const firstStep = profile.memory.currentGoals[0] ? profile.language === "fr" ? `rester aligné avec ton objectif actuel: ${profile.memory.currentGoals[0]}` : `stay aligned with your current goal: ${profile.memory.currentGoals[0]}` : profile.language === "fr" ? "clarifier la promesse produit en une phrase" : "tighten the product promise into one sentence";
  if (profile.language === "fr") {
    return `Voici la meilleure suite que je te recommande:
1. ${firstStep},
2. choisir l’angle entre Launch Token, Prediction Market, ou List My AI,
3. transformer ça en message visible, preuve claire, et prochaine action simple.`;
  }
  return `Here’s the next move I’d recommend:
1. ${firstStep},
2. choose the angle between Launch Token, Prediction Market, or List My AI,
3. turn that into visible copy, clear proof, and a simple next action.`;
}
function getProactiveQuestion(profile) {
  if (profile.taskTypes.includes("write")) {
    return profile.language === "fr" ? "Tu veux que je te rédige ça maintenant en version courte, premium, ou plus agressive côté conversion ?" : "Do you want me to draft that now in a short, premium, or more conversion-focused version?";
  }
  if (profile.topics.includes("launch")) {
    return profile.language === "fr" ? "Tu veux que je t’aide maintenant à structurer ton launch token, ou plutôt à préparer le message visible sur la fiche ?" : "Do you want me to help structure your token launch next, or prepare the public-facing listing message first?";
  }
  if (profile.topics.includes("listing") || profile.topics.includes("pricing")) {
    return profile.language === "fr" ? "Tu veux que je t’aide à choisir le bon plan, à préparer le paiement wallet Solana, ou à rédiger la fiche qui convertit le mieux ?" : "Do you want help choosing the right plan, preparing the Solana wallet payment, or writing the listing copy that converts best?";
  }
  if (profile.topics.includes("clawdtrust") || profile.topics.includes("comparison")) {
    return profile.language === "fr" ? "Tu veux une comparaison frontale avec un autre agent, ou tu préfères que je t’aide à mieux mettre en avant l’angle unique de ClawdTrust ?" : "Do you want a head-to-head comparison with another agent, or would you rather have me sharpen ClawdTrust’s unique angle first?";
  }
  return profile.language === "fr" ? "Balance-moi juste ton objectif, un texte à retravailler, ou une question sur la plateforme, et je prends le relais." : "Send me your goal, a draft to improve, or a platform question, and I’ll take it from there.";
}
function getClosing(profile) {
  if (profile.language === "fr") {
    return "Je suis prêt pour la suite, boss. Donne-moi ton contexte, ton brouillon, ou ta question, et je te répondrai comme un Aido Agent qui a de la mémoire et du mordant. 🐾";
  }
  return "I’m ready for the next step. Give me your context, draft, or question, and I’ll answer like an Aido Agent with memory and bite. 🐾";
}
function createAssistantReply(input, history, context) {
  const faqMatch = getFaqMatch(input);
  const faqLanguage = detectChatLanguage(input);
  if (faqMatch) {
    return {
      id: `assistant-${Date.now()}`,
      role: "assistant",
      language: faqLanguage,
      content: createFaqReply(faqMatch.question, faqMatch.answer, faqLanguage),
      createdAt: Date.now()
    };
  }
  const profile = buildProfile(input, history, context);
  const blocks = [getOpening(profile)];
  const learnedFactsLine = getLearnedFactsLine(profile);
  if (learnedFactsLine) {
    blocks.push(learnedFactsLine);
  }
  const memoryRecallLine = getMemoryRecallLine(profile);
  if (memoryRecallLine) {
    blocks.push(memoryRecallLine);
  }
  if (profile.taskTypes.includes("summarize")) {
    blocks.push(getSummaryBlock(profile));
  }
  if (profile.taskTypes.includes("explain")) {
    blocks.push(getExplanationBlock(profile));
  }
  if (profile.taskTypes.includes("brainstorm")) {
    blocks.push(getBrainstormBlock(profile));
  }
  if (profile.taskTypes.includes("analyze")) {
    blocks.push(getAnalysisBlock(profile));
  }
  if (profile.taskTypes.includes("plan")) {
    blocks.push(getPlanningBlock(profile));
  }
  if (profile.taskTypes.includes("write")) {
    blocks.push(getWritingBlock(profile));
  }
  if (profile.taskTypes.includes("compare") || profile.topics.includes("comparison")) {
    blocks.push(getComparisonBlock(profile));
  }
  if (profile.topics.includes("clawdtrust")) {
    blocks.push(getClawdTrustBlock(profile));
  }
  if (profile.topics.includes("pricing") || profile.topics.includes("listing")) {
    blocks.push(getPricingBlock(profile));
  }
  if (profile.topics.includes("visibility") || profile.topics.includes("positioning") || profile.topics.includes("agent")) {
    blocks.push(getVisibilityBlock(profile));
    blocks.push(getProductAngle(profile));
    blocks.push(getPositioningBlock(profile));
  }
  if (profile.topics.includes("launch")) {
    blocks.push(getLaunchBlock(profile));
  }
  if (profile.topics.includes("prediction")) {
    blocks.push(getPredictionMarketBlock(profile));
  }
  if (profile.topics.includes("general") || profile.topics.includes("listing") || profile.topics.includes("launch") || profile.topics.includes("prediction") || profile.topics.includes("clawdtrust")) {
    blocks.push(getPlatformKnowledgeBlock(profile));
  }
  if (profile.topics.includes("general") || profile.taskTypes.includes("general") || blocks.length <= 3) {
    blocks.push(getGeneralAutonomyBlock(profile));
  }
  blocks.push(getActionPlan(profile));
  blocks.push(getProactiveQuestion(profile));
  blocks.push(getClosing(profile));
  const content = blocks.filter(Boolean).join("\n\n");
  return {
    id: `assistant-${Date.now()}`,
    role: "assistant",
    language: profile.language,
    content,
    createdAt: Date.now()
  };
}
const annualPlan = pricingPlans.find((plan) => plan.name.toLowerCase().includes("annual"));
const monthlyPlan = pricingPlans.find((plan) => plan.name.toLowerCase().includes("monthly"));
const clawdTrustTool = featuredTools.find((tool) => tool.name === "ClawdTrust");
function includesAny(text, keywords) {
  return keywords.some((keyword) => text.includes(keyword));
}
function createFrenchSimulation(prompt) {
  var _a, _b, _c, _d;
  const normalizedPrompt = prompt.toLowerCase();
  if (includesAny(normalizedPrompt, ["tweet", "post", "x ", "twitter", "réseau", "social"])) {
    return {
      badge: "Social push",
      title: "Campagne de visibilité préparée",
      summary: "Aido Agent prépare un angle de post plus clair pour attirer les bons utilisateurs vers la fiche Octopus Market.",
      metrics: [
        { label: "Angle", value: "Preuve + bénéfice" },
        { label: "CTA", value: "Voir la fiche" },
        { label: "Impact estimé", value: "+18%", delta: "engagement" }
      ],
      bullets: [
        "mettre la promesse en une ligne très concrète",
        "montrer un bénéfice visible dès les 3 premiers mots",
        "renvoyer vers la fiche ou le launch studio selon l’objectif"
      ],
      footer: "Mode simulation activé, prêt à transformer ça en message produit ou en fiche de listing."
    };
  }
  if (includesAny(normalizedPrompt, ["shopify", "vente", "commandes", "revenu", "monétisation"])) {
    return {
      badge: "Revenue lens",
      title: "Analyse monétisation prête",
      summary: "Aido Agent relie le discours produit à la conversion, pour que la visibilité sur Octopus Market serve aussi la monétisation.",
      metrics: [
        { label: "Friction", value: "Basse" },
        { label: "Activation", value: "+12%", delta: "estimée" },
        { label: "Conversion path", value: "Plus court" }
      ],
      bullets: [
        "clarifier qui gagne quoi immédiatement",
        "mettre le badge et la preuve sociale avant le bouton",
        "raccourcir le chemin entre découverte et clic sortant"
      ],
      footer: "On ne va pas aboyer pour rien, le but reste du trafic qualifié qui mord côté conversion. 🐶"
    };
  }
  if (includesAny(normalizedPrompt, ["analyse", "stats", "visibilité", "audience", "growth", "croissance"])) {
    return {
      badge: "Visibility scan",
      title: "Analyse de visibilité terminée",
      summary: "Aido Agent repère les leviers qui donnent le plus d’impact concret sur Octopus Market: clarté, confiance, et prochain clic.",
      metrics: [
        { label: "Confiance", value: "+30%", delta: "badges" },
        { label: "Lisibilité", value: "Très bonne" },
        { label: "Prochain clic", value: "Visible" }
      ],
      bullets: [
        "renforcer la headline avec une promesse résultat",
        "mettre le bénéfice business avant la techno",
        "faire ressortir le CTA principal plus tôt dans la fiche"
      ],
      footer: "C’est le mode radar Aido Agent: simple, utile, et sans fumée de robot."
    };
  }
  if (includesAny(normalizedPrompt, ["launch", "token", "mint", "bags", "solfair"])) {
    return {
      badge: "Launch mode",
      title: "Checklist de lancement prête",
      summary: "Aido Agent passe en mode launch et t’aide à verrouiller les infos avant l’envoi vers Bags.fm.",
      metrics: [
        { label: "Documents", value: "Whitepaper + logo" },
        { label: "Wallets", value: "Dev + lock" },
        { label: "Passerelle", value: "Bags.fm ready" }
      ],
      bullets: [
        "vérifier le nom, le symbole, et la description finale",
        "préparer les wallets développeur et lock wallet",
        `vérifier si le bonus holder $ClawdTrust au-dessus de ${clawdTrustThresholdUsd}$ s’applique`
      ],
      footer: "Mode autonome activé pour éviter un lancement en freestyle poulpesque. 🐙"
    };
  }
  if (includesAny(normalizedPrompt, ["listing", "wallet", "solana", "payment", "paiement", "signature"])) {
    return {
      badge: "Listing flow",
      title: "Flux de listing prêt à lancer",
      summary: "Aido Agent prépare le chemin le plus simple entre la fiche, la signature du wallet Solana, et le prélèvement du listing.",
      metrics: [
        { label: "Plan rapide", value: (_a = monthlyPlan == null ? void 0 : monthlyPlan.name) != null ? _a : "Monthly" },
        { label: "Plan durable", value: (_b = annualPlan == null ? void 0 : annualPlan.name) != null ? _b : "Annual" },
        { label: "Discount", value: "-30%", delta: "$ClawdTrust" }
      ],
      bullets: [
        "valider le plan selon vitesse ou présence durable",
        "préparer le wallet Solana avant la signature",
        "ajouter le holder wallet si tu veux le discount"
      ],
      footer: "Le chemin est prêt: moins de friction, plus de chance d’activer ton listing rapidement."
    };
  }
  if (includesAny(normalizedPrompt, ["clawdtrust", "prediction", "rug"])) {
    return {
      badge: "Featured agent",
      title: "ClawdTrust mis en avant",
      summary: "Aido Agent recentre le discours sur ce qui différencie vraiment ClawdTrust dans la catégorie Agent.",
      metrics: [
        { label: "Prix", value: (_c = clawdTrustTool == null ? void 0 : clawdTrustTool.price) != null ? _c : "Free/month" },
        { label: "Users", value: (_d = clawdTrustTool == null ? void 0 : clawdTrustTool.users) != null ? _d : "492 users" },
        { label: "Badge", value: "Gold verified" }
      ],
      bullets: [
        "prediction market sur Solana",
        "rug control sur Solana",
        "angle confiance plus fort que les cartes classiques"
      ],
      footer: "ClawdTrust reste la carte premium de la meute sur la plateforme."
    };
  }
  return {
    badge: "Autonomous mode",
    title: "Réponse autonome prête",
    summary: "Aido Agent transforme ton message en plan d’action clair, avec un angle produit, une prochaine étape, et une sortie utile pour la plateforme.",
    metrics: [
      { label: "Compréhension", value: "Contextuelle" },
      { label: "Mémoire", value: "Persistante" },
      { label: "Style", value: "Aido Agent" }
    ],
    bullets: [
      "répondre plus librement, comme un copilote",
      "garder les infos importantes de l’utilisateur",
      "proposer la meilleure prochaine action sans attendre"
    ],
    footer: "Je te file la patte, boss: envoie-moi un objectif, un texte, ou une idée à structurer."
  };
}
function createEnglishSimulation(prompt) {
  var _a, _b, _c, _d;
  const normalizedPrompt = prompt.toLowerCase();
  if (includesAny(normalizedPrompt, ["tweet", "post", "x ", "twitter", "social"])) {
    return {
      badge: "Social push",
      title: "Visibility campaign prepared",
      summary: "Aido Agent is shaping a cleaner social angle to drive the right users toward the Octopus Market listing.",
      metrics: [
        { label: "Angle", value: "Proof + benefit" },
        { label: "CTA", value: "View listing" },
        { label: "Estimated lift", value: "+18%", delta: "engagement" }
      ],
      bullets: [
        "lead with one concrete promise",
        "show the outcome in the first few words",
        "send users to the listing or launch studio based on intent"
      ],
      footer: "Simulation mode is on, ready to turn this into sharper product copy."
    };
  }
  if (includesAny(normalizedPrompt, ["shopify", "orders", "sales", "revenue", "monetization"])) {
    return {
      badge: "Revenue lens",
      title: "Monetization review ready",
      summary: "Aido Agent is connecting the product message to conversion so Octopus Market visibility also supports revenue.",
      metrics: [
        { label: "Friction", value: "Low" },
        { label: "Activation", value: "+12%", delta: "estimated" },
        { label: "Conversion path", value: "Shorter" }
      ],
      bullets: [
        "clarify who gets what value immediately",
        "show trust signals before the main button",
        "shorten the path from discovery to outbound click"
      ],
      footer: "No barking for nothing here, the goal is qualified attention that converts. 🐶"
    };
  }
  if (includesAny(normalizedPrompt, ["analyze", "stats", "visibility", "audience", "growth"])) {
    return {
      badge: "Visibility scan",
      title: "Visibility analysis completed",
      summary: "Aido Agent highlights the levers that create the most concrete upside on Octopus Market: clarity, trust, and the next click.",
      metrics: [
        { label: "Trust", value: "+30%", delta: "badges" },
        { label: "Readability", value: "Strong" },
        { label: "Next click", value: "Visible" }
      ],
      bullets: [
        "tighten the headline around an outcome",
        "put the business benefit ahead of the tech",
        "surface the main CTA earlier on the listing"
      ],
      footer: "This is Aido Agent radar mode: simple, useful, and without robot fog."
    };
  }
  if (includesAny(normalizedPrompt, ["launch", "token", "mint", "bags", "solfair"])) {
    return {
      badge: "Launch mode",
      title: "Launch checklist prepared",
      summary: "Aido Agent is in launch mode and helps lock the right information before the Bags.fm handoff.",
      metrics: [
        { label: "Documents", value: "Whitepaper + logo" },
        { label: "Wallets", value: "Dev + lock" },
        { label: "Handoff", value: "Bags.fm ready" }
      ],
      bullets: [
        "confirm the final name, ticker, and description",
        "prepare both developer wallets and the lock wallet",
        `check whether the $ClawdTrust holder bonus above ${clawdTrustThresholdUsd}$ applies`
      ],
      footer: "Autonomous mode is on to stop the launch turning into an octopus-style freestyle. 🐙"
    };
  }
  if (includesAny(normalizedPrompt, ["listing", "wallet", "solana", "payment", "signature"])) {
    return {
      badge: "Listing flow",
      title: "Listing flow prepared",
      summary: "Aido Agent is setting up the shortest path between listing copy, Solana wallet signature, and the automatic listing charge.",
      metrics: [
        { label: "Fast plan", value: (_a = monthlyPlan == null ? void 0 : monthlyPlan.name) != null ? _a : "Monthly" },
        { label: "Long play", value: (_b = annualPlan == null ? void 0 : annualPlan.name) != null ? _b : "Annual" },
        { label: "Discount", value: "-30%", delta: "$ClawdTrust" }
      ],
      bullets: [
        "pick the plan based on testing speed or durable presence",
        "prepare the Solana wallet before signing",
        "add the holder wallet if you want the discount applied"
      ],
      footer: "The path is ready: less friction, better odds of activating the listing fast."
    };
  }
  if (includesAny(normalizedPrompt, ["clawdtrust", "prediction", "rug"])) {
    return {
      badge: "Featured agent",
      title: "ClawdTrust spotlight prepared",
      summary: "Aido Agent is focusing the story on what truly differentiates ClawdTrust inside the Agent category.",
      metrics: [
        { label: "Price", value: (_c = clawdTrustTool == null ? void 0 : clawdTrustTool.price) != null ? _c : "Free/month" },
        { label: "Users", value: (_d = clawdTrustTool == null ? void 0 : clawdTrustTool.users) != null ? _d : "492 users" },
        { label: "Badge", value: "Gold verified" }
      ],
      bullets: [
        "prediction market agent on Solana",
        "rug control on Solana",
        "stronger trust angle than a standard agent card"
      ],
      footer: "ClawdTrust stays the premium card in the pack on this platform."
    };
  }
  return {
    badge: "Autonomous mode",
    title: "Autonomous response prepared",
    summary: "Aido Agent turns your message into a clearer plan with product angle, useful next step, and a practical output for the platform.",
    metrics: [
      { label: "Understanding", value: "Contextual" },
      { label: "Memory", value: "Persistent" },
      { label: "Style", value: "Aido Agent" }
    ],
    bullets: [
      "reply more freely like a copilot",
      "keep important user details in memory",
      "propose the best next action without waiting"
    ],
    footer: "Send me a goal, a draft, or an idea to structure, and I’ll run with it."
  };
}
function createCyrDogeSimulation(prompt, language) {
  return language === "fr" ? createFrenchSimulation(prompt) : createEnglishSimulation(prompt);
}
function createEmptyCyrDogeMemory() {
  return {
    user: {
      name: null,
      age: null,
      location: null,
      profession: null
    },
    preferences: {
      languagePreference: "en",
      responseStyle: "concise and helpful",
      tonePreference: "professional and friendly",
      humorPreference: "light humor"
    },
    projectsInProgress: [],
    currentGoals: [],
    importantInformation: [],
    updatedAt: Date.now()
  };
}
let cyrDogeMemoryCache = null;
function readStoredCyrDogeMemory() {
  return cyrDogeMemoryCache;
}
async function loadCyrDogeMemory(walletAddress) {
  const memory = await getAgentMemory(walletAddress);
  if (!memory) return null;
  const result = {
    user: {
      name: memory.user.name,
      age: memory.user.age,
      location: memory.user.location,
      profession: memory.user.profession
    },
    preferences: {
      languagePreference: memory.preferences.languagePreference,
      responseStyle: memory.preferences.responseStyle,
      tonePreference: memory.preferences.tonePreference,
      humorPreference: memory.preferences.humorPreference
    },
    projectsInProgress: memory.projectsInProgress,
    currentGoals: memory.currentGoals,
    importantInformation: memory.importantInformation,
    updatedAt: memory.updatedAt
  };
  cyrDogeMemoryCache = result;
  return result;
}
async function writeStoredCyrDogeMemory(walletAddress, memory) {
  cyrDogeMemoryCache = memory;
  await saveAgentMemory(walletAddress, {
    user: {
      name: memory.user.name,
      age: memory.user.age,
      location: memory.user.location,
      profession: memory.user.profession
    },
    preferences: {
      languagePreference: memory.preferences.languagePreference,
      responseStyle: memory.preferences.responseStyle,
      tonePreference: memory.preferences.tonePreference,
      humorPreference: memory.preferences.humorPreference
    },
    projectsInProgress: memory.projectsInProgress,
    currentGoals: memory.currentGoals,
    importantInformation: memory.importantInformation,
    updatedAt: memory.updatedAt
  });
}
function normalizeCapturedValue(value) {
  return value.replace(/\s+/g, " ").trim().replace(/[.,!?;:]+$/g, "").trim();
}
function toTitleCase(value) {
  return value.split(" ").filter(Boolean).map((part) => part.charAt(0).toUpperCase() + part.slice(1)).join(" ");
}
function addUniqueValue(values, value) {
  const normalizedValue = normalizeCapturedValue(value);
  if (!normalizedValue) return values;
  const alreadyExists = values.some(
    (existingValue) => existingValue.toLowerCase() === normalizedValue.toLowerCase()
  );
  if (alreadyExists) return values;
  return [normalizedValue, ...values].slice(0, 6);
}
function findFirstMatch(text, patterns) {
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match == null ? void 0 : match[1]) return normalizeCapturedValue(match[1]);
  }
  return null;
}
function extractName(text) {
  const value = findFirstMatch(text, [
    /(?:je m['']appelle|mon nom est)\s+([a-zà-ÿ][a-zà-ÿ' -]{1,40})/i,
    /(?:my name is)\s+([a-z][a-z' -]{1,40})/i
  ]);
  return value ? toTitleCase(value) : null;
}
function extractAge(text) {
  return findFirstMatch(text, [
    /(?:j'ai)\s+(\d{1,3})\s+ans/i,
    /(?:i am|i'm)\s+(\d{1,3})\s+years? old/i
  ]);
}
function extractLocation(text) {
  return findFirstMatch(text, [
    /(?:j'habite à|je vis à|je suis basé à|je suis en)\s+([^.!?\n]{2,60})/i,
    /(?:i live in|i'm based in|i am based in)\s+([^.!?\n]{2,60})/i
  ]);
}
function extractProfession(text) {
  return findFirstMatch(text, [
    /(?:je suis)\s+(?:un|une)\s+([^.!?\n]{2,60})/i,
    /(?:i am|i'm)\s+(?:a|an)\s+([^.!?\n]{2,60})/i
  ]);
}
function extractLanguagePreference(text) {
  const normalizedText = text.toLowerCase();
  if (/(réponds?|parle|écris|reste).*(français)|always.*french|answer.*in french|reply.*in french/i.test(normalizedText)) {
    return "fr";
  }
  if (/(réponds?|parle|écris).*(anglais)|answer.*in english|reply.*in english/i.test(normalizedText)) {
    return "en";
  }
  return null;
}
function extractResponseStyle(text) {
  if (/(court|bref|simple|direct|concis|short|brief|simple|direct)/i.test(text)) return "concise and direct";
  if (/(détaillé|long|approfondi|detail|detailed|long-form)/i.test(text)) return "detailed";
  return null;
}
function extractTonePreference(text) {
  if (/(amical|chaleureux|friendly|warm|décontracté|casual)/i.test(text)) return "friendly and warm";
  if (/(pro|professionnel|professional)/i.test(text)) return "professional";
  return null;
}
function extractHumorPreference(text) {
  if (/(humour|humor|drôle|funny|taquin|playful)/i.test(text)) return "light humor";
  return null;
}
function extractProject(text) {
  return findFirstMatch(text, [
    /(?:je travaille sur|je construis|je lance|mon projet est|je développe)\s+([^.!?\n]{4,90})/i,
    /(?:i'm building|i am building|i'm launching|we are launching|my project is|i'm working on|i am working on)\s+([^.!?\n]{4,90})/i
  ]);
}
function extractGoal(text) {
  return findFirstMatch(text, [
    /(?:mon objectif est|je veux|j'aimerais|j'ai besoin de|je cherche à)\s+([^.!?\n]{4,110})/i,
    /(?:my goal is|i want to|i need to|i'm trying to|i am trying to|i want)\s+([^.!?\n]{4,110})/i
  ]);
}
function extractImportantPreference(text) {
  return findFirstMatch(text, [
    /(?:j'aime|j'adore|je préfère|j'ai besoin de)\s+([^.!?\n]{4,90})/i,
    /(?:i like|i love|i prefer|i need)\s+([^.!?\n]{4,90})/i
  ]);
}
function updateField(currentValue, nextValue) {
  if (!nextValue) return currentValue;
  if ((currentValue == null ? void 0 : currentValue.toLowerCase()) === nextValue.toLowerCase()) return currentValue;
  return nextValue;
}
function updateCyrDogeMemory(memory, input) {
  const nextMemory = {
    ...memory,
    user: { ...memory.user },
    preferences: { ...memory.preferences },
    projectsInProgress: [...memory.projectsInProgress],
    currentGoals: [...memory.currentGoals],
    importantInformation: [...memory.importantInformation],
    updatedAt: Date.now()
  };
  const learnedFacts = [];
  const name = extractName(input);
  const age = extractAge(input);
  const location = extractLocation(input);
  const profession = extractProfession(input);
  const languagePreference = extractLanguagePreference(input);
  const responseStyle = extractResponseStyle(input);
  const tonePreference = extractTonePreference(input);
  const humorPreference = extractHumorPreference(input);
  const project = extractProject(input);
  const goal = extractGoal(input);
  const importantPreference = extractImportantPreference(input);
  const nextName = updateField(nextMemory.user.name, name);
  if (nextName !== nextMemory.user.name && nextName) {
    nextMemory.user.name = nextName;
    learnedFacts.push(`name: ${nextName}`);
  }
  const nextAge = updateField(nextMemory.user.age, age);
  if (nextAge !== nextMemory.user.age && nextAge) {
    nextMemory.user.age = nextAge;
    learnedFacts.push(`age: ${nextAge}`);
  }
  const nextLocation = updateField(nextMemory.user.location, location);
  if (nextLocation !== nextMemory.user.location && nextLocation) {
    nextMemory.user.location = nextLocation;
    learnedFacts.push(`location: ${nextLocation}`);
  }
  const nextProfession = updateField(nextMemory.user.profession, profession);
  if (nextProfession !== nextMemory.user.profession && nextProfession) {
    nextMemory.user.profession = nextProfession;
    learnedFacts.push(`profession: ${nextProfession}`);
  }
  const nextLanguagePreference = languagePreference != null ? languagePreference : nextMemory.preferences.languagePreference;
  if (nextLanguagePreference !== nextMemory.preferences.languagePreference && nextLanguagePreference) {
    nextMemory.preferences.languagePreference = nextLanguagePreference;
    learnedFacts.push(`language: ${nextLanguagePreference === "fr" ? "French" : "English"}`);
  }
  const nextResponseStyle = updateField(nextMemory.preferences.responseStyle, responseStyle);
  if (nextResponseStyle !== nextMemory.preferences.responseStyle && nextResponseStyle) {
    nextMemory.preferences.responseStyle = nextResponseStyle;
    learnedFacts.push(`reply style: ${nextResponseStyle}`);
  }
  const nextTonePreference = updateField(nextMemory.preferences.tonePreference, tonePreference);
  if (nextTonePreference !== nextMemory.preferences.tonePreference && nextTonePreference) {
    nextMemory.preferences.tonePreference = nextTonePreference;
    learnedFacts.push(`tone: ${nextTonePreference}`);
  }
  const nextHumorPreference = updateField(nextMemory.preferences.humorPreference, humorPreference);
  if (nextHumorPreference !== nextMemory.preferences.humorPreference && nextHumorPreference) {
    nextMemory.preferences.humorPreference = nextHumorPreference;
    learnedFacts.push(`humor: ${nextHumorPreference}`);
  }
  if (project) {
    const nextProjects = addUniqueValue(nextMemory.projectsInProgress, project);
    if (nextProjects.length !== nextMemory.projectsInProgress.length) {
      nextMemory.projectsInProgress = nextProjects;
      learnedFacts.push(`project: ${project}`);
    }
  }
  if (goal) {
    const nextGoals = addUniqueValue(nextMemory.currentGoals, goal);
    if (nextGoals.length !== nextMemory.currentGoals.length) {
      nextMemory.currentGoals = nextGoals;
      learnedFacts.push(`goal: ${goal}`);
    }
  }
  if (importantPreference) {
    const nextImportantInformation = addUniqueValue(nextMemory.importantInformation, importantPreference);
    if (nextImportantInformation.length !== nextMemory.importantInformation.length) {
      nextMemory.importantInformation = nextImportantInformation;
      learnedFacts.push(`important: ${importantPreference}`);
    }
  }
  return { memory: nextMemory, learnedFacts };
}
function countKnownMemoryItems(memory) {
  return [
    memory.user.name,
    memory.user.age,
    memory.user.location,
    memory.user.profession,
    memory.preferences.languagePreference,
    memory.preferences.responseStyle,
    memory.preferences.tonePreference,
    memory.preferences.humorPreference,
    ...memory.projectsInProgress,
    ...memory.currentGoals,
    ...memory.importantInformation
  ].filter(Boolean).length;
}
function getCyrDogeMemoryHighlights(memory, language) {
  const highlights = [];
  if (memory.user.name) highlights.push(language === "fr" ? `Nom: ${memory.user.name}` : `Name: ${memory.user.name}`);
  if (memory.projectsInProgress[0]) highlights.push(language === "fr" ? `Projet: ${memory.projectsInProgress[0]}` : `Project: ${memory.projectsInProgress[0]}`);
  if (memory.currentGoals[0]) highlights.push(language === "fr" ? `Objectif: ${memory.currentGoals[0]}` : `Goal: ${memory.currentGoals[0]}`);
  if (memory.preferences.languagePreference) highlights.push(language === "fr" ? `Langue: ${memory.preferences.languagePreference === "fr" ? "Français" : "Anglais"}` : `Language: ${memory.preferences.languagePreference === "fr" ? "French" : "English"}`);
  if (memory.importantInformation[0]) highlights.push(language === "fr" ? `Aime: ${memory.importantInformation[0]}` : `Likes: ${memory.importantInformation[0]}`);
  return highlights.slice(0, 5);
}
const cyrDogeProfileSrc = "https://studio-assets.supernova.io/files/ws/757243/9f6009d0241fda73d5e07a356ccc6c33825c2d1abb0e629d11579561e5f4e941.jpeg";
function AgentAvatar({
  className = "size-11"
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `flex shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-orange-200 bg-white dark:border-white/10 dark:bg-zinc-900 ${className}`, "data-forge-id": "forge-bprndr-46-4", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:46:4:57:10", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: cyrDogeProfileSrc, alt: "Aido Agent profile", loading: "eager", fetchPriority: "high", decoding: "async", referrerPolicy: "no-referrer", draggable: false, className: "h-full w-full object-cover", "data-forge-id": "forge-bprmn0-47-6", "data-component": "img", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:47:6:56:8" }) });
}
function formatRelativeMoment(timestamp, language) {
  try {
    return new Intl.DateTimeFormat(language === "fr" ? "fr-FR" : "en-US", {
      hour: "2-digit",
      minute: "2-digit",
      day: "2-digit",
      month: "short"
    }).format(new Date(timestamp));
  } catch (e) {
    return new Date(timestamp).toLocaleString();
  }
}
function formatLiveClock(timestamp) {
  return new Intl.DateTimeFormat("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(timestamp));
}
function useCyrDogeState(walletAddress) {
  const [messages, setMessages] = reactExports.useState(() => {
    const storedMessages = readStoredCyrDogeMessages();
    return storedMessages != null ? storedMessages : [createWelcomeMessage()];
  });
  const [memory, setMemory] = reactExports.useState(() => {
    var _a;
    return (_a = readStoredCyrDogeMemory()) != null ? _a : createEmptyCyrDogeMemory();
  });
  reactExports.useEffect(() => {
    if (!walletAddress) return;
    loadCyrDogeMemory(walletAddress).then((loaded) => {
      if (loaded) setMemory(loaded);
    });
  }, [walletAddress]);
  reactExports.useEffect(() => {
    try {
      window.localStorage.setItem(cyrDogeStorageKey, JSON.stringify(messages));
    } catch (e) {
      return;
    }
  }, [messages]);
  reactExports.useEffect(() => {
    if (!walletAddress) return;
    writeStoredCyrDogeMemory(walletAddress, memory).catch(() => {
    });
  }, [walletAddress, memory]);
  return {
    memory,
    messages,
    setMemory,
    setMessages
  };
}
function CyrDogeChat({
  isWalletConnected,
  walletAddress,
  onConnectWallet
}) {
  const {
    memory,
    messages,
    setMemory,
    setMessages
  } = useCyrDogeState(walletAddress);
  const [draft, setDraft] = reactExports.useState("");
  const [isReplying, setIsReplying] = reactExports.useState(false);
  const [simulation, setSimulation] = reactExports.useState(null);
  const [liveTime, setLiveTime] = reactExports.useState(() => Date.now());
  const viewportRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    var _a;
    (_a = viewportRef.current) == null ? void 0 : _a.scrollTo({
      top: viewportRef.current.scrollHeight,
      behavior: "smooth"
    });
  }, [messages, isReplying]);
  reactExports.useEffect(() => {
    const timer = window.setInterval(() => {
      setLiveTime(Date.now());
    }, 3e4);
    return () => {
      window.clearInterval(timer);
    };
  }, []);
  const totalUserMessages = reactExports.useMemo(() => messages.filter((message) => message.role === "user").length, [messages]);
  const rememberedItemsCount = reactExports.useMemo(() => countKnownMemoryItems(memory), [memory]);
  const currentLanguage = reactExports.useMemo(() => {
    var _a, _b;
    const latestUserMessage = [...messages].reverse().find((message) => message.role === "user");
    return (_b = (_a = latestUserMessage == null ? void 0 : latestUserMessage.language) != null ? _a : memory.preferences.languagePreference) != null ? _b : "en";
  }, [memory.preferences.languagePreference, messages]);
  const memoryHighlights = reactExports.useMemo(() => getCyrDogeMemoryHighlights(memory, currentLanguage), [currentLanguage, memory]);
  const lastInteractionMoment = reactExports.useMemo(() => formatRelativeMoment(memory.updatedAt, currentLanguage), [currentLanguage, memory.updatedAt]);
  const sendMessage = (content) => {
    const trimmedContent = content.trim();
    if (!trimmedContent || isReplying || !isWalletConnected) {
      return;
    }
    const language = detectChatLanguage(trimmedContent);
    const userMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      language,
      content: trimmedContent,
      createdAt: Date.now()
    };
    const memoryUpdate = updateCyrDogeMemory(memory, trimmedContent);
    setMemory(memoryUpdate.memory);
    setMessages((currentMessages) => [...currentMessages, userMessage]);
    setDraft("");
    setIsReplying(true);
    setSimulation(createCyrDogeSimulation(trimmedContent, language));
    window.setTimeout(() => {
      setMessages((currentMessages) => [...currentMessages, createAssistantReply(trimmedContent, currentMessages, {
        memory: memoryUpdate.memory,
        learnedFacts: memoryUpdate.learnedFacts
      })]);
      setIsReplying(false);
    }, 480);
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    sendMessage(draft);
  };
  const handleComposerKeyDown = (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      sendMessage(draft);
    }
  };
  const handleReset = () => {
    setMessages([createWelcomeMessage()]);
    setMemory(createEmptyCyrDogeMemory());
    setSimulation(null);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-6 xl:grid-cols-[0.88fr_1.12fr]", "data-forge-id": "forge-82fqlx-215-4", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:215:4:499:10", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 shadow-sm dark:border-white/10 dark:bg-white/5 dark:text-white", "data-forge-id": "forge-82fpv6-216-6", "data-component": "Card", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:216:6:349:13", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-82fp4f-217-8", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:217:8:233:21", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-3", "data-forge-id": "forge-y0y7yd-218-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:218:10:225:16", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-orange-100 text-orange-700 hover:bg-orange-100 dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-y0yuxy-219-12", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:219:12:221:20", children: "Standard English default" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-white text-zinc-800 hover:bg-white dark:border-white/10 dark:bg-zinc-900 dark:text-zinc-100 dark:hover:bg-zinc-900", "data-forge-id": "forge-y1e6mm-222-12", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:222:12:224:20", children: "10 FAQ memory starters" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "mt-4 flex items-center gap-3 text-2xl", "data-forge-id": "forge-y1gqko-226-10", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:226:10:229:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(AgentAvatar, { "data-forge-id": "forge-y1hdk9-227-12", "data-component": "AgentAvatar", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:227:12:227:27" }),
          "Aido Agent"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { className: "text-base leading-7 text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-y1wp8v-230-10", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:230:10:232:28", children: "Ask a question, get a response, and keep the conversation tied to Octopus Market, official platform facts, wallet-gated flows, and guided next steps." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-5", "data-forge-id": "forge-82ehdg-234-8", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:234:8:348:22", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-200 bg-orange-50 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-y1zw6i-235-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:235:10:255:16", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", "data-forge-id": "forge-y20j63-236-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:236:12:239:18", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Wallet, { className: "size-4 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-y2165o-237-14", "data-component": "Wallet", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:237:14:237:80" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-y21t57-238-14", "data-component": "p", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:238:14:238:104", children: "Utility unlock status" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm leading-6 text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-y2ghua-240-12", "data-component": "p", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:240:12:244:16", children: isWalletConnected ? `Aido Agent is unlocked with wallet ${formatWalletAddress(walletAddress)}.` : "Connect a Solana wallet to chat, save guided actions, and use the full Octopus Market utility layer." }),
          !isWalletConnected ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", className: "mt-4 rounded-2xl bg-orange-500 text-white hover:bg-orange-400", onClick: () => void onConnectWallet(), "data-forge-id": "forge-y2kbri-246-14", "data-component": "Button", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:246:14:253:23", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Wallet, { className: "size-4", "data-forge-id": "forge-y30xfa-251-16", "data-component": "Wallet", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:251:16:251:45" }),
            "Connect wallet to unlock Aido Agent"
          ] }) : null
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-200 bg-orange-50 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-y34rca-257-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:257:10:282:16", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3", "data-forge-id": "forge-y35ebv-258-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:258:12:267:18", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", "data-forge-id": "forge-y361bg-259-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:259:14:262:20", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Bot, { className: "size-4 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-y3k314-260-16", "data-component": "Bot", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:260:16:260:79" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-y3kq0n-261-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:261:16:261:106", children: "Platform access areas" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-y3lzzn-263-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:263:14:266:20", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Clock3, { className: "size-4 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-y3mmz8-264-16", "data-component": "Clock3", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:264:16:264:82" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "data-forge-id": "forge-y3n9yr-265-16", "data-component": "span", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:265:16:265:56", children: formatLiveClock(liveTime) })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 flex flex-wrap gap-2", "data-forge-id": "forge-y3p6x8-268-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:268:12:277:18", children: aidoAgentAccessAreas.map((workspace) => /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-white text-zinc-800 hover:bg-white dark:border-white/10 dark:bg-zinc-950 dark:text-zinc-100 dark:hover:bg-zinc-950", "data-forge-id": "forge-y43vmh-270-16", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:270:16:275:24", children: workspace }, workspace)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex items-center gap-2 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-y48zil-278-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:278:12:281:18", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Clock3, { className: "size-4 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-y49mi6-279-14", "data-component": "Clock3", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:279:14:279:80" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-y4no7s-280-14", "data-component": "span", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:280:14:280:68", children: [
              "Last memory sync: ",
              lastInteractionMoment
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-200 bg-white px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-y4q85s-284-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:284:10:304:16", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", "data-forge-id": "forge-y4qv5d-285-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:285:12:288:18", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Brain, { className: "size-4 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-y4ri4y-286-14", "data-component": "Brain", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:286:14:286:79" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-y4s54h-287-14", "data-component": "p", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:287:14:287:112", children: "Memory profile on this device" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-2 text-sm leading-6 text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-y4tf3h-289-12", "data-component": "p", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:289:12:291:16", children: [
            "Aido Agent currently remembers ",
            rememberedItemsCount,
            " useful detail",
            rememberedItemsCount === 1 ? "" : "s",
            ". New chat resets both the thread and the local memory profile for a clean English restart."
          ] }),
          memoryHighlights.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3 flex flex-wrap gap-2", "data-forge-id": "forge-y59drq-293-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:293:14:302:20", children: memoryHighlights.map((highlight) => /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-orange-50 text-zinc-800 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-zinc-100 dark:hover:bg-zinc-950", "data-forge-id": "forge-y5anqw-295-18", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:295:18:300:26", children: highlight }, highlight)) }) : null
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-200 bg-white px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-yhers5-306-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:306:10:331:16", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", "data-forge-id": "forge-yhferq-307-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:307:12:310:18", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquareQuote, { className: "size-4 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-yhg1rb-308-14", "data-component": "MessageSquareQuote", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:308:14:308:92" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-yhgoqu-309-14", "data-component": "p", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:309:14:309:100", children: "Stored Q&A series" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm leading-6 text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-yhvdfx-311-12", "data-component": "p", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:311:12:313:16", children: "These 10 built-in memory starters help users ask direct product questions and get consistent answers." }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 grid gap-3", "data-forge-id": "forge-yhxaei-314-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:314:12:330:18", children: aidoAgentStarterFaqs.map((faq, index) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", variant: "outline", className: "h-auto min-h-14 justify-start border-orange-200 bg-white px-4 py-3 text-left text-zinc-950 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900", onClick: () => sendMessage(faq.question), disabled: !isWalletConnected || isReplying, "data-forge-id": "forge-yhykdo-316-16", "data-component": "Button", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:316:16:328:25", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mr-3 inline-flex size-6 shrink-0 items-center justify-center rounded-full bg-orange-100 text-xs font-semibold text-orange-700 dark:bg-orange-500/15 dark:text-orange-300", "data-forge-id": "forge-yih301-324-18", "data-component": "span", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:324:18:326:25", children: index + 1 }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "whitespace-normal", "data-forge-id": "forge-yiizym-327-18", "data-component": "span", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:327:18:327:75", children: faq.question })
          ] }, faq.question)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-3 sm:grid-cols-2", "data-forge-id": "forge-yj08ln-333-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:333:10:347:16", children: cyrDogeQuickPrompts.map((prompt) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", variant: "outline", className: "h-auto min-h-14 justify-start border-orange-200 bg-white px-4 py-3 text-left text-zinc-950 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900", onClick: () => sendMessage(prompt), disabled: !isWalletConnected || isReplying, "data-forge-id": "forge-yj1ikt-335-14", "data-component": "Button", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:335:14:345:23", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "size-4 shrink-0 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-yjk176-343-16", "data-component": "Sparkles", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:343:16:343:93" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "whitespace-normal", "data-forge-id": "forge-yjko6p-344-16", "data-component": "span", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:344:16:344:67", children: prompt })
        ] }, prompt)) })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 shadow-sm dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-81th16-351-6", "data-component": "Card", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:351:6:498:13", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { "data-forge-id": "forge-81tgaf-352-8", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:352:8:376:21", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3", "data-forge-id": "forge-yk3tsd-353-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:353:10:375:16", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-yk4gry-354-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:354:12:361:18", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-2xl", "data-forge-id": "forge-yk53rj-355-14", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:355:14:355:75", children: "Live chat preview" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { className: "mt-2 text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-yk5qr2-356-14", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:356:14:360:32", children: totalUserMessages > 0 ? `${totalUserMessages} user message${totalUserMessages > 1 ? "s" : ""} saved on this device, plus ${rememberedItemsCount} memory item${rememberedItemsCount === 1 ? "" : "s"}` : "Ask about ClawdTrust, Launch Token, Prediction Market, wallet validation, or official Octopus Market details" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", "data-forge-id": "forge-ykmze9-362-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:362:12:374:18", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-orange-100 text-orange-700 hover:bg-orange-100 dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-yknmdu-363-14", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:363:14:365:22", children: "Platform-aware mode" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "ghost", className: "rounded-2xl px-3 text-zinc-600 hover:bg-orange-50 hover:text-zinc-950 dark:text-zinc-300 dark:hover:bg-white/5 dark:hover:text-white", onClick: handleReset, "data-forge-id": "forge-ykpjcf-366-14", "data-component": "Button", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:366:14:373:23", children: "New chat" })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4", "data-forge-id": "forge-81s2lw-377-8", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:377:8:497:22", children: [
        simulation ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-orange-200 bg-orange-50 p-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-ylb8wb-379-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:379:12:415:18", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-3", "data-forge-id": "forge-ylpalz-380-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:380:14:391:20", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-ylpxlk-381-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:381:16:387:22", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-white text-orange-700 hover:bg-white dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-ylqkl5-382-18", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:382:18:384:26", children: simulation.badge }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-ylshjq-385-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:385:18:385:112", children: simulation.title }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm leading-6 text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-ylt4j9-386-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:386:18:386:113", children: simulation.summary })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-orange-500 text-white hover:bg-orange-500 dark:border-orange-400/20 dark:bg-orange-500 dark:text-white dark:hover:bg-orange-500", "data-forge-id": "forge-yluei9-388-16", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:388:16:390:24", children: "Live preview" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 grid gap-3 sm:grid-cols-3", "data-forge-id": "forge-ymad6e-392-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:392:14:405:20", children: simulation.metrics.map((metric) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-200 bg-white px-4 py-4 dark:border-white/10 dark:bg-zinc-950", "data-forge-id": "forge-ymbn5k-394-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:394:18:403:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.18em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-yme74b-398-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:398:20:398:122", children: metric.label }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-base font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-ymeu3u-399-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:399:20:399:112", children: metric.value }),
            metric.delta ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-orange-600 dark:text-orange-300", "data-forge-id": "forge-yyd79m-401-22", "data-component": "p", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:401:22:401:105", children: metric.delta }) : null
          ] }, metric.label)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "mt-4 space-y-2 text-sm leading-6 text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-yyge6g-406-14", "data-component": "ul", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:406:14:413:19", children: simulation.bullets.map((bullet) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex gap-2", "data-forge-id": "forge-yyho5m-408-18", "data-component": "li", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:408:18:411:23", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mt-2 size-2 shrink-0 rounded-full bg-orange-500 dark:bg-orange-300", "data-forge-id": "forge-yyib5s-409-20", "data-component": "span", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:409:20:409:107" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "data-forge-id": "forge-yywcve-410-20", "data-component": "span", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:410:20:410:41", children: bullet })
          ] }, bullet)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-yyywsr-414-14", "data-component": "p", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:414:14:414:98", children: simulation.footer })
        ] }) : null,
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { ref: viewportRef, className: "max-h-[420px] space-y-4 overflow-y-auto rounded-3xl border border-orange-200 bg-orange-50/80 p-4 dark:border-white/10 dark:bg-black/20", "aria-live": "polite", "data-forge-id": "forge-yz1gqr-418-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:418:10:453:16", children: [
          messages.map((message) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `flex ${message.role === "assistant" ? "justify-start" : "justify-end"}`, "data-forge-id": "forge-yzipe4-424-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:424:14:443:20", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `max-w-[88%] rounded-3xl px-4 py-3 text-sm leading-7 shadow-sm ${message.role === "assistant" ? "border border-orange-200 bg-white text-zinc-800 dark:border-white/10 dark:bg-zinc-950 dark:text-zinc-100" : "bg-orange-500 text-white"}`, "data-forge-id": "forge-yzl9ca-428-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:428:16:442:22", children: [
            message.role === "assistant" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-2 flex items-center gap-2 text-xs font-medium uppercase tracking-[0.16em] text-orange-600 dark:text-orange-300", "data-forge-id": "forge-z03rza-436-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:436:20:439:26", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(AgentAvatar, { className: "size-4 rounded-full border-orange-200 dark:border-white/10", "data-forge-id": "forge-z04eyv-437-22", "data-component": "AgentAvatar", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:437:22:437:108" }),
              "Aido Agent"
            ] }) : null,
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "whitespace-pre-wrap", "data-forge-id": "forge-z0kdmd-441-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:441:18:441:74", children: message.content })
          ] }) }, message.id)),
          isReplying ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-start", "data-forge-id": "forge-z0o7jf-447-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:447:14:451:20", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-3xl border border-orange-200 bg-white px-4 py-3 text-sm text-zinc-700 shadow-sm dark:border-white/10 dark:bg-zinc-950 dark:text-zinc-200", "data-forge-id": "forge-z0ouj0-448-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:448:16:450:22", children: "Aido Agent is reviewing your message, memory, and Octopus Market context..." }) }) : null
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: handleSubmit, className: "space-y-3", "data-forge-id": "forge-z16q5m-455-10", "data-component": "form", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:455:10:485:17", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: draft, onChange: (event) => setDraft(event.target.value), onKeyDown: handleComposerKeyDown, rows: 4, placeholder: isWalletConnected ? "Ask a question about Octopus Market, Launch Token, Prediction Market, List My AI, ClawdTrust, the official token, or wallet validation" : "Connect a Solana wallet to unlock Aido Agent chat", className: "min-h-32 resize-none border-orange-200 bg-white text-zinc-950 placeholder:text-zinc-400 dark:border-white/10 dark:bg-white/5 dark:text-white dark:placeholder:text-zinc-500", disabled: !isWalletConnected || isReplying, "data-forge-id": "forge-z17d57-456-12", "data-component": "Textarea", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:456:12:468:14" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between", "data-forge-id": "forge-z1t2p5-469-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:469:12:484:18", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-z274et-470-14", "data-component": "p", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:470:14:474:18", children: isWalletConnected ? "Press Enter to send, or Shift + Enter for a new line." : "Connect first to unlock assistant replies and guided answers." }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: isWalletConnected ? "submit" : "button", className: "h-12 shrink-0 rounded-2xl bg-orange-500 px-6 text-white hover:bg-orange-400", disabled: isWalletConnected ? isReplying || draft.trim().length === 0 : false, onClick: isWalletConnected ? void 0 : () => void onConnectWallet(), "data-forge-id": "forge-z2abcg-475-14", "data-component": "Button", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:475:14:483:23", children: [
              isWalletConnected ? /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "size-4", "data-forge-id": "forge-z2rk1i-481-37", "data-component": "Send", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:481:37:481:64" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Wallet, { className: "size-4", "data-forge-id": "forge-z2rk43-481-67", "data-component": "Wallet", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:481:67:481:96" }),
              isWalletConnected ? "Send" : "Connect wallet"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "bg-orange-100 dark:bg-white/10", "data-forge-id": "forge-z2vdwr-487-10", "data-component": "Separator", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:487:10:487:66" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-200 bg-white px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-z2wnvt-489-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:489:10:496:16", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-z3aplh-490-12", "data-component": "p", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:490:12:490:109", children: "What changed in this version" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "mt-3 space-y-2 text-sm leading-6 text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-z3bcl0-491-12", "data-component": "ul", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:491:12:495:17", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { "data-forge-id": "forge-z3bzkl-492-14", "data-component": "li", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:492:14:492:95", children: "It now includes 10 built-in Q&A starters for consistent product answers." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { "data-forge-id": "forge-z3cmk4-493-14", "data-component": "li", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:493:14:493:115", children: "It keeps memory, answers free-form questions, and stays grounded in official platform facts." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("li", { "data-forge-id": "forge-z3d9jn-494-14", "data-component": "li", "data-source-pos": "src/components/octopus-market/cyrdoge-chat.tsx:494:14:494:106", children: "It shows live date and time context, plus wallet-gated access to the utility layer." })
          ] })
        ] })
      ] })
    ] })
  ] });
}
export {
  CyrDogeChat
};
