const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index.browser.esm-BU49YVkZ.js","assets/index-CE1PewnY.js","assets/index-C-7_nSR2.js","assets/index-s_vVowBZ.css"])))=>i.map(i=>d[i]);
import { al as getSolanaProvider, b2 as SOLANA_USDC_MINT, b3 as SOLANA_MAINNET_RPC_URLS, ak as __vitePreload } from "./index-C-7_nSR2.js";
import { b as bufferExports } from "./index-CE1PewnY.js";
const paymentStorageKey = "octopus-market-payment-requests-v1";
const defaultUsdPerSolFallback = 160;
const solanaRpcTimeoutMs = 1e4;
const solanaLamportsPerSol = 1e9;
const solTokenAddress = "So11111111111111111111111111111111111111112";
const memoProgramId = "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr";
const tokenProgramId = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA";
const associatedTokenProgramId = "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL";
const base58Alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
const base58Map = new Map(base58Alphabet.split("").map((character, index) => [character, index]));
let solanaWeb3ModulePromise = null;
function loadSolanaWeb3() {
  if (!solanaWeb3ModulePromise) {
    solanaWeb3ModulePromise = __vitePreload(() => import("./index.browser.esm-BU49YVkZ.js"), true ? __vite__mapDeps([0,1,2,3]) : void 0);
  }
  return solanaWeb3ModulePromise;
}
function readStoredTransactions() {
  if (typeof window === "undefined") {
    return [];
  }
  try {
    const rawValue = window.localStorage.getItem(paymentStorageKey);
    if (!rawValue) {
      return [];
    }
    const parsedValue = JSON.parse(rawValue);
    return Array.isArray(parsedValue) ? parsedValue : [];
  } catch (e) {
    return [];
  }
}
function listStoredTransactions() {
  return readStoredTransactions();
}
function writeStoredTransactions(transactions) {
  if (typeof window === "undefined") {
    return;
  }
  try {
    window.localStorage.setItem(paymentStorageKey, JSON.stringify(transactions));
  } catch (e) {
    return;
  }
}
function updateStoredTransaction(transactionId, updater) {
  var _a;
  const transactions = readStoredTransactions();
  const nextTransactions = transactions.map(
    (transaction) => transaction.id === transactionId ? updater(transaction) : transaction
  );
  writeStoredTransactions(nextTransactions);
  return (_a = nextTransactions.find((transaction) => transaction.id === transactionId)) != null ? _a : null;
}
function normalizeAmount(amount, decimals = 6) {
  return Number(amount.toFixed(decimals));
}
function randomHex(byteLength = 6) {
  var _a;
  if (typeof window !== "undefined" && ((_a = window.crypto) == null ? void 0 : _a.getRandomValues)) {
    const values = new Uint8Array(byteLength);
    window.crypto.getRandomValues(values);
    return Array.from(values, (value) => value.toString(16).padStart(2, "0")).join("");
  }
  return `${Math.random().toString(16).slice(2)}${Date.now().toString(16)}`.slice(0, byteLength * 2);
}
function escapeXml(value) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function buildOnChainMemo(paymentRequest) {
  var _a, _b, _c, _d, _e, _f;
  const params = new URLSearchParams();
  const metadata = (_a = paymentRequest.metadata) != null ? _a : {};
  params.set("v", "1");
  params.set("kind", paymentRequest.kind);
  params.set("requestId", paymentRequest.id);
  params.set("reference", paymentRequest.reference);
  params.set("wallet", paymentRequest.walletAddress);
  params.set("recipient", paymentRequest.recipient);
  params.set("totalPaidUsdc", String((_b = metadata.totalChargeUsdc) != null ? _b : paymentRequest.amount));
  params.set("amountUsdc", String((_e = (_d = (_c = metadata.stake) != null ? _c : metadata.feeAmountUsdc) != null ? _d : metadata.listingAmountUsdc) != null ? _e : paymentRequest.amount));
  params.set("reserveFeeUsdc", String((_f = metadata.reserveFee) != null ? _f : 0));
  if (paymentRequest.message) {
    params.set("title", paymentRequest.message);
  }
  if (typeof metadata.marketTitle === "string") {
    params.set("marketTitle", metadata.marketTitle);
  }
  if (typeof metadata.categoryLabel === "string") {
    params.set("categoryLabel", metadata.categoryLabel);
  }
  if (typeof metadata.selectionId === "string") {
    params.set("selectionId", metadata.selectionId);
  }
  if (typeof metadata.selectionLabel === "string") {
    params.set("selectionLabel", metadata.selectionLabel);
  }
  if (typeof metadata.marketId === "string") {
    params.set("marketId", metadata.marketId);
  }
  if (typeof metadata.tokenName === "string") {
    params.set("tokenName", metadata.tokenName);
  }
  if (typeof metadata.symbol === "string") {
    params.set("symbol", metadata.symbol);
  }
  if (typeof metadata.plan === "string") {
    params.set("plan", metadata.plan);
  }
  if (typeof metadata.launchOption === "string") {
    params.set("launchOption", metadata.launchOption);
  }
  if (typeof metadata.username === "string") {
    params.set("username", metadata.username);
  }
  return `om?${params.toString()}`;
}
function parseOnChainMemo(value) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s;
  if (!value.startsWith("om?")) {
    return null;
  }
  const params = new URLSearchParams(value.slice(3));
  return {
    kind: (_a = params.get("kind")) != null ? _a : "prediction",
    requestId: (_b = params.get("requestId")) != null ? _b : "",
    reference: (_c = params.get("reference")) != null ? _c : "",
    wallet: (_d = params.get("wallet")) != null ? _d : "",
    recipient: (_e = params.get("recipient")) != null ? _e : "",
    title: (_f = params.get("title")) != null ? _f : "",
    marketTitle: (_g = params.get("marketTitle")) != null ? _g : "",
    categoryLabel: (_h = params.get("categoryLabel")) != null ? _h : "",
    marketId: (_i = params.get("marketId")) != null ? _i : "",
    selectionId: (_j = params.get("selectionId")) != null ? _j : "",
    selectionLabel: (_k = params.get("selectionLabel")) != null ? _k : "",
    tokenName: (_l = params.get("tokenName")) != null ? _l : "",
    symbol: (_m = params.get("symbol")) != null ? _m : "",
    plan: (_n = params.get("plan")) != null ? _n : "",
    launchOption: (_o = params.get("launchOption")) != null ? _o : "",
    username: (_p = params.get("username")) != null ? _p : "",
    amountUsdc: Number((_q = params.get("amountUsdc")) != null ? _q : 0),
    reserveFeeUsdc: Number((_r = params.get("reserveFeeUsdc")) != null ? _r : 0),
    totalPaidUsdc: Number((_s = params.get("totalPaidUsdc")) != null ? _s : 0)
  };
}
function createMemoInstruction(web3, payer, memo) {
  const { PublicKey, TransactionInstruction } = web3;
  return new TransactionInstruction({
    programId: new PublicKey(memoProgramId),
    keys: [{ pubkey: payer, isSigner: true, isWritable: false }],
    data: bufferExports.Buffer.from(memo, "utf8")
  });
}
function hashValue(value) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}
function createPseudoQrPattern(value) {
  const size = 21;
  const matrix = Array.from({ length: size }, () => Array.from({ length: size }, () => false));
  const paintFinder = (startX, startY) => {
    for (let y = 0; y < 7; y += 1) {
      for (let x = 0; x < 7; x += 1) {
        const isOuter = x === 0 || x === 6 || y === 0 || y === 6;
        const isInner = x >= 2 && x <= 4 && y >= 2 && y <= 4;
        matrix[startY + y][startX + x] = isOuter || isInner;
      }
    }
  };
  paintFinder(0, 0);
  paintFinder(size - 7, 0);
  paintFinder(0, size - 7);
  let seed = hashValue(value);
  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const insideFinder = x < 7 && y < 7 || x >= size - 7 && y < 7 || x < 7 && y >= size - 7;
      if (insideFinder) {
        continue;
      }
      seed = Math.imul(seed ^ x + 11, 2654435761) >>> 0;
      const shouldPaint = (seed >>> (x + y) % 17 & 1) === 1;
      matrix[y][x] = shouldPaint;
    }
  }
  return matrix;
}
function encodeBase58(bytes) {
  const digits = [0];
  for (const byte of bytes) {
    let carry = byte;
    for (let index = 0; index < digits.length; index += 1) {
      const nextValue = digits[index] * 256 + carry;
      digits[index] = nextValue % 58;
      carry = Math.floor(nextValue / 58);
    }
    while (carry > 0) {
      digits.push(carry % 58);
      carry = Math.floor(carry / 58);
    }
  }
  let prefix = "";
  for (const byte of bytes) {
    if (byte !== 0) {
      break;
    }
    prefix += base58Alphabet[0];
  }
  return `${prefix}${digits.reverse().map((digit) => base58Alphabet[digit]).join("")}`;
}
function decodeBase58(value) {
  if (!value) {
    return new Uint8Array();
  }
  const bytes = [0];
  for (const character of value) {
    const alphabetIndex = base58Map.get(character);
    if (typeof alphabetIndex !== "number") {
      throw new Error("invalid-base58");
    }
    let carry = alphabetIndex;
    for (let index = 0; index < bytes.length; index += 1) {
      const nextValue = bytes[index] * 58 + carry;
      bytes[index] = nextValue & 255;
      carry = nextValue >> 8;
    }
    while (carry > 0) {
      bytes.push(carry & 255);
      carry >>= 8;
    }
  }
  for (const character of value) {
    if (character !== base58Alphabet[0]) {
      break;
    }
    bytes.push(0);
  }
  return Uint8Array.from(bytes.reverse());
}
function isValidReference(value) {
  try {
    return decodeBase58(value).length === 32;
  } catch (e) {
    return false;
  }
}
async function withTimeout(promise, timeoutMs, timeoutMessage) {
  return new Promise((resolve, reject) => {
    const timeoutId = window.setTimeout(() => reject(new Error(timeoutMessage)), timeoutMs);
    promise.then((value) => {
      window.clearTimeout(timeoutId);
      resolve(value);
    }).catch((error) => {
      window.clearTimeout(timeoutId);
      reject(error);
    });
  });
}
async function requestSolanaRpc(rpcUrl, method, params) {
  const response = await fetch(rpcUrl, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: `${method}-${Date.now()}`,
      method,
      params
    })
  });
  if (!response.ok) {
    throw new Error(`rpc-${response.status}`);
  }
  const payload = await response.json();
  if (payload.error) {
    throw new Error(payload.error.message || `${method}-failed`);
  }
  if (typeof payload.result === "undefined") {
    throw new Error(`${method}-missing-result`);
  }
  return payload.result;
}
function extractTransferLamports(transaction, recipient) {
  var _a, _b, _c, _d;
  const instructions = (_b = (_a = transaction == null ? void 0 : transaction.transaction) == null ? void 0 : _a.message) == null ? void 0 : _b.instructions;
  if (!Array.isArray(instructions)) {
    return 0;
  }
  for (const instruction of instructions) {
    const parsedInstruction = instruction == null ? void 0 : instruction.parsed;
    if (!parsedInstruction || parsedInstruction.type !== "transfer") {
      continue;
    }
    if (((_c = parsedInstruction.info) == null ? void 0 : _c.destination) !== recipient) {
      continue;
    }
    const lamports = (_d = parsedInstruction.info) == null ? void 0 : _d.lamports;
    if (typeof lamports === "number") {
      return lamports;
    }
    if (typeof lamports === "string") {
      const numericLamports = Number(lamports);
      if (Number.isFinite(numericLamports)) {
        return numericLamports;
      }
    }
  }
  return 0;
}
function uiAmountToBaseUnits(amount, decimals) {
  if (!Number.isFinite(amount) || amount <= 0) {
    return 0;
  }
  const normalizedAmount = amount.toFixed(decimals);
  const [wholePart, fractionalPart = ""] = normalizedAmount.split(".");
  const combined = `${wholePart}${fractionalPart.padEnd(decimals, "0")}`.replace(/^0+(?=\d)/, "");
  const numericValue = Number(combined);
  return Number.isFinite(numericValue) ? numericValue : 0;
}
function serializeU64(value) {
  const output = new Uint8Array(8);
  let remaining = BigInt(Math.max(0, Math.trunc(value)));
  for (let index = 0; index < 8; index += 1) {
    output[index] = Number(remaining & /* @__PURE__ */ BigInt("255"));
    remaining >>= /* @__PURE__ */ BigInt("8");
  }
  return output;
}
function findAssociatedTokenAddress(web3, owner, mint) {
  const { PublicKey } = web3;
  const tokenProgramPublicKey = new PublicKey(tokenProgramId);
  const associatedTokenProgramPublicKey = new PublicKey(associatedTokenProgramId);
  return PublicKey.findProgramAddressSync(
    [owner.toBuffer(), tokenProgramPublicKey.toBuffer(), mint.toBuffer()],
    associatedTokenProgramPublicKey
  )[0];
}
function createAssociatedTokenAccountInstruction(web3, payer, owner, mint, ata) {
  const { PublicKey, SystemProgram, TransactionInstruction } = web3;
  const associatedTokenProgramPublicKey = new PublicKey(associatedTokenProgramId);
  const tokenProgramPublicKey = new PublicKey(tokenProgramId);
  return new TransactionInstruction({
    programId: associatedTokenProgramPublicKey,
    keys: [
      { pubkey: payer, isSigner: true, isWritable: true },
      { pubkey: ata, isSigner: false, isWritable: true },
      { pubkey: owner, isSigner: false, isWritable: false },
      { pubkey: mint, isSigner: false, isWritable: false },
      { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
      { pubkey: tokenProgramPublicKey, isSigner: false, isWritable: false }
    ],
    data: bufferExports.Buffer.from([1])
  });
}
function createTransferCheckedInstruction(web3, source, destination, mint, owner, amountBaseUnits, decimals, reference) {
  const { PublicKey, TransactionInstruction } = web3;
  const serializedAmount = serializeU64(amountBaseUnits);
  const data = bufferExports.Buffer.alloc(10);
  data[0] = 12;
  bufferExports.Buffer.from(serializedAmount).copy(data, 1);
  data[9] = decimals;
  const keys = [
    { pubkey: source, isSigner: false, isWritable: true },
    { pubkey: mint, isSigner: false, isWritable: false },
    { pubkey: destination, isSigner: false, isWritable: true },
    { pubkey: owner, isSigner: true, isWritable: false }
  ];
  if (reference) {
    keys.push({ pubkey: reference, isSigner: false, isWritable: false });
  }
  return new TransactionInstruction({
    programId: new PublicKey(tokenProgramId),
    keys,
    data
  });
}
function extractTokenTransferBaseUnits(transaction, destinationTokenAccount, mint) {
  var _a, _b, _c, _d;
  const instructions = (_b = (_a = transaction == null ? void 0 : transaction.transaction) == null ? void 0 : _a.message) == null ? void 0 : _b.instructions;
  if (Array.isArray(instructions)) {
    for (const instruction of instructions) {
      const parsedInstruction = instruction == null ? void 0 : instruction.parsed;
      const info = parsedInstruction == null ? void 0 : parsedInstruction.info;
      if (!parsedInstruction || !info) {
        continue;
      }
      if (info.destination !== destinationTokenAccount) {
        continue;
      }
      if (typeof info.mint === "string" && info.mint !== mint) {
        continue;
      }
      const tokenAmount = info.tokenAmount;
      if (tokenAmount == null ? void 0 : tokenAmount.amount) {
        const numericAmount = Number(tokenAmount.amount);
        if (Number.isFinite(numericAmount)) {
          return numericAmount;
        }
      }
      if (typeof info.amount === "string") {
        const numericAmount = Number(info.amount);
        if (Number.isFinite(numericAmount)) {
          return numericAmount;
        }
      }
    }
  }
  const postTokenBalances = (_c = transaction == null ? void 0 : transaction.meta) == null ? void 0 : _c.postTokenBalances;
  if (Array.isArray(postTokenBalances)) {
    const recipientBalance = postTokenBalances.find(
      (balance) => balance.owner === destinationTokenAccount || balance.mint === mint
    );
    const amount = Number((_d = recipientBalance == null ? void 0 : recipientBalance.uiTokenAmount) == null ? void 0 : _d.amount);
    if (Number.isFinite(amount)) {
      return amount;
    }
  }
  return 0;
}
function updateValidatedTransaction(transactionId, signature, rpcUrl) {
  return updateStoredTransaction(transactionId, (transaction) => ({
    ...transaction,
    signature,
    rpcUrl: rpcUrl != null ? rpcUrl : transaction.rpcUrl,
    status: "validated",
    validatedAt: Date.now()
  }));
}
function extractMemoPayload(transaction) {
  var _a, _b, _c, _d;
  const instructions = (_b = (_a = transaction == null ? void 0 : transaction.transaction) == null ? void 0 : _a.message) == null ? void 0 : _b.instructions;
  if (!Array.isArray(instructions)) {
    return null;
  }
  for (const instruction of instructions) {
    const programId = typeof (instruction == null ? void 0 : instruction.programId) === "string" ? instruction.programId : typeof ((_c = instruction == null ? void 0 : instruction.programId) == null ? void 0 : _c.toString) === "function" ? instruction.programId.toString() : "";
    if (programId !== memoProgramId) {
      continue;
    }
    if (typeof (instruction == null ? void 0 : instruction.parsed) === "string") {
      return instruction.parsed;
    }
    if (typeof ((_d = instruction == null ? void 0 : instruction.parsed) == null ? void 0 : _d.memo) === "string") {
      return instruction.parsed.memo;
    }
    if (typeof (instruction == null ? void 0 : instruction.data) === "string") {
      try {
        return bufferExports.Buffer.from(decodeBase58(instruction.data)).toString("utf8");
      } catch (e) {
        continue;
      }
    }
  }
  return null;
}
function extractSignerWalletAddress(transaction) {
  var _a, _b, _c, _d, _e, _f;
  const accountKeys = (_b = (_a = transaction == null ? void 0 : transaction.transaction) == null ? void 0 : _a.message) == null ? void 0 : _b.accountKeys;
  if (!Array.isArray(accountKeys)) {
    return "";
  }
  const signerRecord = accountKeys.find((accountKey) => {
    if (typeof accountKey === "string") {
      return false;
    }
    return (accountKey == null ? void 0 : accountKey.signer) === true || (accountKey == null ? void 0 : accountKey.signer) === "true";
  });
  if (typeof (signerRecord == null ? void 0 : signerRecord.pubkey) === "string") {
    return signerRecord.pubkey;
  }
  if (typeof ((_c = signerRecord == null ? void 0 : signerRecord.pubkey) == null ? void 0 : _c.toString) === "function") {
    return signerRecord.pubkey.toString();
  }
  if (typeof accountKeys[0] === "string") {
    return accountKeys[0];
  }
  if (typeof ((_d = accountKeys[0]) == null ? void 0 : _d.pubkey) === "string") {
    return accountKeys[0].pubkey;
  }
  if (typeof ((_f = (_e = accountKeys[0]) == null ? void 0 : _e.pubkey) == null ? void 0 : _f.toString) === "function") {
    return accountKeys[0].pubkey.toString();
  }
  return "";
}
async function scanIncomingTreasuryPayments(recipientWallet, options) {
  var _a, _b;
  const limit = Math.max(10, Math.min((_a = options == null ? void 0 : options.limit) != null ? _a : 40, 100));
  const rpcErrors = [];
  const web3 = await loadSolanaWeb3();
  const { PublicKey } = web3;
  const recipientPublicKey = new PublicKey(recipientWallet);
  const mintPublicKey = new PublicKey(SOLANA_USDC_MINT);
  const recipientTokenAccount = findAssociatedTokenAddress(web3, recipientPublicKey, mintPublicKey).toString();
  for (const rpcUrl of SOLANA_MAINNET_RPC_URLS) {
    try {
      const signatures = await withTimeout(
        requestSolanaRpc(rpcUrl, "getSignaturesForAddress", [recipientTokenAccount, { limit }]),
        solanaRpcTimeoutMs,
        `scan-timeout-${rpcUrl}`
      );
      const discoveredPayments = [];
      for (const signatureRecord of signatures) {
        const signature = signatureRecord.signature;
        if (!signature) {
          continue;
        }
        const transaction = await withTimeout(
          requestSolanaRpc(rpcUrl, "getTransaction", [signature, { encoding: "jsonParsed", commitment: "confirmed", maxSupportedTransactionVersion: 0 }]),
          solanaRpcTimeoutMs,
          `scan-transaction-timeout-${rpcUrl}`
        ).catch(() => null);
        if (!transaction) {
          continue;
        }
        const transferredBaseUnits = extractTokenTransferBaseUnits(transaction, recipientTokenAccount, SOLANA_USDC_MINT);
        if (transferredBaseUnits <= 0) {
          continue;
        }
        const memoPayload = extractMemoPayload(transaction);
        const memo = memoPayload ? parseOnChainMemo(memoPayload) : null;
        const totalPaidUsdc = Number((transferredBaseUnits / 10 ** 6).toFixed(2));
        const amountUsdc = Number.isFinite(memo == null ? void 0 : memo.amountUsdc) && ((_b = memo == null ? void 0 : memo.amountUsdc) != null ? _b : 0) > 0 ? Number(memo.amountUsdc.toFixed(2)) : totalPaidUsdc;
        const reserveFeeUsdc = Number.isFinite(memo == null ? void 0 : memo.reserveFeeUsdc) ? Number(memo.reserveFeeUsdc.toFixed(2)) : Math.max(0, Number((totalPaidUsdc - amountUsdc).toFixed(2)));
        const flow = (memo == null ? void 0 : memo.kind) === "launch" || (memo == null ? void 0 : memo.kind) === "listing" || (memo == null ? void 0 : memo.kind) === "prediction" ? memo.kind : "prediction";
        const title = (memo == null ? void 0 : memo.marketTitle) || (memo == null ? void 0 : memo.tokenName) || (memo == null ? void 0 : memo.plan) || (memo == null ? void 0 : memo.title) || `${flow} payment`;
        discoveredPayments.push({
          signature,
          reference: (memo == null ? void 0 : memo.reference) || signature,
          paymentRequestId: (memo == null ? void 0 : memo.requestId) || signature,
          flow,
          title,
          subtitle: [memo == null ? void 0 : memo.selectionLabel, memo == null ? void 0 : memo.categoryLabel, memo == null ? void 0 : memo.launchOption, memo == null ? void 0 : memo.symbol].filter(Boolean).join(" · ") || void 0,
          categoryLabel: (memo == null ? void 0 : memo.categoryLabel) || void 0,
          marketId: (memo == null ? void 0 : memo.marketId) || void 0,
          selectionId: (memo == null ? void 0 : memo.selectionId) || void 0,
          selectionLabel: (memo == null ? void 0 : memo.selectionLabel) || void 0,
          username: (memo == null ? void 0 : memo.username) || void 0,
          userWallet: (memo == null ? void 0 : memo.wallet) || extractSignerWalletAddress(transaction),
          recipientWallet,
          amountUsdc,
          reserveFeeUsdc,
          totalPaidUsdc: Number(((memo == null ? void 0 : memo.totalPaidUsdc) && memo.totalPaidUsdc > 0 ? memo.totalPaidUsdc : totalPaidUsdc).toFixed(2)),
          createdAt: transaction.blockTime ? transaction.blockTime * 1e3 : signatureRecord.blockTime ? signatureRecord.blockTime * 1e3 : Date.now()
        });
      }
      return discoveredPayments;
    } catch (error) {
      rpcErrors.push(error instanceof Error ? error.message : `scan failed on ${rpcUrl}`);
    }
  }
  throw new Error(rpcErrors.join(" · ") || "incoming-payment-scan-failed");
}
async function sendDirectWalletTransfer(paymentRequest, payerAddress) {
  var _a;
  const provider = getSolanaProvider();
  if (!(provider == null ? void 0 : provider.signAndSendTransaction) && !(provider == null ? void 0 : provider.signTransaction)) {
    throw new Error("wallet-transaction-unsupported");
  }
  const endpointErrors = [];
  const web3 = await loadSolanaWeb3();
  const { Connection, PublicKey, SystemProgram, Transaction } = web3;
  const payerPublicKey = new PublicKey(payerAddress);
  const recipientPublicKey = new PublicKey(paymentRequest.recipient);
  const referencePublicKey = new PublicKey(paymentRequest.reference);
  const mintPublicKey = paymentRequest.currency === "USDC" ? new PublicKey(paymentRequest.tokenMint || SOLANA_USDC_MINT) : null;
  const tokenDecimals = paymentRequest.currency === "USDC" ? (_a = paymentRequest.tokenDecimals) != null ? _a : 6 : 9;
  for (const rpcUrl of SOLANA_MAINNET_RPC_URLS) {
    try {
      const connection = new Connection(rpcUrl, "confirmed");
      const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash("confirmed");
      const transaction = new Transaction({
        feePayer: payerPublicKey,
        recentBlockhash: blockhash
      });
      if (paymentRequest.currency === "USDC" && mintPublicKey) {
        const payerTokenAccount = findAssociatedTokenAddress(web3, payerPublicKey, mintPublicKey);
        const recipientTokenAccount = findAssociatedTokenAddress(web3, recipientPublicKey, mintPublicKey);
        const recipientAtaInfo = await connection.getAccountInfo(recipientTokenAccount, "confirmed");
        const memoPayload = paymentRequest.memo || buildOnChainMemo(paymentRequest);
        if (!recipientAtaInfo) {
          transaction.add(createAssociatedTokenAccountInstruction(web3, payerPublicKey, recipientPublicKey, mintPublicKey, recipientTokenAccount));
        }
        if (memoPayload) {
          transaction.add(createMemoInstruction(web3, payerPublicKey, memoPayload));
        }
        transaction.add(
          createTransferCheckedInstruction(
            web3,
            payerTokenAccount,
            recipientTokenAccount,
            mintPublicKey,
            payerPublicKey,
            uiAmountToBaseUnits(paymentRequest.amount, tokenDecimals),
            tokenDecimals,
            referencePublicKey
          )
        );
      } else {
        const lamports = Math.max(1, Math.round(paymentRequest.amount * solanaLamportsPerSol));
        const transferInstruction = SystemProgram.transfer({
          fromPubkey: payerPublicKey,
          toPubkey: recipientPublicKey,
          lamports
        });
        transferInstruction.keys.push({
          pubkey: referencePublicKey,
          isSigner: false,
          isWritable: false
        });
        transaction.add(transferInstruction);
      }
      const signature = provider.signAndSendTransaction ? (await provider.signAndSendTransaction(transaction, {
        maxRetries: 3,
        preflightCommitment: "confirmed"
      })).signature : await connection.sendRawTransaction((await provider.signTransaction(transaction)).serialize(), {
        maxRetries: 3,
        preflightCommitment: "confirmed"
      });
      await connection.confirmTransaction(
        {
          signature,
          blockhash,
          lastValidBlockHeight
        },
        "confirmed"
      );
      return { signature, rpcUrl };
    } catch (error) {
      endpointErrors.push(error instanceof Error ? error.message : `transfer failed on ${rpcUrl}`);
    }
  }
  throw new Error(endpointErrors.join(" · ") || "wallet-transfer-failed");
}
function openSolanaPaymentUrl(encodedUrl) {
  if (typeof window === "undefined" || typeof document === "undefined") {
    throw new Error("window-unavailable");
  }
  const anchor = document.createElement("a");
  anchor.href = encodedUrl;
  anchor.rel = "noreferrer noopener";
  anchor.style.display = "none";
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
}
async function pollReferenceOnChain(reference, timeoutMs = 45e3, intervalMs = 2500) {
  var _a;
  const startedAt = Date.now();
  while (Date.now() - startedAt < timeoutMs) {
    for (const rpcUrl of SOLANA_MAINNET_RPC_URLS) {
      try {
        const signatures = await withTimeout(
          requestSolanaRpc(rpcUrl, "getSignaturesForAddress", [reference, { limit: 5 }]),
          solanaRpcTimeoutMs,
          `reference-timeout-${rpcUrl}`
        );
        const signature = (_a = signatures[0]) == null ? void 0 : _a.signature;
        if (signature) {
          return { signature, rpcUrl };
        }
      } catch (e) {
        continue;
      }
    }
    await new Promise((resolve) => window.setTimeout(resolve, intervalMs));
  }
  throw new Error("reference-timeout");
}
function createQR(value) {
  const matrix = createPseudoQrPattern(value);
  const cellSize = 7;
  const qrSize = matrix.length * cellSize;
  const encodedLabel = escapeXml(value.slice(0, 54));
  const cells = matrix.flatMap(
    (row, y) => row.map(
      (filled, x) => filled ? `<rect x="${x * cellSize}" y="${y * cellSize}" width="${cellSize}" height="${cellSize}" rx="1" fill="#18181b" />` : ""
    )
  ).join("");
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="${qrSize}" height="${qrSize + 44}" viewBox="0 0 ${qrSize} ${qrSize + 44}">
      <rect width="100%" height="100%" rx="20" fill="#ffffff" />
      <rect x="0" y="0" width="${qrSize}" height="${qrSize}" rx="18" fill="#ffffff" />
      ${cells}
      <text x="${qrSize / 2}" y="${qrSize + 22}" text-anchor="middle" font-family="Arial, sans-serif" font-size="10" fill="#52525b">Scan or open in Phantom</text>
      <text x="${qrSize / 2}" y="${qrSize + 34}" text-anchor="middle" font-family="Arial, sans-serif" font-size="8" fill="#71717a">${encodedLabel}</text>
    </svg>
  `;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}
function createPaymentReference() {
  var _a;
  if (typeof window !== "undefined" && ((_a = window.crypto) == null ? void 0 : _a.getRandomValues)) {
    const bytes = new Uint8Array(32);
    window.crypto.getRandomValues(bytes);
    return encodeBase58(bytes);
  }
  const fallbackBytes = Uint8Array.from(Array.from({ length: 32 }, (_, index) => (index * 17 + Date.now()) % 256));
  return encodeBase58(fallbackBytes);
}
function encodeURL({ recipient, amount, reference, currency, tokenMint, tokenDecimals, label, message, memo }) {
  const params = new URLSearchParams();
  const decimals = currency === "USDC" ? tokenDecimals != null ? tokenDecimals : 6 : 9;
  params.set("amount", normalizeAmount(amount, decimals).toFixed(decimals));
  params.append("reference", reference);
  if (currency === "USDC" && tokenMint) {
    params.set("spl-token", tokenMint);
  }
  if (label) {
    params.set("label", label);
  }
  if (message) {
    params.set("message", message);
  }
  if (memo) {
    params.set("memo", memo);
  }
  return `solana:${recipient}?${params.toString()}`;
}
function parseURL(encodedUrl) {
  var _a, _b, _c, _d, _e, _f;
  const [schemePart, queryPart = ""] = encodedUrl.split("?");
  const recipient = schemePart.replace(/^solana:/i, "");
  const params = new URLSearchParams(queryPart);
  const amount = Number((_a = params.get("amount")) != null ? _a : 0);
  const tokenMint = (_b = params.get("spl-token")) != null ? _b : void 0;
  const currency = tokenMint ? "USDC" : "SOL";
  return {
    recipient,
    amount: Number.isFinite(amount) ? amount : 0,
    reference: (_c = params.get("reference")) != null ? _c : "",
    currency,
    tokenMint,
    tokenDecimals: currency === "USDC" ? 6 : 9,
    label: (_d = params.get("label")) != null ? _d : void 0,
    message: (_e = params.get("message")) != null ? _e : void 0,
    memo: (_f = params.get("memo")) != null ? _f : void 0
  };
}
function createTransfer(input) {
  var _a, _b, _c, _d;
  const reference = (_a = input.reference) != null ? _a : createPaymentReference();
  const currency = (_b = input.currency) != null ? _b : "SOL";
  const tokenMint = currency === "USDC" ? (_c = input.tokenMint) != null ? _c : SOLANA_USDC_MINT : void 0;
  const tokenDecimals = currency === "USDC" ? (_d = input.tokenDecimals) != null ? _d : 6 : 9;
  const amount = normalizeAmount(input.amount, tokenDecimals);
  const encodedUrl = encodeURL({
    recipient: input.recipient,
    amount,
    reference,
    currency,
    tokenMint,
    tokenDecimals,
    label: input.label,
    message: input.message,
    memo: input.memo
  });
  return {
    recipient: input.recipient,
    amount,
    reference,
    currency,
    tokenMint,
    tokenDecimals,
    label: input.label,
    message: input.message,
    memo: input.memo,
    encodedUrl
  };
}
function buildTransaction(input) {
  const transfer = createTransfer(input);
  const draftRequest = {
    id: `tx-${Date.now().toString(36).toUpperCase()}-${randomHex(5).toUpperCase()}`,
    kind: input.kind,
    walletAddress: input.walletAddress,
    metadata: input.metadata,
    qrCodeSrc: createQR(transfer.encodedUrl),
    signature: null,
    status: "created",
    createdAt: Date.now(),
    ...transfer
  };
  const memo = buildOnChainMemo(draftRequest);
  const request = {
    ...draftRequest,
    memo,
    encodedUrl: encodeURL({
      recipient: draftRequest.recipient,
      amount: draftRequest.amount,
      reference: draftRequest.reference,
      currency: draftRequest.currency,
      tokenMint: draftRequest.tokenMint,
      tokenDecimals: draftRequest.tokenDecimals,
      label: draftRequest.label,
      message: draftRequest.message,
      memo
    })
  };
  request.qrCodeSrc = createQR(request.encodedUrl);
  const nextTransactions = [request, ...readStoredTransactions()].slice(0, 120);
  writeStoredTransactions(nextTransactions);
  return request;
}
async function fetchTransaction(transactionId) {
  var _a;
  return (_a = readStoredTransactions().find((transaction) => transaction.id === transactionId)) != null ? _a : null;
}
async function fetchLiveSolPriceUsd() {
  var _a, _b, _c;
  try {
    const response = await fetch(`https://public-api.birdeye.so/defi/price?address=${solTokenAddress}`, {
      headers: {
        accept: "application/json",
        "x-chain": "solana"
      }
    });
    if (!response.ok) {
      throw new Error("sol-price-unavailable");
    }
    const payload = await response.json();
    const numericValue = Number((_c = (_a = payload.data) == null ? void 0 : _a.value) != null ? _c : (_b = payload.data) == null ? void 0 : _b.price);
    if (!Number.isFinite(numericValue) || numericValue <= 0) {
      throw new Error("sol-price-unavailable");
    }
    return numericValue;
  } catch (e) {
    return defaultUsdPerSolFallback;
  }
}
function convertUsdAmountToSol(usdAmount, solPriceUsd) {
  if (!Number.isFinite(usdAmount) || usdAmount <= 0 || !Number.isFinite(solPriceUsd) || solPriceUsd <= 0) {
    return 0;
  }
  return normalizeAmount(usdAmount / solPriceUsd, 9);
}
async function submitSolanaTransfer(paymentRequest) {
  const provider = getSolanaProvider();
  if (!(provider == null ? void 0 : provider.publicKey)) {
    throw new Error("wallet-unavailable");
  }
  const payerAddress = provider.publicKey.toString();
  if (payerAddress !== paymentRequest.walletAddress) {
    throw new Error("wallet-account-mismatch");
  }
  if (!isValidReference(paymentRequest.reference)) {
    throw new Error("invalid-payment-reference");
  }
  if (provider.signAndSendTransaction || provider.signTransaction) {
    const directTransfer = await sendDirectWalletTransfer(paymentRequest, payerAddress);
    const updatedRequest2 = updateStoredTransaction(paymentRequest.id, (transactionRecord) => ({
      ...transactionRecord,
      signature: directTransfer.signature,
      rpcUrl: directTransfer.rpcUrl,
      status: "signed"
    }));
    if (!updatedRequest2) {
      throw new Error("payment-request-missing");
    }
    return updatedRequest2;
  }
  openSolanaPaymentUrl(paymentRequest.encodedUrl);
  const foundReference = await pollReferenceOnChain(paymentRequest.reference);
  const updatedRequest = updateStoredTransaction(paymentRequest.id, (transactionRecord) => ({
    ...transactionRecord,
    signature: foundReference.signature,
    rpcUrl: foundReference.rpcUrl,
    status: "signed"
  }));
  if (!updatedRequest) {
    throw new Error("payment-request-missing");
  }
  return updatedRequest;
}
async function findReference(reference) {
  var _a, _b;
  const storedRequest = (_a = readStoredTransactions().find((transaction) => transaction.reference === reference)) != null ? _a : null;
  const shouldUseChainLookup = ((_b = storedRequest == null ? void 0 : storedRequest.metadata) == null ? void 0 : _b.onChainTransfer) === true || !storedRequest;
  if (shouldUseChainLookup && isValidReference(reference)) {
    try {
      const foundReference = await pollReferenceOnChain(reference, 18e3, 2e3);
      return {
        signature: foundReference.signature,
        reference,
        rpcUrl: foundReference.rpcUrl,
        request: storedRequest
      };
    } catch (e) {
      if (!storedRequest) {
        return null;
      }
    }
  }
  if (!storedRequest) {
    return null;
  }
  return {
    signature: storedRequest.signature,
    reference,
    rpcUrl: storedRequest.rpcUrl,
    request: storedRequest
  };
}
async function attachSignature(transactionId, signature) {
  return updateStoredTransaction(transactionId, (transaction) => ({
    ...transaction,
    signature,
    status: "signed"
  }));
}
async function validateTransfer(signature, criteria) {
  var _a, _b, _c, _d, _e, _f, _g;
  const transactions = readStoredTransactions();
  const normalizedCurrency = (_a = criteria.currency) != null ? _a : "SOL";
  const normalizedTokenMint = normalizedCurrency === "USDC" ? (_b = criteria.tokenMint) != null ? _b : SOLANA_USDC_MINT : void 0;
  const normalizedTokenDecimals = normalizedCurrency === "USDC" ? (_c = criteria.tokenDecimals) != null ? _c : 6 : 9;
  const matchingTransaction = transactions.find(
    (transaction) => transaction.reference === criteria.reference && transaction.recipient === criteria.recipient && transaction.currency === normalizedCurrency && Math.abs(transaction.amount - normalizeAmount(criteria.amount, normalizedTokenDecimals)) < 1e-9
  );
  const shouldUseChainValidation = ((_d = matchingTransaction == null ? void 0 : matchingTransaction.metadata) == null ? void 0 : _d.onChainTransfer) === true || !matchingTransaction;
  if (shouldUseChainValidation && isValidReference(criteria.reference)) {
    const rpcUrls = (matchingTransaction == null ? void 0 : matchingTransaction.rpcUrl) ? [matchingTransaction.rpcUrl, ...SOLANA_MAINNET_RPC_URLS.filter((rpcUrl) => rpcUrl !== matchingTransaction.rpcUrl)] : SOLANA_MAINNET_RPC_URLS;
    for (const rpcUrl of rpcUrls) {
      try {
        const transaction = await withTimeout(
          requestSolanaRpc(rpcUrl, "getTransaction", [signature, { encoding: "jsonParsed", commitment: "confirmed", maxSupportedTransactionVersion: 0 }]),
          solanaRpcTimeoutMs,
          `validation-timeout-${rpcUrl}`
        );
        const accountKeys = (_g = (_f = (_e = transaction == null ? void 0 : transaction.transaction) == null ? void 0 : _e.message) == null ? void 0 : _f.accountKeys) == null ? void 0 : _g.map(
          (accountKey) => {
            var _a2, _b2;
            return typeof accountKey === "string" ? accountKey : typeof (accountKey == null ? void 0 : accountKey.pubkey) === "string" ? accountKey.pubkey : (_b2 = (_a2 = accountKey == null ? void 0 : accountKey.pubkey) == null ? void 0 : _a2.toString) == null ? void 0 : _b2.call(_a2);
          }
        );
        if (!Array.isArray(accountKeys) || !accountKeys.includes(criteria.reference)) {
          continue;
        }
        if (normalizedCurrency === "USDC" && normalizedTokenMint) {
          const web3 = await loadSolanaWeb3();
          const { PublicKey } = web3;
          const recipientTokenAccount = findAssociatedTokenAddress(
            web3,
            new PublicKey(criteria.recipient),
            new PublicKey(normalizedTokenMint)
          ).toString();
          const transferredBaseUnits = extractTokenTransferBaseUnits(transaction, recipientTokenAccount, normalizedTokenMint);
          const expectedBaseUnits = uiAmountToBaseUnits(criteria.amount, normalizedTokenDecimals);
          if (transferredBaseUnits < expectedBaseUnits) {
            continue;
          }
        } else {
          const transferredLamports = extractTransferLamports(transaction, criteria.recipient);
          const expectedLamports = Math.max(1, Math.round(criteria.amount * solanaLamportsPerSol));
          if (transferredLamports < expectedLamports) {
            continue;
          }
        }
        if (!matchingTransaction) {
          return {
            id: signature,
            kind: "prediction",
            walletAddress: "",
            recipient: criteria.recipient,
            amount: criteria.amount,
            reference: criteria.reference,
            currency: normalizedCurrency,
            tokenMint: normalizedTokenMint,
            tokenDecimals: normalizedTokenDecimals,
            encodedUrl: "",
            qrCodeSrc: "",
            signature,
            status: "validated",
            createdAt: Date.now(),
            validatedAt: Date.now(),
            rpcUrl
          };
        }
        const updatedTransaction2 = updateValidatedTransaction(matchingTransaction.id, signature, rpcUrl);
        if (!updatedTransaction2) {
          throw new Error("payment-validation-failed");
        }
        return updatedTransaction2;
      } catch (e) {
        continue;
      }
    }
  }
  if (!matchingTransaction || matchingTransaction.signature !== signature) {
    throw new Error("payment-validation-failed");
  }
  const updatedTransaction = updateValidatedTransaction(matchingTransaction.id, signature, matchingTransaction.rpcUrl);
  if (!updatedTransaction) {
    throw new Error("payment-validation-failed");
  }
  return updatedTransaction;
}
function serializeSignature(signature) {
  let binary = "";
  signature.forEach((byte) => {
    binary += String.fromCharCode(byte);
  });
  if (typeof window !== "undefined" && typeof window.btoa === "function") {
    return window.btoa(binary);
  }
  return Array.from(signature, (byte) => byte.toString(16).padStart(2, "0")).join("");
}
export {
  attachSignature,
  buildTransaction,
  convertUsdAmountToSol,
  createPaymentReference,
  createQR,
  createTransfer,
  encodeURL,
  fetchLiveSolPriceUsd,
  fetchTransaction,
  findReference,
  listStoredTransactions,
  parseURL,
  scanIncomingTreasuryPayments,
  serializeSignature,
  submitSolanaTransfer,
  validateTransfer
};
