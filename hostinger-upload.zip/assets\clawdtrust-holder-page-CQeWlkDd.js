import { r as reactExports, j as jsxRuntimeExports, C as Card, a as CardHeader, B as Badge, b as CardTitle, z as CardDescription, e as CardContent, d as Button, a4 as Check, a5 as Copy, M as officialTokenAddress } from "./index-C-7_nSR2.js";
import { r as readStoredOctopusTokens, T as Table, a as TableHeader, b as TableRow, c as TableHead, d as TableBody, e as TableCell, C as ChartContainer, A as AreaChart, f as CartesianGrid, X as XAxis, Y as YAxis, g as ChartTooltip, h as Area } from "./solfair-launch-studio-lUi5hU6k.js";
import { D as Dialog, a as DialogContent, b as DialogHeader, c as DialogTitle, d as DialogDescription } from "./octopus-ai-listing-dialog-Cw8KzkBF.js";
import "./alert-KqzOsNqQ.js";
import "./textarea-6tc707H_.js";
import "./solana-pay-PUUwvoir.js";
import "./index-CE1PewnY.js";
import "./circle-check-DVTHR8mg.js";
import "./coins-Cw0iSkkx.js";
import "./signature-CN2G_ivN.js";
import "./send-DmexI6YH.js";
import "./sparkles-CaH_qrgu.js";
const octopusTokensStorageKey = "octopus-market-token-board-v3";
const officialDexScreenerPairAddress = "egi97rat7zrxrqvvv7edb5tvxzzxwgdh8vwvkgpfzdfc";
const officialVerifiedHolders = 28;
const officialTokenGoldBadgeSrc = "https://studio-assets.supernova.io/files/ws/757243/2f25ed55d146075e38472bdc708603004b4959dee3f03f4e93ea9bfca247f038.png";
const chartRangeOptions = ["1H", "6H", "24H", "7D"];
function isOfficialTrackedToken(token) {
  return token.contractAddress === officialTokenAddress || token.id === "clawdtrust";
}
function formatCompactContractAddress(value) {
  if (!value) return "Pending";
  if (value.length <= 10) return value;
  return `${value.slice(0, 5)}...${value.slice(-5)}`;
}
function getPriceFractionDigits(numericValue) {
  if (numericValue < 1e-4) return 8;
  if (numericValue < 0.01) return 6;
  if (numericValue < 1) return 5;
  return 4;
}
function formatUsdValue(value, mode = "market") {
  const numericValue = Number(value);
  if (!Number.isFinite(numericValue) || numericValue <= 0) return "";
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    notation: mode === "market" && numericValue >= 1e4 ? "compact" : "standard",
    minimumFractionDigits: mode === "price" ? getPriceFractionDigits(numericValue) : 2,
    maximumFractionDigits: mode === "price" ? getPriceFractionDigits(numericValue) : 2
  }).format(numericValue);
}
function parseFormattedUsdValue(value) {
  if (!value) return 0;
  const sanitizedValue = value.replace(/[^0-9.-]+/g, "");
  const numericValue = Number(sanitizedValue);
  return Number.isFinite(numericValue) ? numericValue : 0;
}
function formatHoldersValue(value) {
  const numericValue = Number(value);
  if (!Number.isFinite(numericValue) || numericValue < 0) return "Live sync";
  return new Intl.NumberFormat("en-US", {
    maximumFractionDigits: 0
  }).format(numericValue);
}
function parseHoldersNumber(value) {
  const numericValue = Number(typeof value === "string" ? value.replace(/,/g, "") : value);
  if (!Number.isFinite(numericValue) || numericValue < 0) return null;
  return numericValue;
}
function formatChartLabel(timestamp, range) {
  return new Intl.DateTimeFormat("en-US", range === "7D" ? {
    month: "short",
    day: "numeric"
  } : {
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(timestamp * 1e3));
}
function createFallbackChartPoints(basePrice, range = "24H") {
  const safePrice = basePrice > 0 ? basePrice : 1;
  const rangeConfig = range === "1H" ? {
    points: 12,
    stepSeconds: 60 * 5
  } : range === "6H" ? {
    points: 24,
    stepSeconds: 60 * 15
  } : range === "7D" ? {
    points: 28,
    stepSeconds: 60 * 60 * 6
  } : {
    points: 24,
    stepSeconds: 60 * 60
  };
  return Array.from({
    length: rangeConfig.points
  }, (_, index) => {
    const timestamp = Math.floor(Date.now() / 1e3) - (rangeConfig.points - 1 - index) * rangeConfig.stepSeconds;
    const wave = Math.sin(index / 2.6) * 0.035;
    const drift = (index - 12) * 18e-4;
    const close = Number((safePrice * (1 + wave + drift)).toFixed(6));
    return {
      timestamp,
      label: formatChartLabel(timestamp, range),
      close,
      high: Number((close * 1.012).toFixed(6)),
      low: Number((close * 0.988).toFixed(6)),
      volume: Number((safePrice * 12e3 * (1 + index / 12)).toFixed(2))
    };
  });
}
function findFirstNumericLikeValue(payload, candidateKeys) {
  if (!payload || typeof payload !== "object") return null;
  const normalizedKeys = new Set(candidateKeys.map((k) => k.replace(/[^a-z0-9]/gi, "").toLowerCase()));
  const visited = /* @__PURE__ */ new WeakSet();
  const search = (value) => {
    if (!value || typeof value !== "object") return null;
    if (visited.has(value)) return null;
    visited.add(value);
    if (Array.isArray(value)) {
      for (const item of value) {
        const m = search(item);
        if (m !== null) return m;
      }
      return null;
    }
    const record = value;
    for (const [key, entryValue] of Object.entries(record)) {
      const normalizedKey = key.replace(/[^a-z0-9]/gi, "").toLowerCase();
      if (normalizedKeys.has(normalizedKey) && (typeof entryValue === "string" || typeof entryValue === "number")) {
        const numericValue = Number(entryValue);
        if (Number.isFinite(numericValue) && numericValue > 0) return entryValue;
      }
      const nested = search(entryValue);
      if (nested !== null) return nested;
    }
    return null;
  };
  return search(payload);
}
async function fetchBirdeyeJson(path) {
  const response = await fetch(`https://api.dexscreener.com/latest/dex/pairs/solana/${path}`);
  if (!response.ok) throw new Error("dexscreener-request-failed");
  return response.json();
}
async function fetchDexScreenerTokenJson(tokenAddress) {
  const response = await fetch(`https://api.dexscreener.com/tokens/v1/solana/${tokenAddress}`);
  if (!response.ok) throw new Error("dexscreener-token-request-failed");
  return response.json();
}
function extractBirdeyeMetricValue(payload, metric) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i;
  if (payload && typeof payload === "object") {
    const pair = Array.isArray(payload.pairs) ? (_a = payload.pairs) == null ? void 0 : _a[0] : (_b = payload.pair) != null ? _b : payload;
    if (pair && typeof pair === "object") {
      if (metric === "price") return (_c = pair.priceUsd) != null ? _c : null;
      if (metric === "volume") return (_e = (_d = pair.volume) == null ? void 0 : _d.h24) != null ? _e : null;
      if (metric === "marketCap") {
        return (_i = (_h = (_f = pair.marketCap) != null ? _f : pair.fdv) != null ? _h : (_g = pair.liquidity) == null ? void 0 : _g.usd) != null ? _i : null;
      }
    }
  }
  if (metric === "price") return findFirstNumericLikeValue(payload, ["price", "priceUsd", "value", "currentPrice"]);
  if (metric === "volume") return findFirstNumericLikeValue(payload, ["v24hUSD", "volume24hUSD", "volume24h", "v24h", "volume"]);
  if (metric === "marketCap") return findFirstNumericLikeValue(payload, ["marketCap", "marketCapUsd", "mc", "fdv", "liquidity"]);
  return findFirstNumericLikeValue(payload, ["holders", "holder", "holderCount", "holdersCount", "holder_count"]);
}
function getBirdeyeTokenAddress(token) {
  var _a, _b;
  if (isOfficialTrackedToken(token)) return token.poolAddress || officialDexScreenerPairAddress;
  if (token.poolAddress) return token.poolAddress;
  const dexMatch = (_a = token.dexScreenerUrl) == null ? void 0 : _a.match(/\/solana\/([^/?#]+)/i);
  return (_b = dexMatch == null ? void 0 : dexMatch[1]) != null ? _b : "";
}
async function fetchBirdeyeChartPoints(tokenAddress, fallbackPrice, range = "24H") {
  var _a, _b, _c;
  try {
    const payload = await fetchBirdeyeJson(tokenAddress);
    const pair = Array.isArray(payload == null ? void 0 : payload.pairs) ? payload.pairs[0] : payload == null ? void 0 : payload.pair;
    const livePrice = Number((_a = pair == null ? void 0 : pair.priceUsd) != null ? _a : fallbackPrice) || fallbackPrice;
    const priceChangePercent = Number((_c = (_b = pair == null ? void 0 : pair.priceChange) == null ? void 0 : _b.h24) != null ? _c : 0);
    const driftRatio = Number.isFinite(priceChangePercent) ? priceChangePercent / 100 : 0;
    const chartPoints = createFallbackChartPoints(livePrice, range);
    if (chartPoints.length < 2) return chartPoints;
    return chartPoints.map((point, index) => {
      var _a2, _b2, _c2;
      const factor = chartPoints.length === 1 ? 1 : index / (chartPoints.length - 1);
      const close = Number((livePrice * (1 - driftRatio + driftRatio * factor)).toFixed(8));
      return {
        ...point,
        close,
        high: Number((close * 1.012).toFixed(8)),
        low: Number((close * 0.988).toFixed(8)),
        volume: Number((_c2 = (_b2 = (_a2 = pair == null ? void 0 : pair.volume) == null ? void 0 : _a2.h24) != null ? _b2 : point.volume) != null ? _c2 : 0)
      };
    });
  } catch (e) {
    return createFallbackChartPoints(fallbackPrice, range);
  }
}
async function fetchOfficialTokenHolders(token) {
  var _a, _b;
  if (!isOfficialTrackedToken(token)) return null;
  try {
    const tokenPayload = await fetchDexScreenerTokenJson(token.contractAddress || officialTokenAddress);
    const holderValue = extractBirdeyeMetricValue(tokenPayload, "holders");
    const parsedHolderValue = parseHoldersNumber(holderValue);
    if (parsedHolderValue !== null) return parsedHolderValue;
  } catch (e) {
    return (_a = parseHoldersNumber(token.holders)) != null ? _a : officialVerifiedHolders;
  }
  return (_b = parseHoldersNumber(token.holders)) != null ? _b : officialVerifiedHolders;
}
async function fetchLiveTokenMetrics(token) {
  const tokenAddress = getBirdeyeTokenAddress(token);
  if (!tokenAddress) return null;
  try {
    const overviewPayload = await fetchBirdeyeJson(tokenAddress);
    let priceValue = extractBirdeyeMetricValue(overviewPayload, "price");
    if (priceValue === null) {
      const pricePayload = await fetchBirdeyeJson(tokenAddress);
      priceValue = extractBirdeyeMetricValue(pricePayload, "price");
    }
    const fallbackPrice = Number(priceValue) || parseFormattedUsdValue(token.price) || 1;
    const chartPoints = await fetchBirdeyeChartPoints(tokenAddress, fallbackPrice, "24H");
    const liveHoldersCount = extractBirdeyeMetricValue(overviewPayload, "holders");
    const officialHoldersCount = await fetchOfficialTokenHolders(token);
    const holdersCount = liveHoldersCount != null ? liveHoldersCount : officialHoldersCount;
    return {
      price: formatUsdValue(priceValue, "price") || token.price,
      volume24h: formatUsdValue(extractBirdeyeMetricValue(overviewPayload, "volume"), "market") || token.volume24h,
      marketCap: formatUsdValue(extractBirdeyeMetricValue(overviewPayload, "marketCap"), "market") || token.marketCap,
      holders: formatHoldersValue(holdersCount) || token.holders,
      status: "Live",
      chartPoints,
      lastUpdatedLabel: new Intl.DateTimeFormat("en-US", {
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      }).format(/* @__PURE__ */ new Date())
    };
  } catch (e) {
    return null;
  }
}
function TokenChartTooltip({
  active,
  payload
}) {
  var _a;
  if (!active || !(payload == null ? void 0 : payload.length)) return null;
  const point = payload[0];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-200 bg-white px-3 py-2 shadow-lg dark:border-white/10 dark:bg-zinc-950", "data-forge-id": "forge-gtvw16-270-4", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:270:4:275:10", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-gtvvaf-271-6", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:271:6:271:88", children: (_a = point.payload) == null ? void 0 : _a.label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-gtvujq-272-6", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:272:6:274:10", children: formatUsdValue(point.value, "price") || "$0.000000" })
  ] });
}
function ClawdTrustHolderPage() {
  var _a, _b;
  const tokenMetricsRefreshMs = 2e4;
  const [octopusTokens, setOctopusTokens] = reactExports.useState(() => readStoredOctopusTokens());
  const [selectedTokenId, setSelectedTokenId] = reactExports.useState(() => {
    var _a2, _b2;
    return (_b2 = (_a2 = readStoredOctopusTokens()[0]) == null ? void 0 : _a2.id) != null ? _b2 : "clawdtrust";
  });
  const [isTokenDetailsOpen, setIsTokenDetailsOpen] = reactExports.useState(false);
  const [copiedContractId, setCopiedContractId] = reactExports.useState(null);
  const [selectedChartRange, setSelectedChartRange] = reactExports.useState("24H");
  const [selectedTokenChartOverride, setSelectedTokenChartOverride] = reactExports.useState([]);
  const [isChartRefreshing, setIsChartRefreshing] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      window.localStorage.setItem(octopusTokensStorageKey, JSON.stringify(octopusTokens));
    } catch (e) {
      return;
    }
  }, [octopusTokens]);
  reactExports.useEffect(() => {
    var _a2, _b2;
    if (!octopusTokens.some((token) => token.id === selectedTokenId)) {
      setSelectedTokenId((_b2 = (_a2 = octopusTokens[0]) == null ? void 0 : _a2.id) != null ? _b2 : "clawdtrust");
    }
  }, [octopusTokens, selectedTokenId]);
  const tokenRefreshKey = reactExports.useMemo(() => octopusTokens.map((t) => `${t.id}:${t.poolAddress}:${t.contractAddress}`).join("|"), [octopusTokens]);
  reactExports.useEffect(() => {
    if (typeof window === "undefined") return;
    let isCancelled = false;
    const refreshTokenMetrics = async () => {
      const nextSnapshots = await Promise.all(octopusTokens.map(async (token) => ({
        id: token.id,
        snapshot: isOfficialTrackedToken(token) || token.id === selectedTokenId ? await fetchLiveTokenMetrics(token) : null
      })));
      if (isCancelled) return;
      setOctopusTokens((currentTokens) => currentTokens.map((token) => {
        var _a2;
        const nextSnapshot = (_a2 = nextSnapshots.find((e) => e.id === token.id)) == null ? void 0 : _a2.snapshot;
        if (!nextSnapshot) return token;
        const mergedToken = {
          ...token,
          ...nextSnapshot
        };
        const hasChanged = mergedToken.price !== token.price || mergedToken.volume24h !== token.volume24h || mergedToken.marketCap !== token.marketCap || mergedToken.holders !== token.holders || mergedToken.status !== token.status;
        return hasChanged ? mergedToken : token;
      }));
    };
    void refreshTokenMetrics();
    const intervalId = window.setInterval(() => {
      if (!isCancelled) void refreshTokenMetrics();
    }, tokenMetricsRefreshMs);
    return () => {
      isCancelled = true;
      window.clearInterval(intervalId);
    };
  }, [selectedTokenId, tokenRefreshKey]);
  const selectedToken = (_a = octopusTokens.find((t) => t.id === selectedTokenId)) != null ? _a : octopusTokens[0];
  const baseSelectedTokenChartData = ((_b = selectedToken == null ? void 0 : selectedToken.chartPoints) == null ? void 0 : _b.length) ? selectedToken.chartPoints : createFallbackChartPoints(parseFormattedUsdValue(selectedToken == null ? void 0 : selectedToken.price) || 1, "24H");
  const selectedTokenChartData = selectedTokenChartOverride.length ? selectedTokenChartOverride : baseSelectedTokenChartData;
  const selectedTokenPriceDelta = selectedTokenChartData.length > 1 ? (selectedTokenChartData[selectedTokenChartData.length - 1].close - selectedTokenChartData[0].close) / selectedTokenChartData[0].close * 100 : 0;
  const selectedTokenIsPositive = selectedTokenPriceDelta >= 0;
  const dynamicTokenChartConfig = reactExports.useMemo(() => ({
    close: {
      label: "Price",
      color: selectedTokenIsPositive ? "#16a34a" : "#dc2626"
    }
  }), [selectedTokenIsPositive]);
  reactExports.useEffect(() => {
    var _a2;
    if (!selectedToken) {
      setSelectedTokenChartOverride([]);
      return;
    }
    let isCancelled = false;
    const fallbackPrice = parseFormattedUsdValue(selectedToken.price) || 1;
    setSelectedTokenChartOverride(selectedChartRange === "24H" && ((_a2 = selectedToken.chartPoints) == null ? void 0 : _a2.length) ? selectedToken.chartPoints : createFallbackChartPoints(fallbackPrice, selectedChartRange));
    const tokenAddress = getBirdeyeTokenAddress(selectedToken);
    if (!tokenAddress || !isTokenDetailsOpen) {
      setIsChartRefreshing(false);
      return;
    }
    setIsChartRefreshing(true);
    void fetchBirdeyeChartPoints(tokenAddress, fallbackPrice, selectedChartRange).then((points) => {
      if (!isCancelled) setSelectedTokenChartOverride(points);
    }).finally(() => {
      if (!isCancelled) setIsChartRefreshing(false);
    });
    return () => {
      isCancelled = true;
    };
  }, [isTokenDetailsOpen, selectedChartRange, selectedToken]);
  const renderSelectedTokenLiveDot = ({
    cx,
    cy,
    index
  }) => {
    if (typeof cx !== "number" || typeof cy !== "number" || typeof index !== "number" || index !== selectedTokenChartData.length - 1) return null;
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { cx, cy, r: 9, fill: "var(--color-close)", opacity: 0.18, className: "animate-ping" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { cx, cy, r: 5, fill: "var(--color-close)", fillOpacity: 0.28 }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { cx, cy, r: 3.5, fill: "var(--color-close)" })
    ] });
  };
  const handleCopyContract = async (token) => {
    var _a2;
    if (!token.contractAddress || typeof window === "undefined") return;
    try {
      if ((_a2 = navigator.clipboard) == null ? void 0 : _a2.writeText) {
        await navigator.clipboard.writeText(token.contractAddress);
      } else {
        const textArea = window.document.createElement("textarea");
        textArea.value = token.contractAddress;
        window.document.body.appendChild(textArea);
        textArea.select();
        window.document.execCommand("copy");
        window.document.body.removeChild(textArea);
      }
      setCopiedContractId(token.id);
      window.setTimeout(() => {
        setCopiedContractId((current) => current === token.id ? null : current);
      }, 1600);
    } catch (e) {
      setCopiedContractId(null);
    }
  };
  const handleOpenTokenChart = (token) => {
    setSelectedTokenId(token.id);
    setIsTokenDetailsOpen(true);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 shadow-[0_24px_80px_rgba(249,115,22,0.12)] transition-transform duration-500 md:[transform:perspective(1800px)_rotateX(2deg)] dark:border-white/10 dark:bg-white/5 dark:text-white dark:shadow-[0_28px_90px_rgba(0,0,0,0.35)]", "data-forge-id": "forge-gsur33-435-4", "data-component": "Card", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:435:4:733:11", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-gsuqcc-436-6", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:436:6:449:19", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-3", "data-forge-id": "forge-gsupll-437-8", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:437:8:444:14", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-orange-100 text-orange-700 hover:bg-orange-100 dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-nmn0wh-438-10", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:438:10:440:18", children: "Become a ClawdTrust Holder" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-white text-zinc-700 hover:bg-white dark:border-white/10 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-900", "data-forge-id": "forge-nm7p7t-441-10", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:441:10:443:18", children: "Internal launch board" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-2xl", "data-forge-id": "forge-gsu43g-445-8", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:445:8:445:90", children: "Tokens launched through Octopus Market" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { className: "text-base leading-7 text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-gsu3cr-446-8", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:446:8:448:26", children: "Follow the tracked token board with real-time Birdeye market sync, copy each contract address from the table, and open all token details only from the More info action." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4", "data-forge-id": "forge-gstk2r-451-6", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:451:6:732:20", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-orange-200 bg-orange-50/80 p-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-gstjc0-452-8", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:452:8:552:14", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4 rounded-2xl border border-orange-100 bg-white/80 px-4 py-3 text-sm text-zinc-600 dark:border-white/10 dark:bg-zinc-950/70 dark:text-zinc-300", "data-forge-id": "forge-nlmmne-453-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:453:10:455:16", children: "Use More info on any token row to open its extra details, live chart, and market information inside Octopus Market." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Table, { "data-forge-id": "forge-nlk2pa-457-10", "data-component": "Table", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:457:10:551:18", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableHeader, { "data-forge-id": "forge-nljfpp-458-12", "data-component": "TableHeader", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:458:12:469:26", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { className: "border-orange-200 dark:border-white/10", "data-forge-id": "forge-nlisq4-459-14", "data-component": "TableRow", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:459:14:468:25", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-nl4r0g-460-16", "data-component": "TableHead", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:460:16:460:89", children: "Token" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-nl440x-461-16", "data-component": "TableHead", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:461:16:461:90", children: "Ticker" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-nl3h1e-462-16", "data-component": "TableHead", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:462:16:462:89", children: "Price" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-nl2u1v-463-16", "data-component": "TableHead", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:463:16:463:94", children: "24h Volume" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-nl272c-464-16", "data-component": "TableHead", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:464:16:464:94", children: "Market Cap" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-nl1k2t-465-16", "data-component": "TableHead", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:465:16:465:91", children: "Holders" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-nl0x3a-466-16", "data-component": "TableHead", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:466:16:466:90", children: "Status" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TableHead, { className: "text-right text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-nl0a3r-467-16", "data-component": "TableHead", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:467:16:467:104", children: "More info" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TableBody, { "data-forge-id": "forge-nkkyf7-470-12", "data-component": "TableBody", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:470:12:550:24", children: octopusTokens.map((token) => {
            var _a2;
            const tokenChartData = ((_a2 = token.chartPoints) == null ? void 0 : _a2.length) ? token.chartPoints : createFallbackChartPoints(parseFormattedUsdValue(token.price) || 1);
            const tokenPriceDelta = tokenChartData.length > 1 ? (tokenChartData[tokenChartData.length - 1].close - tokenChartData[0].close) / tokenChartData[0].close * 100 : 0;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(TableRow, { className: `border-orange-100 transition hover:bg-white/80 dark:border-white/10 dark:hover:bg-zinc-950/70 ${token.id === (selectedToken == null ? void 0 : selectedToken.id) ? "bg-white shadow-[inset_0_0_0_1px_rgba(249,115,22,0.18)] dark:bg-zinc-950/70" : ""}`, "data-forge-id": "forge-nk0iu5-481-18", "data-component": "TableRow", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:481:18:547:29", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { "data-forge-id": "forge-njvexa-489-20", "data-component": "TableCell", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:489:20:520:32", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-start gap-2 text-left", "data-forge-id": "forge-njhd7m-490-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:490:22:519:28", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-njgq81-491-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:491:24:501:30", children: [
                  token.logoSrc ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: token.logoSrc, alt: `${token.name} logo`, className: "size-8 rounded-full border border-orange-200 object-cover dark:border-white/10", "data-forge-id": "forge-njfg8v-493-28", "data-component": "img", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:493:28:493:173" }) : null,
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2", "data-forge-id": "forge-nje69v-495-26", "data-component": "span", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:495:26:500:33", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "data-forge-id": "forge-njdjaa-496-28", "data-component": "span", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:496:28:496:53", children: token.name }),
                    isOfficialTrackedToken(token) ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: officialTokenGoldBadgeSrc, alt: `${token.name} gold verified`, className: "size-5 shrink-0 object-contain", "data-forge-id": "forge-njc9al-498-30", "data-component": "img", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:498:30:498:148" }) : null
                  ] })
                ] }),
                token.contractAddress ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-n7bz6z-503-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:503:26:517:32", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "max-w-[120px] break-all font-mono text-[10px] tracking-[0.08em] sm:max-w-none sm:text-xs sm:tracking-[0.12em]", "data-forge-id": "forge-n7bc7e-504-28", "data-component": "span", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:504:28:506:35", children: formatCompactContractAddress(token.contractAddress) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "ghost", size: "sm", onClick: (e) => {
                    e.stopPropagation();
                    void handleCopyContract(token);
                  }, className: "h-7 w-7 rounded-full border border-orange-200 p-0 text-zinc-600 hover:bg-orange-100 hover:text-zinc-950 dark:border-white/10 dark:text-zinc-300 dark:hover:bg-zinc-900 dark:hover:text-white", "aria-label": `Copy ${token.name} contract address`, "data-forge-id": "forge-n79f8t-507-28", "data-component": "Button", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:507:28:516:37", children: copiedContractId === token.id ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "size-3.5", "data-forge-id": "forge-n6qwj7-515-63", "data-component": "Check", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:515:63:515:93" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Copy, { className: "size-3.5", "data-forge-id": "forge-n6qwgj-515-96", "data-component": "Copy", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:515:96:515:125" }) })
                ] }) : null
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-n69nzh-521-20", "data-component": "TableCell", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:521:20:521:113", children: token.ticker }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: tokenPriceDelta >= 0 ? "text-emerald-600 dark:text-emerald-300" : "text-red-600 dark:text-red-300", "data-forge-id": "forge-n690zy-522-20", "data-component": "TableCell", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:522:20:524:32", children: token.price }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { "data-forge-id": "forge-n6741d-525-20", "data-component": "TableCell", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:525:20:525:60", children: token.volume24h }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { "data-forge-id": "forge-n66h1u-526-20", "data-component": "TableCell", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:526:20:526:60", children: token.marketCap }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { "data-forge-id": "forge-n65u2b-527-20", "data-component": "TableCell", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:527:20:527:58", children: token.holders }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { "data-forge-id": "forge-n6572s-528-20", "data-component": "TableCell", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:528:20:532:32", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-white text-orange-700 hover:bg-white dark:border-white/10 dark:bg-zinc-950 dark:text-orange-300 dark:hover:bg-zinc-950", "data-forge-id": "forge-n64k37-529-22", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:529:22:531:30", children: token.status }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(TableCell, { className: "text-right", "data-forge-id": "forge-n5olf2-533-20", "data-component": "TableCell", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:533:20:546:32", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: token.id === (selectedToken == null ? void 0 : selectedToken.id) ? "default" : "outline", size: "sm", onClick: () => handleOpenTokenChart(token), className: token.id === (selectedToken == null ? void 0 : selectedToken.id) ? "rounded-full bg-orange-500 px-4 text-white hover:bg-orange-400" : "rounded-full border-orange-200 bg-white px-4 text-zinc-900 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900", "data-forge-id": "forge-n5nyfh-534-22", "data-component": "Button", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:534:22:545:31", children: "More info" }) })
            ] }, token.id);
          }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm leading-6 text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-gs9p99-554-8", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:554:8:556:12", children: "New successful launches from the Create token flow are added here automatically, while the tracked ClawdTrust token keeps its official contract, live Dexscreener price reflection, live holders count, copyable contract address, and native market view inside the More info panel on Octopus Market." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open: isTokenDetailsOpen, onOpenChange: setIsTokenDetailsOpen, "data-forge-id": "forge-gs9ljs-559-8", "data-component": "Dialog", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:559:8:731:17", children: /* @__PURE__ */ jsxRuntimeExports.jsx(DialogContent, { className: "max-h-[90vh] overflow-y-auto border-orange-200 bg-white text-zinc-950 sm:max-w-5xl dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-n434mf-560-10", "data-component": "DialogContent", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:560:10:730:26", children: selectedToken ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { "data-forge-id": "forge-n417no-563-16", "data-component": "DialogHeader", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:563:16:586:31", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-3", "data-forge-id": "forge-n40ko3-564-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:564:18:571:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-orange-100 text-orange-700 hover:bg-orange-100 dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-n3zxnx-565-20", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:565:20:567:28", children: selectedToken.ticker }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-white text-zinc-700 hover:bg-white dark:border-white/10 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-900", "data-forge-id": "forge-n3y0pc-568-20", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:568:20:570:28", children: selectedToken.status })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex items-center gap-3", "data-forge-id": "forge-n3i21s-572-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:572:18:582:24", children: [
            selectedToken.logoSrc ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: selectedToken.logoSrc, alt: `${selectedToken.name} logo`, className: "size-10 rounded-full border border-orange-200 object-cover dark:border-white/10", "data-forge-id": "forge-n3gs21-574-22", "data-component": "img", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:574:22:574:184" }) : null,
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", "data-forge-id": "forge-n3fi31-576-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:576:20:581:26", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { className: "text-2xl text-zinc-950 dark:text-white", "data-forge-id": "forge-n3ev3g-577-22", "data-component": "DialogTitle", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:577:22:577:120", children: selectedToken.name }),
              isOfficialTrackedToken(selectedToken) ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: officialTokenGoldBadgeSrc, alt: `${selectedToken.name} gold verified`, className: "size-5 shrink-0 object-contain", "data-forge-id": "forge-n3dl4c-579-24", "data-component": "img", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:579:24:579:150" }) : null
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { className: "text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-n2xmgw-583-18", "data-component": "DialogDescription", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:583:18:585:38", children: "All extra information for this token stays inside the More info view, including the live chart and key token metrics." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-4", "data-forge-id": "forge-n2ufjb-588-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:588:16:651:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-3 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-n2tsjq-589-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:589:18:608:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-n2fqth-590-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:590:20:590:116", children: "Contract" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 flex items-center gap-2", "data-forge-id": "forge-n2f3ty-591-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:591:20:607:26", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "max-w-[150px] break-all font-mono text-[10px] font-medium leading-5 text-zinc-900 sm:max-w-none sm:text-xs dark:text-white", "data-forge-id": "forge-n2egud-592-22", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:592:22:594:26", children: formatCompactContractAddress(selectedToken.contractAddress) }),
              selectedToken.contractAddress ? /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "ghost", size: "sm", onClick: () => void handleCopyContract(selectedToken), className: "h-8 w-8 rounded-full border border-orange-200 p-0 text-zinc-600 hover:bg-orange-100 hover:text-zinc-950 dark:border-white/10 dark:text-zinc-300 dark:hover:bg-zinc-900 dark:hover:text-white", "aria-label": `Copy ${selectedToken.name} contract address`, "data-forge-id": "forge-n2bww7-596-24", "data-component": "Button", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:596:24:605:33", children: copiedContractId === selectedToken.id ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "size-3.5", "data-forge-id": "forge-mq9pps-604-67", "data-component": "Check", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:604:67:604:97" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Copy, { className: "size-3.5", "data-forge-id": "forge-5orapu-604-100", "data-component": "Copy", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:604:100:604:129" }) }) : null
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-3 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-mq6iwf-609-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:609:18:614:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-mpsh66-610-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:610:20:610:112", children: "Pool" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 break-all text-sm text-zinc-900 dark:text-white", "data-forge-id": "forge-mpru6n-611-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:611:20:613:24", children: selectedToken.poolAddress || "Pool address not added yet" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-3 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-mppa96-615-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:615:18:620:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-mpon90-616-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:616:20:616:119", children: "Live source" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-2 break-all text-sm text-zinc-900 dark:text-white", "data-forge-id": "forge-mpo09h-617-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:617:20:619:24", children: [
              "Autonomous ClawdTrust sync · Dexscreener pair feed refreshed every ",
              tokenMetricsRefreshMs / 1e3,
              " seconds"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-3 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-mp81lx-621-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:621:18:626:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-mp7elr-622-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:622:20:622:127", children: "Last market refresh" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 break-all text-sm text-zinc-900 dark:text-white", "data-forge-id": "forge-mp6rm8-623-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:623:20:625:24", children: selectedToken.lastUpdatedLabel || "Waiting for first live sync" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-3 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-mp47or-627-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:627:18:630:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-mp3kol-628-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:628:20:628:113", children: "Price" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-mp2xp2-629-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:629:20:629:117", children: selectedToken.price })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-3 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-moo90k-631-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:631:18:634:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-monm0e-632-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:632:20:632:118", children: "24h volume" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-momz0v-633-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:633:20:633:121", children: selectedToken.volume24h })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-3 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-molp2g-635-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:635:18:638:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-mol22a-636-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:636:20:636:118", children: "Market cap" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-mokf2r-637-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:637:20:637:121", children: selectedToken.marketCap })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-3 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-moj54c-639-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:639:18:642:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-mo53e3-640-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:640:20:640:115", children: "Holders" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-mo4gek-641-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:641:20:641:119", children: selectedToken.holders })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-3 dark:border-white/10 dark:bg-black/20 sm:col-span-2 xl:col-span-4", "data-forge-id": "forge-mo36g5-643-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:643:18:650:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-mo2jfz-644-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:644:20:644:130", children: "Immediate deployer buy" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 break-all text-sm text-zinc-900 dark:text-white", "data-forge-id": "forge-mo1wgg-645-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:645:20:649:24", children: selectedToken.initialBuyPercent && selectedToken.initialBuyPercent > 0 ? `${selectedToken.initialBuyPercent}% configured during launch` : "No immediate deployer buy configured" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "overflow-hidden rounded-3xl border border-orange-200 bg-white shadow-[0_30px_90px_rgba(15,23,42,0.18)] dark:border-white/10 dark:bg-zinc-950/80 dark:shadow-[0_36px_100px_rgba(0,0,0,0.4)]", "data-forge-id": "forge-mniqvb-654-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:654:16:727:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `border-b border-orange-100 px-5 py-5 dark:border-white/10 ${selectedTokenIsPositive ? "bg-[radial-gradient(circle_at_top_left,rgba(34,197,94,0.22),transparent_45%),linear-gradient(180deg,rgba(240,253,244,1),rgba(255,255,255,1))] dark:bg-[radial-gradient(circle_at_top_left,rgba(34,197,94,0.22),transparent_45%),linear-gradient(180deg,rgba(24,39,28,0.9),rgba(9,9,11,1))]" : "bg-[radial-gradient(circle_at_top_left,rgba(239,68,68,0.2),transparent_45%),linear-gradient(180deg,rgba(254,242,242,1),rgba(255,255,255,1))] dark:bg-[radial-gradient(circle_at_top_left,rgba(239,68,68,0.22),transparent_45%),linear-gradient(180deg,rgba(48,24,24,0.9),rgba(9,9,11,1))]"}`, "data-forge-id": "forge-mni3vq-655-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:655:18:698:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-4", "data-forge-id": "forge-mn1i7d-660-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:660:20:674:26", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-mn0v7s-661-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:661:22:667:28", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-mn0887-662-24", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:662:24:662:130", children: "Octopus live chart" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "mt-2 text-xl font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-mmzl8o-663-24", "data-component": "h4", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:663:24:663:136", children: [
                  selectedToken.ticker,
                  " market view"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm leading-6 text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-mmyy95-664-24", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:664:24:666:28", children: "Native chart on Octopus Market, powered by Dexscreener live pair data and the official Solscan token reference." })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-200 bg-white/80 px-4 py-3 text-right shadow-sm backdrop-blur dark:border-white/10 dark:bg-black/30", "data-forge-id": "forge-mmweb3-668-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:668:22:673:28", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-mmvrbi-669-24", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:669:24:669:120", children: "24h move" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: `mt-2 text-lg font-semibold ${selectedTokenIsPositive ? "text-emerald-600 dark:text-emerald-300" : "text-red-600 dark:text-red-300"}`, "data-forge-id": "forge-mmhplw-670-24", "data-component": "p", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:670:24:672:28", children: [
                  selectedTokenIsPositive ? "+" : "",
                  selectedTokenPriceDelta.toFixed(2),
                  "%"
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex flex-wrap items-center justify-between gap-3", "data-forge-id": "forge-mmeiod-675-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:675:20:697:26", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap items-center gap-2", "data-forge-id": "forge-mmdvos-676-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:676:22:692:28", children: chartRangeOptions.map((range) => /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", onClick: () => setSelectedChartRange(range), className: `h-9 rounded-full px-4 text-xs font-semibold ${selectedChartRange === range ? "border-orange-300 bg-orange-500 text-white hover:bg-orange-500 dark:border-orange-300 dark:bg-orange-500 dark:text-white" : "border-orange-200 bg-white text-zinc-900 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900"}`, "data-forge-id": "forge-mmclpm-678-26", "data-component": "Button", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:678:26:690:35", children: range }, range)) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-mlc7gn-693-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:693:22:696:28", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `size-2 rounded-full ${selectedTokenIsPositive ? "bg-emerald-500" : "bg-red-500"} animate-pulse`, "data-forge-id": "forge-mlbkh2-694-24", "data-component": "span", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:694:24:694:141" }),
                isChartRefreshing ? "Refreshing live price path" : "Live price path synced"
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-white p-4 dark:bg-zinc-950", "data-forge-id": "forge-ml8dk6-699-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:699:18:726:24", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChartContainer, { config: dynamicTokenChartConfig, className: "h-[360px] w-full", "data-forge-id": "forge-m9andc-700-20", "data-component": "ChartContainer", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:700:20:725:37", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(AreaChart, { data: selectedTokenChartData, margin: {
            left: 12,
            right: 12,
            top: 10,
            bottom: 0
          }, "data-forge-id": "forge-m9a0dr-701-22", "data-component": "AreaChart", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:701:22:724:34", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("defs", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("linearGradient", { id: "clawdtrust-chart", x1: "0", y1: "0", x2: "0", y2: "1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "5%", stopColor: "var(--color-close)", stopOpacity: 0.35 }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "95%", stopColor: "var(--color-close)", stopOpacity: 0.02 })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CartesianGrid, { vertical: false, strokeDasharray: "3 3", "data-forge-id": "forge-m95jh0-708-24", "data-component": "CartesianGrid", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:708:24:708:80" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(XAxis, { dataKey: "label", tickLine: false, axisLine: false, minTickGap: 28, "data-forge-id": "forge-m94whh-709-24", "data-component": "XAxis", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:709:24:709:99" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(YAxis, { tickLine: false, axisLine: false, width: 92, tickFormatter: (v) => formatUsdValue(v, "price") || "$0.000000", "data-forge-id": "forge-m8qurv-710-24", "data-component": "YAxis", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:710:24:710:143" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ChartTooltip, { cursor: {
              stroke: "var(--color-close)",
              strokeOpacity: 0.28,
              strokeWidth: 1.5
            }, content: /* @__PURE__ */ jsxRuntimeExports.jsx(TokenChartTooltip, { "data-forge-id": "forge-m8oxse-713-35", "data-component": "TokenChartTooltip", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:713:35:713:56" }), "data-forge-id": "forge-m8q7sc-711-24", "data-component": "ChartTooltip", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:711:24:714:26" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Area, { type: "monotone", dataKey: "close", stroke: "var(--color-close)", strokeWidth: 2.5, fill: "url(#clawdtrust-chart)", dot: renderSelectedTokenLiveDot, isAnimationActive: true, "data-forge-id": "forge-m8nnu8-715-24", "data-component": "Area", "data-source-pos": "src/components/octopus-market/clawdtrust-holder-page.tsx:715:24:723:26" })
          ] }) }) })
        ] })
      ] }) : null }) })
    ] })
  ] });
}
export {
  ClawdTrustHolderPage
};
