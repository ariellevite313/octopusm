import { c as createLucideIcon, aQ as useCallbackRef$1, r as reactExports, aC as useComposedRefs, j as jsxRuntimeExports, aA as Primitive, aE as composeEventHandlers, aR as dispatchDiscreteCustomEvent, aS as useLayoutEffect2, aT as reactDomExports, aU as __assign, aV as __rest, aW as __spreadArray, ay as useControllableState, aX as useId, aF as Presence, aG as createContextScope, aY as createSlot, aw as cn, a0 as X, aZ as getDefaultListingSubmissionProfile, B as Badge, d as Button, I as Input, C as Card, e as CardContent, ae as paymentTokenSymbol, A as Separator, W as Wallet, S as ShieldCheck, al as getSolanaProvider, am as solanaUsdcMintAddress, K as solanaPaymentAddress, w as appendAIListingSubmission } from "./index-C-7_nSR2.js";
import { L as LoaderCircle, A as Alert, a as AlertTitle, b as AlertDescription } from "./alert-KqzOsNqQ.js";
import { T as Textarea } from "./textarea-6tc707H_.js";
import { buildTransaction, submitSolanaTransfer, findReference, validateTransfer, fetchTransaction } from "./solana-pay-PUUwvoir.js";
const __iconNode$2 = [
  ["path", { d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z", key: "1rqfz7" }],
  ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
  ["path", { d: "M10 9H8", key: "b1mrlr" }],
  ["path", { d: "M16 13H8", key: "t4e002" }],
  ["path", { d: "M16 17H8", key: "z1uh3a" }]
];
const FileText = createLucideIcon("file-text", __iconNode$2);
const __iconNode$1 = [
  ["path", { d: "M16 5h6", key: "1vod17" }],
  ["path", { d: "M19 2v6", key: "4bpg5p" }],
  ["path", { d: "M21 11.5V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7.5", key: "1ue2ih" }],
  ["path", { d: "m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21", key: "1xmnt7" }],
  ["circle", { cx: "9", cy: "9", r: "2", key: "af1f0g" }]
];
const ImagePlus = createLucideIcon("image-plus", __iconNode$1);
const __iconNode = [
  [
    "path",
    { d: "M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z", key: "q3az6g" }
  ],
  ["path", { d: "M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8", key: "1h4pet" }],
  ["path", { d: "M12 17.5v-11", key: "1jc1ny" }]
];
const Receipt = createLucideIcon("receipt", __iconNode);
function useEscapeKeydown(onEscapeKeyDownProp, ownerDocument = globalThis == null ? void 0 : globalThis.document) {
  const onEscapeKeyDown = useCallbackRef$1(onEscapeKeyDownProp);
  reactExports.useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        onEscapeKeyDown(event);
      }
    };
    ownerDocument.addEventListener("keydown", handleKeyDown, { capture: true });
    return () => ownerDocument.removeEventListener("keydown", handleKeyDown, { capture: true });
  }, [onEscapeKeyDown, ownerDocument]);
}
var DISMISSABLE_LAYER_NAME = "DismissableLayer";
var CONTEXT_UPDATE = "dismissableLayer.update";
var POINTER_DOWN_OUTSIDE = "dismissableLayer.pointerDownOutside";
var FOCUS_OUTSIDE = "dismissableLayer.focusOutside";
var originalBodyPointerEvents;
var DismissableLayerContext = reactExports.createContext({
  layers: /* @__PURE__ */ new Set(),
  layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
  branches: /* @__PURE__ */ new Set(),
  // Outside elements that belong to a layer's own dismiss affordance (eg, a
  // dialog overlay). Pressing them should dismiss the layer regardless of
  // whether or not they stop propagation.
  //
  // See https://github.com/radix-ui/primitives/issues/3346
  dismissableSurfaces: /* @__PURE__ */ new Set()
});
var DismissableLayer = reactExports.forwardRef(
  (props, forwardedRef) => {
    var _a;
    const {
      disableOutsidePointerEvents = false,
      deferPointerDownOutside = false,
      onEscapeKeyDown,
      onPointerDownOutside,
      onFocusOutside,
      onInteractOutside,
      onDismiss,
      ...layerProps
    } = props;
    const context = reactExports.useContext(DismissableLayerContext);
    const [node, setNode] = reactExports.useState(null);
    const ownerDocument = (_a = node == null ? void 0 : node.ownerDocument) != null ? _a : globalThis == null ? void 0 : globalThis.document;
    const [, force] = reactExports.useState({});
    const composedRefs = useComposedRefs(forwardedRef, (node2) => setNode(node2));
    const layers = Array.from(context.layers);
    const [highestLayerWithOutsidePointerEventsDisabled] = [...context.layersWithOutsidePointerEventsDisabled].slice(-1);
    const highestLayerWithOutsidePointerEventsDisabledIndex = layers.indexOf(highestLayerWithOutsidePointerEventsDisabled);
    const index = node ? layers.indexOf(node) : -1;
    const isBodyPointerEventsDisabled = context.layersWithOutsidePointerEventsDisabled.size > 0;
    const isPointerEventsEnabled = index >= highestLayerWithOutsidePointerEventsDisabledIndex;
    const isDeferredPointerDownOutsideRef = reactExports.useRef(false);
    const pointerDownOutside = usePointerDownOutside(
      (event) => {
        const target = event.target;
        if (!(target instanceof Node)) {
          return;
        }
        const isPointerDownOnBranch = [...context.branches].some(
          (branch) => branch.contains(target)
        );
        if (!isPointerEventsEnabled || isPointerDownOnBranch) return;
        onPointerDownOutside == null ? void 0 : onPointerDownOutside(event);
        onInteractOutside == null ? void 0 : onInteractOutside(event);
        if (!event.defaultPrevented) onDismiss == null ? void 0 : onDismiss();
      },
      {
        ownerDocument,
        deferPointerDownOutside,
        isDeferredPointerDownOutsideRef,
        dismissableSurfaces: context.dismissableSurfaces
      }
    );
    const focusOutside = useFocusOutside((event) => {
      if (deferPointerDownOutside && isDeferredPointerDownOutsideRef.current) {
        return;
      }
      const target = event.target;
      const isFocusInBranch = [...context.branches].some((branch) => branch.contains(target));
      if (isFocusInBranch) return;
      onFocusOutside == null ? void 0 : onFocusOutside(event);
      onInteractOutside == null ? void 0 : onInteractOutside(event);
      if (!event.defaultPrevented) onDismiss == null ? void 0 : onDismiss();
    }, ownerDocument);
    useEscapeKeydown((event) => {
      const isHighestLayer = index === context.layers.size - 1;
      if (!isHighestLayer) return;
      onEscapeKeyDown == null ? void 0 : onEscapeKeyDown(event);
      if (!event.defaultPrevented && onDismiss) {
        event.preventDefault();
        onDismiss();
      }
    }, ownerDocument);
    reactExports.useEffect(() => {
      if (!node) return;
      if (disableOutsidePointerEvents) {
        if (context.layersWithOutsidePointerEventsDisabled.size === 0) {
          originalBodyPointerEvents = ownerDocument.body.style.pointerEvents;
          ownerDocument.body.style.pointerEvents = "none";
        }
        context.layersWithOutsidePointerEventsDisabled.add(node);
      }
      context.layers.add(node);
      dispatchUpdate();
      return () => {
        if (disableOutsidePointerEvents) {
          context.layersWithOutsidePointerEventsDisabled.delete(node);
          if (context.layersWithOutsidePointerEventsDisabled.size === 0) {
            ownerDocument.body.style.pointerEvents = originalBodyPointerEvents;
          }
        }
      };
    }, [node, ownerDocument, disableOutsidePointerEvents, context]);
    reactExports.useEffect(() => {
      return () => {
        if (!node) return;
        context.layers.delete(node);
        context.layersWithOutsidePointerEventsDisabled.delete(node);
        dispatchUpdate();
      };
    }, [node, context]);
    reactExports.useEffect(() => {
      const handleUpdate = () => force({});
      document.addEventListener(CONTEXT_UPDATE, handleUpdate);
      return () => document.removeEventListener(CONTEXT_UPDATE, handleUpdate);
    }, []);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Primitive.div,
      {
        ...layerProps,
        ref: composedRefs,
        style: {
          pointerEvents: isBodyPointerEventsDisabled ? isPointerEventsEnabled ? "auto" : "none" : void 0,
          ...props.style
        },
        onFocusCapture: composeEventHandlers(props.onFocusCapture, focusOutside.onFocusCapture),
        onBlurCapture: composeEventHandlers(props.onBlurCapture, focusOutside.onBlurCapture),
        onPointerDownCapture: composeEventHandlers(
          props.onPointerDownCapture,
          pointerDownOutside.onPointerDownCapture
        )
      }
    );
  }
);
DismissableLayer.displayName = DISMISSABLE_LAYER_NAME;
var BRANCH_NAME = "DismissableLayerBranch";
var DismissableLayerBranch = reactExports.forwardRef((props, forwardedRef) => {
  const context = reactExports.useContext(DismissableLayerContext);
  const ref = reactExports.useRef(null);
  const composedRefs = useComposedRefs(forwardedRef, ref);
  reactExports.useEffect(() => {
    const node = ref.current;
    if (node) {
      context.branches.add(node);
      return () => {
        context.branches.delete(node);
      };
    }
  }, [context.branches]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Primitive.div, { ...props, ref: composedRefs });
});
DismissableLayerBranch.displayName = BRANCH_NAME;
function useDismissableLayerSurface() {
  const context = reactExports.useContext(DismissableLayerContext);
  const [node, setNode] = reactExports.useState(null);
  reactExports.useEffect(() => {
    if (!node) {
      return;
    }
    context.dismissableSurfaces.add(node);
    return () => {
      context.dismissableSurfaces.delete(node);
    };
  }, [node, context.dismissableSurfaces]);
  return setNode;
}
function usePointerDownOutside(onPointerDownOutside, args) {
  const {
    ownerDocument = globalThis == null ? void 0 : globalThis.document,
    deferPointerDownOutside = false,
    isDeferredPointerDownOutsideRef,
    dismissableSurfaces
  } = args;
  const handlePointerDownOutside = useCallbackRef$1(onPointerDownOutside);
  const isPointerInsideReactTreeRef = reactExports.useRef(false);
  const isPointerDownOutsideRef = reactExports.useRef(false);
  const interceptedOutsideInteractionEventsRef = reactExports.useRef(/* @__PURE__ */ new Map());
  const handleClickRef = reactExports.useRef(() => {
  });
  reactExports.useEffect(() => {
    function resetOutsideInteraction() {
      isPointerDownOutsideRef.current = false;
      isDeferredPointerDownOutsideRef.current = false;
      interceptedOutsideInteractionEventsRef.current.clear();
    }
    function isOutsideInteractionIntercepted() {
      return Array.from(interceptedOutsideInteractionEventsRef.current.values()).some(Boolean);
    }
    function handleInteractionCapture(event) {
      if (!isPointerDownOutsideRef.current) {
        return;
      }
      const target = event.target;
      const isDismissableSurface = target instanceof Node && [...dismissableSurfaces].some((surface) => surface.contains(target));
      if (!isDismissableSurface) {
        interceptedOutsideInteractionEventsRef.current.set(event.type, true);
      }
      if (event.type === "click") {
        window.setTimeout(() => {
          if (isPointerDownOutsideRef.current) {
            handleClickRef.current();
          }
        }, 0);
      }
    }
    function handleInteractionBubble(event) {
      if (isPointerDownOutsideRef.current) {
        interceptedOutsideInteractionEventsRef.current.set(event.type, false);
      }
    }
    const handlePointerDown = (event) => {
      if (event.target && !isPointerInsideReactTreeRef.current) {
        let handleAndDispatchPointerDownOutsideEvent2 = function() {
          ownerDocument.removeEventListener("click", handleClickRef.current);
          const wasOutsideInteractionIntercepted = isOutsideInteractionIntercepted();
          resetOutsideInteraction();
          if (!wasOutsideInteractionIntercepted) {
            handleAndDispatchCustomEvent(
              POINTER_DOWN_OUTSIDE,
              handlePointerDownOutside,
              eventDetail,
              { discrete: true }
            );
          }
        };
        const eventDetail = { originalEvent: event };
        isPointerDownOutsideRef.current = true;
        isDeferredPointerDownOutsideRef.current = deferPointerDownOutside && event.button === 0;
        interceptedOutsideInteractionEventsRef.current.clear();
        if (!deferPointerDownOutside || event.button !== 0) {
          handleAndDispatchPointerDownOutsideEvent2();
        } else {
          ownerDocument.removeEventListener("click", handleClickRef.current);
          handleClickRef.current = handleAndDispatchPointerDownOutsideEvent2;
          ownerDocument.addEventListener("click", handleClickRef.current, { once: true });
        }
      } else {
        ownerDocument.removeEventListener("click", handleClickRef.current);
        resetOutsideInteraction();
      }
      isPointerInsideReactTreeRef.current = false;
    };
    const outsideInteractionEvents = [
      "pointerup",
      "mousedown",
      "mouseup",
      "touchstart",
      "touchend",
      "click"
    ];
    for (const eventName of outsideInteractionEvents) {
      ownerDocument.addEventListener(eventName, handleInteractionCapture, true);
      ownerDocument.addEventListener(eventName, handleInteractionBubble);
    }
    const timerId = window.setTimeout(() => {
      ownerDocument.addEventListener("pointerdown", handlePointerDown);
    }, 0);
    return () => {
      window.clearTimeout(timerId);
      ownerDocument.removeEventListener("pointerdown", handlePointerDown);
      ownerDocument.removeEventListener("click", handleClickRef.current);
      for (const eventName of outsideInteractionEvents) {
        ownerDocument.removeEventListener(eventName, handleInteractionCapture, true);
        ownerDocument.removeEventListener(eventName, handleInteractionBubble);
      }
    };
  }, [
    ownerDocument,
    handlePointerDownOutside,
    deferPointerDownOutside,
    isDeferredPointerDownOutsideRef,
    dismissableSurfaces
  ]);
  return {
    // ensures we check React component tree (not just DOM tree)
    onPointerDownCapture: () => isPointerInsideReactTreeRef.current = true
  };
}
function useFocusOutside(onFocusOutside, ownerDocument = globalThis == null ? void 0 : globalThis.document) {
  const handleFocusOutside = useCallbackRef$1(onFocusOutside);
  const isFocusInsideReactTreeRef = reactExports.useRef(false);
  reactExports.useEffect(() => {
    const handleFocus = (event) => {
      if (event.target && !isFocusInsideReactTreeRef.current) {
        const eventDetail = { originalEvent: event };
        handleAndDispatchCustomEvent(FOCUS_OUTSIDE, handleFocusOutside, eventDetail, {
          discrete: false
        });
      }
    };
    ownerDocument.addEventListener("focusin", handleFocus);
    return () => ownerDocument.removeEventListener("focusin", handleFocus);
  }, [ownerDocument, handleFocusOutside]);
  return {
    onFocusCapture: () => isFocusInsideReactTreeRef.current = true,
    onBlurCapture: () => isFocusInsideReactTreeRef.current = false
  };
}
function dispatchUpdate() {
  const event = new CustomEvent(CONTEXT_UPDATE);
  document.dispatchEvent(event);
}
function handleAndDispatchCustomEvent(name, handler, detail, { discrete }) {
  const target = detail.originalEvent.target;
  const event = new CustomEvent(name, { bubbles: false, cancelable: true, detail });
  if (handler) target.addEventListener(name, handler, { once: true });
  if (discrete) {
    dispatchDiscreteCustomEvent(target, event);
  } else {
    target.dispatchEvent(event);
  }
}
var AUTOFOCUS_ON_MOUNT = "focusScope.autoFocusOnMount";
var AUTOFOCUS_ON_UNMOUNT = "focusScope.autoFocusOnUnmount";
var EVENT_OPTIONS = { bubbles: false, cancelable: true };
var FOCUS_SCOPE_NAME = "FocusScope";
var FocusScope = reactExports.forwardRef((props, forwardedRef) => {
  const {
    loop = false,
    trapped = false,
    onMountAutoFocus: onMountAutoFocusProp,
    onUnmountAutoFocus: onUnmountAutoFocusProp,
    ...scopeProps
  } = props;
  const [container, setContainer] = reactExports.useState(null);
  const onMountAutoFocus = useCallbackRef$1(onMountAutoFocusProp);
  const onUnmountAutoFocus = useCallbackRef$1(onUnmountAutoFocusProp);
  const lastFocusedElementRef = reactExports.useRef(null);
  const composedRefs = useComposedRefs(forwardedRef, (node) => setContainer(node));
  const focusScope = reactExports.useRef({
    paused: false,
    pause() {
      this.paused = true;
    },
    resume() {
      this.paused = false;
    }
  }).current;
  reactExports.useEffect(() => {
    if (trapped) {
      let handleFocusIn2 = function(event) {
        if (focusScope.paused || !container) return;
        const target = event.target;
        if (container.contains(target)) {
          lastFocusedElementRef.current = target;
        } else {
          focus(lastFocusedElementRef.current, { select: true });
        }
      }, handleFocusOut2 = function(event) {
        if (focusScope.paused || !container) return;
        const relatedTarget = event.relatedTarget;
        if (relatedTarget === null) return;
        if (!container.contains(relatedTarget)) {
          focus(lastFocusedElementRef.current, { select: true });
        }
      }, handleMutations2 = function(mutations) {
        const focusedElement = document.activeElement;
        if (focusedElement !== document.body) return;
        for (const mutation of mutations) {
          if (mutation.removedNodes.length > 0) focus(container);
        }
      };
      document.addEventListener("focusin", handleFocusIn2);
      document.addEventListener("focusout", handleFocusOut2);
      const mutationObserver = new MutationObserver(handleMutations2);
      if (container) mutationObserver.observe(container, { childList: true, subtree: true });
      return () => {
        document.removeEventListener("focusin", handleFocusIn2);
        document.removeEventListener("focusout", handleFocusOut2);
        mutationObserver.disconnect();
      };
    }
  }, [trapped, container, focusScope.paused]);
  reactExports.useEffect(() => {
    if (container) {
      focusScopesStack.add(focusScope);
      const previouslyFocusedElement = document.activeElement;
      const hasFocusedCandidate = container.contains(previouslyFocusedElement);
      if (!hasFocusedCandidate) {
        const mountEvent = new CustomEvent(AUTOFOCUS_ON_MOUNT, EVENT_OPTIONS);
        container.addEventListener(AUTOFOCUS_ON_MOUNT, onMountAutoFocus);
        container.dispatchEvent(mountEvent);
        if (!mountEvent.defaultPrevented) {
          focusFirst(removeLinks(getTabbableCandidates(container)), { select: true });
          if (document.activeElement === previouslyFocusedElement) {
            focus(container);
          }
        }
      }
      return () => {
        container.removeEventListener(AUTOFOCUS_ON_MOUNT, onMountAutoFocus);
        setTimeout(() => {
          const unmountEvent = new CustomEvent(AUTOFOCUS_ON_UNMOUNT, EVENT_OPTIONS);
          container.addEventListener(AUTOFOCUS_ON_UNMOUNT, onUnmountAutoFocus);
          container.dispatchEvent(unmountEvent);
          if (!unmountEvent.defaultPrevented) {
            focus(previouslyFocusedElement != null ? previouslyFocusedElement : document.body, { select: true });
          }
          container.removeEventListener(AUTOFOCUS_ON_UNMOUNT, onUnmountAutoFocus);
          focusScopesStack.remove(focusScope);
        }, 0);
      };
    }
  }, [container, onMountAutoFocus, onUnmountAutoFocus, focusScope]);
  const handleKeyDown = reactExports.useCallback(
    (event) => {
      if (!loop && !trapped) return;
      if (focusScope.paused) return;
      const isTabKey = event.key === "Tab" && !event.altKey && !event.ctrlKey && !event.metaKey;
      const focusedElement = document.activeElement;
      if (isTabKey && focusedElement) {
        const container2 = event.currentTarget;
        const [first, last] = getTabbableEdges(container2);
        const hasTabbableElementsInside = first && last;
        if (!hasTabbableElementsInside) {
          if (focusedElement === container2) event.preventDefault();
        } else {
          if (!event.shiftKey && focusedElement === last) {
            event.preventDefault();
            if (loop) focus(first, { select: true });
          } else if (event.shiftKey && focusedElement === first) {
            event.preventDefault();
            if (loop) focus(last, { select: true });
          }
        }
      }
    },
    [loop, trapped, focusScope.paused]
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Primitive.div, { tabIndex: -1, ...scopeProps, ref: composedRefs, onKeyDown: handleKeyDown });
});
FocusScope.displayName = FOCUS_SCOPE_NAME;
function focusFirst(candidates, { select = false } = {}) {
  const previouslyFocusedElement = document.activeElement;
  for (const candidate of candidates) {
    focus(candidate, { select });
    if (document.activeElement !== previouslyFocusedElement) return;
  }
}
function getTabbableEdges(container) {
  const candidates = getTabbableCandidates(container);
  const first = findVisible(candidates, container);
  const last = findVisible(candidates.reverse(), container);
  return [first, last];
}
function getTabbableCandidates(container) {
  const nodes = [];
  const walker = document.createTreeWalker(container, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (node) => {
      const isHiddenInput = node.tagName === "INPUT" && node.type === "hidden";
      if (node.disabled || node.hidden || isHiddenInput) return NodeFilter.FILTER_SKIP;
      return node.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  });
  while (walker.nextNode()) nodes.push(walker.currentNode);
  return nodes;
}
function findVisible(elements, container) {
  for (const element of elements) {
    if (!isHidden(element, { upTo: container })) return element;
  }
}
function isHidden(node, { upTo }) {
  if (getComputedStyle(node).visibility === "hidden") return true;
  while (node) {
    if (upTo !== void 0 && node === upTo) return false;
    if (getComputedStyle(node).display === "none") return true;
    node = node.parentElement;
  }
  return false;
}
function isSelectableInput(element) {
  return element instanceof HTMLInputElement && "select" in element;
}
function focus(element, { select = false } = {}) {
  if (element && element.focus) {
    const previouslyFocusedElement = document.activeElement;
    element.focus({ preventScroll: true });
    if (element !== previouslyFocusedElement && isSelectableInput(element) && select)
      element.select();
  }
}
var focusScopesStack = createFocusScopesStack();
function createFocusScopesStack() {
  let stack = [];
  return {
    add(focusScope) {
      const activeFocusScope = stack[0];
      if (focusScope !== activeFocusScope) {
        activeFocusScope == null ? void 0 : activeFocusScope.pause();
      }
      stack = arrayRemove(stack, focusScope);
      stack.unshift(focusScope);
    },
    remove(focusScope) {
      var _a;
      stack = arrayRemove(stack, focusScope);
      (_a = stack[0]) == null ? void 0 : _a.resume();
    }
  };
}
function arrayRemove(array, item) {
  const updatedArray = [...array];
  const index = updatedArray.indexOf(item);
  if (index !== -1) {
    updatedArray.splice(index, 1);
  }
  return updatedArray;
}
function removeLinks(items) {
  return items.filter((item) => item.tagName !== "A");
}
var PORTAL_NAME$1 = "Portal";
var Portal = reactExports.forwardRef((props, forwardedRef) => {
  var _a;
  const { container: containerProp, ...portalProps } = props;
  const [mounted, setMounted] = reactExports.useState(false);
  useLayoutEffect2(() => setMounted(true), []);
  const container = containerProp || mounted && ((_a = globalThis == null ? void 0 : globalThis.document) == null ? void 0 : _a.body);
  return container ? reactDomExports.createPortal(/* @__PURE__ */ jsxRuntimeExports.jsx(Primitive.div, { ...portalProps, ref: forwardedRef }), container) : null;
});
Portal.displayName = PORTAL_NAME$1;
var count = 0;
var guards = null;
function useFocusGuards() {
  reactExports.useEffect(() => {
    if (!guards) {
      guards = { start: createFocusGuard(), end: createFocusGuard() };
    }
    const { start, end } = guards;
    if (document.body.firstElementChild !== start) {
      document.body.insertAdjacentElement("afterbegin", start);
    }
    if (document.body.lastElementChild !== end) {
      document.body.insertAdjacentElement("beforeend", end);
    }
    count++;
    return () => {
      if (count === 1) {
        guards == null ? void 0 : guards.start.remove();
        guards == null ? void 0 : guards.end.remove();
        guards = null;
      }
      count = Math.max(0, count - 1);
    };
  }, []);
}
function createFocusGuard() {
  const element = document.createElement("span");
  element.setAttribute("data-radix-focus-guard", "");
  element.tabIndex = 0;
  element.style.outline = "none";
  element.style.opacity = "0";
  element.style.position = "fixed";
  element.style.pointerEvents = "none";
  return element;
}
var zeroRightClassName = "right-scroll-bar-position";
var fullWidthClassName = "width-before-scroll-bar";
var noScrollbarsClassName = "with-scroll-bars-hidden";
var removedBarSizeVariable = "--removed-body-scroll-bar-size";
function assignRef(ref, value) {
  if (typeof ref === "function") {
    ref(value);
  } else if (ref) {
    ref.current = value;
  }
  return ref;
}
function useCallbackRef(initialValue, callback) {
  var ref = reactExports.useState(function() {
    return {
      // value
      value: initialValue,
      // last callback
      callback,
      // "memoized" public interface
      facade: {
        get current() {
          return ref.value;
        },
        set current(value) {
          var last = ref.value;
          if (last !== value) {
            ref.value = value;
            ref.callback(value, last);
          }
        }
      }
    };
  })[0];
  ref.callback = callback;
  return ref.facade;
}
var useIsomorphicLayoutEffect = typeof window !== "undefined" ? reactExports.useLayoutEffect : reactExports.useEffect;
var currentValues = /* @__PURE__ */ new WeakMap();
function useMergeRefs(refs, defaultValue) {
  var callbackRef = useCallbackRef(null, function(newValue) {
    return refs.forEach(function(ref) {
      return assignRef(ref, newValue);
    });
  });
  useIsomorphicLayoutEffect(function() {
    var oldValue = currentValues.get(callbackRef);
    if (oldValue) {
      var prevRefs_1 = new Set(oldValue);
      var nextRefs_1 = new Set(refs);
      var current_1 = callbackRef.current;
      prevRefs_1.forEach(function(ref) {
        if (!nextRefs_1.has(ref)) {
          assignRef(ref, null);
        }
      });
      nextRefs_1.forEach(function(ref) {
        if (!prevRefs_1.has(ref)) {
          assignRef(ref, current_1);
        }
      });
    }
    currentValues.set(callbackRef, refs);
  }, [refs]);
  return callbackRef;
}
function ItoI(a) {
  return a;
}
function innerCreateMedium(defaults, middleware) {
  if (middleware === void 0) {
    middleware = ItoI;
  }
  var buffer = [];
  var assigned = false;
  var medium = {
    read: function() {
      if (assigned) {
        throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      }
      if (buffer.length) {
        return buffer[buffer.length - 1];
      }
      return defaults;
    },
    useMedium: function(data) {
      var item = middleware(data, assigned);
      buffer.push(item);
      return function() {
        buffer = buffer.filter(function(x) {
          return x !== item;
        });
      };
    },
    assignSyncMedium: function(cb) {
      assigned = true;
      while (buffer.length) {
        var cbs = buffer;
        buffer = [];
        cbs.forEach(cb);
      }
      buffer = {
        push: function(x) {
          return cb(x);
        },
        filter: function() {
          return buffer;
        }
      };
    },
    assignMedium: function(cb) {
      assigned = true;
      var pendingQueue = [];
      if (buffer.length) {
        var cbs = buffer;
        buffer = [];
        cbs.forEach(cb);
        pendingQueue = buffer;
      }
      var executeQueue = function() {
        var cbs2 = pendingQueue;
        pendingQueue = [];
        cbs2.forEach(cb);
      };
      var cycle = function() {
        return Promise.resolve().then(executeQueue);
      };
      cycle();
      buffer = {
        push: function(x) {
          pendingQueue.push(x);
          cycle();
        },
        filter: function(filter) {
          pendingQueue = pendingQueue.filter(filter);
          return buffer;
        }
      };
    }
  };
  return medium;
}
function createSidecarMedium(options) {
  if (options === void 0) {
    options = {};
  }
  var medium = innerCreateMedium(null);
  medium.options = __assign({ async: true, ssr: false }, options);
  return medium;
}
var SideCar$1 = function(_a) {
  var sideCar = _a.sideCar, rest = __rest(_a, ["sideCar"]);
  if (!sideCar) {
    throw new Error("Sidecar: please provide `sideCar` property to import the right car");
  }
  var Target = sideCar.read();
  if (!Target) {
    throw new Error("Sidecar medium not found");
  }
  return reactExports.createElement(Target, __assign({}, rest));
};
SideCar$1.isSideCarExport = true;
function exportSidecar(medium, exported) {
  medium.useMedium(exported);
  return SideCar$1;
}
var effectCar = createSidecarMedium();
var nothing = function() {
  return;
};
var RemoveScroll = reactExports.forwardRef(function(props, parentRef) {
  var ref = reactExports.useRef(null);
  var _a = reactExports.useState({
    onScrollCapture: nothing,
    onWheelCapture: nothing,
    onTouchMoveCapture: nothing
  }), callbacks = _a[0], setCallbacks = _a[1];
  var forwardProps = props.forwardProps, children = props.children, className = props.className, removeScrollBar = props.removeScrollBar, enabled = props.enabled, shards = props.shards, sideCar = props.sideCar, noRelative = props.noRelative, noIsolation = props.noIsolation, inert = props.inert, allowPinchZoom = props.allowPinchZoom, _b = props.as, Container = _b === void 0 ? "div" : _b, gapMode = props.gapMode, rest = __rest(props, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noRelative", "noIsolation", "inert", "allowPinchZoom", "as", "gapMode"]);
  var SideCar2 = sideCar;
  var containerRef = useMergeRefs([ref, parentRef]);
  var containerProps = __assign(__assign({}, rest), callbacks);
  return reactExports.createElement(
    reactExports.Fragment,
    null,
    enabled && reactExports.createElement(SideCar2, { sideCar: effectCar, removeScrollBar, shards, noRelative, noIsolation, inert, setCallbacks, allowPinchZoom: !!allowPinchZoom, lockRef: ref, gapMode }),
    forwardProps ? reactExports.cloneElement(reactExports.Children.only(children), __assign(__assign({}, containerProps), { ref: containerRef })) : reactExports.createElement(Container, __assign({}, containerProps, { className, ref: containerRef }), children)
  );
});
RemoveScroll.defaultProps = {
  enabled: true,
  removeScrollBar: true,
  inert: false
};
RemoveScroll.classNames = {
  fullWidth: fullWidthClassName,
  zeroRight: zeroRightClassName
};
var getNonce = function() {
  if (typeof __webpack_nonce__ !== "undefined") {
    return __webpack_nonce__;
  }
  return void 0;
};
function makeStyleTag() {
  if (!document)
    return null;
  var tag = document.createElement("style");
  tag.type = "text/css";
  var nonce = getNonce();
  if (nonce) {
    tag.setAttribute("nonce", nonce);
  }
  return tag;
}
function injectStyles(tag, css) {
  if (tag.styleSheet) {
    tag.styleSheet.cssText = css;
  } else {
    tag.appendChild(document.createTextNode(css));
  }
}
function insertStyleTag(tag) {
  var head = document.head || document.getElementsByTagName("head")[0];
  head.appendChild(tag);
}
var stylesheetSingleton = function() {
  var counter = 0;
  var stylesheet = null;
  return {
    add: function(style) {
      if (counter == 0) {
        if (stylesheet = makeStyleTag()) {
          injectStyles(stylesheet, style);
          insertStyleTag(stylesheet);
        }
      }
      counter++;
    },
    remove: function() {
      counter--;
      if (!counter && stylesheet) {
        stylesheet.parentNode && stylesheet.parentNode.removeChild(stylesheet);
        stylesheet = null;
      }
    }
  };
};
var styleHookSingleton = function() {
  var sheet = stylesheetSingleton();
  return function(styles, isDynamic) {
    reactExports.useEffect(function() {
      sheet.add(styles);
      return function() {
        sheet.remove();
      };
    }, [styles && isDynamic]);
  };
};
var styleSingleton = function() {
  var useStyle = styleHookSingleton();
  var Sheet = function(_a) {
    var styles = _a.styles, dynamic = _a.dynamic;
    useStyle(styles, dynamic);
    return null;
  };
  return Sheet;
};
var zeroGap = {
  left: 0,
  top: 0,
  right: 0,
  gap: 0
};
var parse = function(x) {
  return parseInt(x || "", 10) || 0;
};
var getOffset = function(gapMode) {
  var cs = window.getComputedStyle(document.body);
  var left = cs[gapMode === "padding" ? "paddingLeft" : "marginLeft"];
  var top = cs[gapMode === "padding" ? "paddingTop" : "marginTop"];
  var right = cs[gapMode === "padding" ? "paddingRight" : "marginRight"];
  return [parse(left), parse(top), parse(right)];
};
var getGapWidth = function(gapMode) {
  if (gapMode === void 0) {
    gapMode = "margin";
  }
  if (typeof window === "undefined") {
    return zeroGap;
  }
  var offsets = getOffset(gapMode);
  var documentWidth = document.documentElement.clientWidth;
  var windowWidth = window.innerWidth;
  return {
    left: offsets[0],
    top: offsets[1],
    right: offsets[2],
    gap: Math.max(0, windowWidth - documentWidth + offsets[2] - offsets[0])
  };
};
var Style = styleSingleton();
var lockAttribute = "data-scroll-locked";
var getStyles = function(_a, allowRelative, gapMode, important) {
  var left = _a.left, top = _a.top, right = _a.right, gap = _a.gap;
  if (gapMode === void 0) {
    gapMode = "margin";
  }
  return "\n  .".concat(noScrollbarsClassName, " {\n   overflow: hidden ").concat(important, ";\n   padding-right: ").concat(gap, "px ").concat(important, ";\n  }\n  body[").concat(lockAttribute, "] {\n    overflow: hidden ").concat(important, ";\n    overscroll-behavior: contain;\n    ").concat([
    allowRelative && "position: relative ".concat(important, ";"),
    gapMode === "margin" && "\n    padding-left: ".concat(left, "px;\n    padding-top: ").concat(top, "px;\n    padding-right: ").concat(right, "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: ").concat(gap, "px ").concat(important, ";\n    "),
    gapMode === "padding" && "padding-right: ".concat(gap, "px ").concat(important, ";")
  ].filter(Boolean).join(""), "\n  }\n  \n  .").concat(zeroRightClassName, " {\n    right: ").concat(gap, "px ").concat(important, ";\n  }\n  \n  .").concat(fullWidthClassName, " {\n    margin-right: ").concat(gap, "px ").concat(important, ";\n  }\n  \n  .").concat(zeroRightClassName, " .").concat(zeroRightClassName, " {\n    right: 0 ").concat(important, ";\n  }\n  \n  .").concat(fullWidthClassName, " .").concat(fullWidthClassName, " {\n    margin-right: 0 ").concat(important, ";\n  }\n  \n  body[").concat(lockAttribute, "] {\n    ").concat(removedBarSizeVariable, ": ").concat(gap, "px;\n  }\n");
};
var getCurrentUseCounter = function() {
  var counter = parseInt(document.body.getAttribute(lockAttribute) || "0", 10);
  return isFinite(counter) ? counter : 0;
};
var useLockAttribute = function() {
  reactExports.useEffect(function() {
    document.body.setAttribute(lockAttribute, (getCurrentUseCounter() + 1).toString());
    return function() {
      var newCounter = getCurrentUseCounter() - 1;
      if (newCounter <= 0) {
        document.body.removeAttribute(lockAttribute);
      } else {
        document.body.setAttribute(lockAttribute, newCounter.toString());
      }
    };
  }, []);
};
var RemoveScrollBar = function(_a) {
  var noRelative = _a.noRelative, noImportant = _a.noImportant, _b = _a.gapMode, gapMode = _b === void 0 ? "margin" : _b;
  useLockAttribute();
  var gap = reactExports.useMemo(function() {
    return getGapWidth(gapMode);
  }, [gapMode]);
  return reactExports.createElement(Style, { styles: getStyles(gap, !noRelative, gapMode, !noImportant ? "!important" : "") });
};
var passiveSupported = false;
if (typeof window !== "undefined") {
  try {
    var options = Object.defineProperty({}, "passive", {
      get: function() {
        passiveSupported = true;
        return true;
      }
    });
    window.addEventListener("test", options, options);
    window.removeEventListener("test", options, options);
  } catch (err) {
    passiveSupported = false;
  }
}
var nonPassive = passiveSupported ? { passive: false } : false;
var alwaysContainsScroll = function(node) {
  return node.tagName === "TEXTAREA";
};
var elementCanBeScrolled = function(node, overflow) {
  if (!(node instanceof Element)) {
    return false;
  }
  var styles = window.getComputedStyle(node);
  return (
    // not-not-scrollable
    styles[overflow] !== "hidden" && // contains scroll inside self
    !(styles.overflowY === styles.overflowX && !alwaysContainsScroll(node) && styles[overflow] === "visible")
  );
};
var elementCouldBeVScrolled = function(node) {
  return elementCanBeScrolled(node, "overflowY");
};
var elementCouldBeHScrolled = function(node) {
  return elementCanBeScrolled(node, "overflowX");
};
var locationCouldBeScrolled = function(axis, node) {
  var ownerDocument = node.ownerDocument;
  var current = node;
  do {
    if (typeof ShadowRoot !== "undefined" && current instanceof ShadowRoot) {
      current = current.host;
    }
    var isScrollable = elementCouldBeScrolled(axis, current);
    if (isScrollable) {
      var _a = getScrollVariables(axis, current), scrollHeight = _a[1], clientHeight = _a[2];
      if (scrollHeight > clientHeight) {
        return true;
      }
    }
    current = current.parentNode;
  } while (current && current !== ownerDocument.body);
  return false;
};
var getVScrollVariables = function(_a) {
  var scrollTop = _a.scrollTop, scrollHeight = _a.scrollHeight, clientHeight = _a.clientHeight;
  return [
    scrollTop,
    scrollHeight,
    clientHeight
  ];
};
var getHScrollVariables = function(_a) {
  var scrollLeft = _a.scrollLeft, scrollWidth = _a.scrollWidth, clientWidth = _a.clientWidth;
  return [
    scrollLeft,
    scrollWidth,
    clientWidth
  ];
};
var elementCouldBeScrolled = function(axis, node) {
  return axis === "v" ? elementCouldBeVScrolled(node) : elementCouldBeHScrolled(node);
};
var getScrollVariables = function(axis, node) {
  return axis === "v" ? getVScrollVariables(node) : getHScrollVariables(node);
};
var getDirectionFactor = function(axis, direction) {
  return axis === "h" && direction === "rtl" ? -1 : 1;
};
var handleScroll = function(axis, endTarget, event, sourceDelta, noOverscroll) {
  var directionFactor = getDirectionFactor(axis, window.getComputedStyle(endTarget).direction);
  var delta = directionFactor * sourceDelta;
  var target = event.target;
  var targetInLock = endTarget.contains(target);
  var shouldCancelScroll = false;
  var isDeltaPositive = delta > 0;
  var availableScroll = 0;
  var availableScrollTop = 0;
  do {
    if (!target) {
      break;
    }
    var _a = getScrollVariables(axis, target), position = _a[0], scroll_1 = _a[1], capacity = _a[2];
    var elementScroll = scroll_1 - capacity - directionFactor * position;
    if (position || elementScroll) {
      if (elementCouldBeScrolled(axis, target)) {
        availableScroll += elementScroll;
        availableScrollTop += position;
      }
    }
    var parent_1 = target.parentNode;
    target = parent_1 && parent_1.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? parent_1.host : parent_1;
  } while (
    // portaled content
    !targetInLock && target !== document.body || // self content
    targetInLock && (endTarget.contains(target) || endTarget === target)
  );
  if (isDeltaPositive && (Math.abs(availableScroll) < 1 || false)) {
    shouldCancelScroll = true;
  } else if (!isDeltaPositive && (Math.abs(availableScrollTop) < 1 || false)) {
    shouldCancelScroll = true;
  }
  return shouldCancelScroll;
};
var getTouchXY = function(event) {
  return "changedTouches" in event ? [event.changedTouches[0].clientX, event.changedTouches[0].clientY] : [0, 0];
};
var getDeltaXY = function(event) {
  return [event.deltaX, event.deltaY];
};
var extractRef = function(ref) {
  return ref && "current" in ref ? ref.current : ref;
};
var deltaCompare = function(x, y) {
  return x[0] === y[0] && x[1] === y[1];
};
var generateStyle = function(id) {
  return "\n  .block-interactivity-".concat(id, " {pointer-events: none;}\n  .allow-interactivity-").concat(id, " {pointer-events: all;}\n");
};
var idCounter = 0;
var lockStack = [];
function RemoveScrollSideCar(props) {
  var shouldPreventQueue = reactExports.useRef([]);
  var touchStartRef = reactExports.useRef([0, 0]);
  var activeAxis = reactExports.useRef();
  var id = reactExports.useState(idCounter++)[0];
  var Style2 = reactExports.useState(styleSingleton)[0];
  var lastProps = reactExports.useRef(props);
  reactExports.useEffect(function() {
    lastProps.current = props;
  }, [props]);
  reactExports.useEffect(function() {
    if (props.inert) {
      document.body.classList.add("block-interactivity-".concat(id));
      var allow_1 = __spreadArray([props.lockRef.current], (props.shards || []).map(extractRef), true).filter(Boolean);
      allow_1.forEach(function(el) {
        return el.classList.add("allow-interactivity-".concat(id));
      });
      return function() {
        document.body.classList.remove("block-interactivity-".concat(id));
        allow_1.forEach(function(el) {
          return el.classList.remove("allow-interactivity-".concat(id));
        });
      };
    }
    return;
  }, [props.inert, props.lockRef.current, props.shards]);
  var shouldCancelEvent = reactExports.useCallback(function(event, parent) {
    if ("touches" in event && event.touches.length === 2 || event.type === "wheel" && event.ctrlKey) {
      return !lastProps.current.allowPinchZoom;
    }
    var touch = getTouchXY(event);
    var touchStart = touchStartRef.current;
    var deltaX = "deltaX" in event ? event.deltaX : touchStart[0] - touch[0];
    var deltaY = "deltaY" in event ? event.deltaY : touchStart[1] - touch[1];
    var currentAxis;
    var target = event.target;
    var moveDirection = Math.abs(deltaX) > Math.abs(deltaY) ? "h" : "v";
    if ("touches" in event && moveDirection === "h" && target.type === "range") {
      return false;
    }
    var selection = window.getSelection();
    var anchorNode = selection && selection.anchorNode;
    var isTouchingSelection = anchorNode ? anchorNode === target || anchorNode.contains(target) : false;
    if (isTouchingSelection) {
      return false;
    }
    var canBeScrolledInMainDirection = locationCouldBeScrolled(moveDirection, target);
    if (!canBeScrolledInMainDirection) {
      return true;
    }
    if (canBeScrolledInMainDirection) {
      currentAxis = moveDirection;
    } else {
      currentAxis = moveDirection === "v" ? "h" : "v";
      canBeScrolledInMainDirection = locationCouldBeScrolled(moveDirection, target);
    }
    if (!canBeScrolledInMainDirection) {
      return false;
    }
    if (!activeAxis.current && "changedTouches" in event && (deltaX || deltaY)) {
      activeAxis.current = currentAxis;
    }
    if (!currentAxis) {
      return true;
    }
    var cancelingAxis = activeAxis.current || currentAxis;
    return handleScroll(cancelingAxis, parent, event, cancelingAxis === "h" ? deltaX : deltaY);
  }, []);
  var shouldPrevent = reactExports.useCallback(function(_event) {
    var event = _event;
    if (!lockStack.length || lockStack[lockStack.length - 1] !== Style2) {
      return;
    }
    var delta = "deltaY" in event ? getDeltaXY(event) : getTouchXY(event);
    var sourceEvent = shouldPreventQueue.current.filter(function(e) {
      return e.name === event.type && (e.target === event.target || event.target === e.shadowParent) && deltaCompare(e.delta, delta);
    })[0];
    if (sourceEvent && sourceEvent.should) {
      if (event.cancelable) {
        event.preventDefault();
      }
      return;
    }
    if (!sourceEvent) {
      var shardNodes = (lastProps.current.shards || []).map(extractRef).filter(Boolean).filter(function(node) {
        return node.contains(event.target);
      });
      var shouldStop = shardNodes.length > 0 ? shouldCancelEvent(event, shardNodes[0]) : !lastProps.current.noIsolation;
      if (shouldStop) {
        if (event.cancelable) {
          event.preventDefault();
        }
      }
    }
  }, []);
  var shouldCancel = reactExports.useCallback(function(name, delta, target, should) {
    var event = { name, delta, target, should, shadowParent: getOutermostShadowParent(target) };
    shouldPreventQueue.current.push(event);
    setTimeout(function() {
      shouldPreventQueue.current = shouldPreventQueue.current.filter(function(e) {
        return e !== event;
      });
    }, 1);
  }, []);
  var scrollTouchStart = reactExports.useCallback(function(event) {
    touchStartRef.current = getTouchXY(event);
    activeAxis.current = void 0;
  }, []);
  var scrollWheel = reactExports.useCallback(function(event) {
    shouldCancel(event.type, getDeltaXY(event), event.target, shouldCancelEvent(event, props.lockRef.current));
  }, []);
  var scrollTouchMove = reactExports.useCallback(function(event) {
    shouldCancel(event.type, getTouchXY(event), event.target, shouldCancelEvent(event, props.lockRef.current));
  }, []);
  reactExports.useEffect(function() {
    lockStack.push(Style2);
    props.setCallbacks({
      onScrollCapture: scrollWheel,
      onWheelCapture: scrollWheel,
      onTouchMoveCapture: scrollTouchMove
    });
    document.addEventListener("wheel", shouldPrevent, nonPassive);
    document.addEventListener("touchmove", shouldPrevent, nonPassive);
    document.addEventListener("touchstart", scrollTouchStart, nonPassive);
    return function() {
      lockStack = lockStack.filter(function(inst) {
        return inst !== Style2;
      });
      document.removeEventListener("wheel", shouldPrevent, nonPassive);
      document.removeEventListener("touchmove", shouldPrevent, nonPassive);
      document.removeEventListener("touchstart", scrollTouchStart, nonPassive);
    };
  }, []);
  var removeScrollBar = props.removeScrollBar, inert = props.inert;
  return reactExports.createElement(
    reactExports.Fragment,
    null,
    inert ? reactExports.createElement(Style2, { styles: generateStyle(id) }) : null,
    removeScrollBar ? reactExports.createElement(RemoveScrollBar, { noRelative: props.noRelative, gapMode: props.gapMode }) : null
  );
}
function getOutermostShadowParent(node) {
  var shadowParent = null;
  while (node !== null) {
    if (node instanceof ShadowRoot) {
      shadowParent = node.host;
      node = node.host;
    }
    node = node.parentNode;
  }
  return shadowParent;
}
const SideCar = exportSidecar(effectCar, RemoveScrollSideCar);
var ReactRemoveScroll = reactExports.forwardRef(function(props, ref) {
  return reactExports.createElement(RemoveScroll, __assign({}, props, { ref, sideCar: SideCar }));
});
ReactRemoveScroll.classNames = RemoveScroll.classNames;
var getDefaultParent = function(originalTarget) {
  if (typeof document === "undefined") {
    return null;
  }
  var sampleTarget = Array.isArray(originalTarget) ? originalTarget[0] : originalTarget;
  return sampleTarget.ownerDocument.body;
};
var counterMap = /* @__PURE__ */ new WeakMap();
var uncontrolledNodes = /* @__PURE__ */ new WeakMap();
var markerMap = {};
var lockCount = 0;
var unwrapHost = function(node) {
  return node && (node.host || unwrapHost(node.parentNode));
};
var correctTargets = function(parent, targets) {
  return targets.map(function(target) {
    if (parent.contains(target)) {
      return target;
    }
    var correctedTarget = unwrapHost(target);
    if (correctedTarget && parent.contains(correctedTarget)) {
      return correctedTarget;
    }
    console.error("aria-hidden", target, "in not contained inside", parent, ". Doing nothing");
    return null;
  }).filter(function(x) {
    return Boolean(x);
  });
};
var applyAttributeToOthers = function(originalTarget, parentNode, markerName, controlAttribute) {
  var targets = correctTargets(parentNode, Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
  if (!markerMap[markerName]) {
    markerMap[markerName] = /* @__PURE__ */ new WeakMap();
  }
  var markerCounter = markerMap[markerName];
  var hiddenNodes = [];
  var elementsToKeep = /* @__PURE__ */ new Set();
  var elementsToStop = new Set(targets);
  var keep = function(el) {
    if (!el || elementsToKeep.has(el)) {
      return;
    }
    elementsToKeep.add(el);
    keep(el.parentNode);
  };
  targets.forEach(keep);
  var deep = function(parent) {
    if (!parent || elementsToStop.has(parent)) {
      return;
    }
    Array.prototype.forEach.call(parent.children, function(node) {
      if (elementsToKeep.has(node)) {
        deep(node);
      } else {
        try {
          var attr = node.getAttribute(controlAttribute);
          var alreadyHidden = attr !== null && attr !== "false";
          var counterValue = (counterMap.get(node) || 0) + 1;
          var markerValue = (markerCounter.get(node) || 0) + 1;
          counterMap.set(node, counterValue);
          markerCounter.set(node, markerValue);
          hiddenNodes.push(node);
          if (counterValue === 1 && alreadyHidden) {
            uncontrolledNodes.set(node, true);
          }
          if (markerValue === 1) {
            node.setAttribute(markerName, "true");
          }
          if (!alreadyHidden) {
            node.setAttribute(controlAttribute, "true");
          }
        } catch (e) {
          console.error("aria-hidden: cannot operate on ", node, e);
        }
      }
    });
  };
  deep(parentNode);
  elementsToKeep.clear();
  lockCount++;
  return function() {
    hiddenNodes.forEach(function(node) {
      var counterValue = counterMap.get(node) - 1;
      var markerValue = markerCounter.get(node) - 1;
      counterMap.set(node, counterValue);
      markerCounter.set(node, markerValue);
      if (!counterValue) {
        if (!uncontrolledNodes.has(node)) {
          node.removeAttribute(controlAttribute);
        }
        uncontrolledNodes.delete(node);
      }
      if (!markerValue) {
        node.removeAttribute(markerName);
      }
    });
    lockCount--;
    if (!lockCount) {
      counterMap = /* @__PURE__ */ new WeakMap();
      counterMap = /* @__PURE__ */ new WeakMap();
      uncontrolledNodes = /* @__PURE__ */ new WeakMap();
      markerMap = {};
    }
  };
};
var hideOthers = function(originalTarget, parentNode, markerName) {
  if (markerName === void 0) {
    markerName = "data-aria-hidden";
  }
  var targets = Array.from(Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
  var activeParentNode = getDefaultParent(originalTarget);
  if (!activeParentNode) {
    return function() {
      return null;
    };
  }
  targets.push.apply(targets, Array.from(activeParentNode.querySelectorAll("[aria-live], script")));
  return applyAttributeToOthers(targets, activeParentNode, markerName, "aria-hidden");
};
var DIALOG_NAME = "Dialog";
var [createDialogContext] = createContextScope(DIALOG_NAME);
var [DialogProvider, useDialogContext] = createDialogContext(DIALOG_NAME);
var Dialog$1 = (props) => {
  const {
    __scopeDialog,
    children,
    open: openProp,
    defaultOpen,
    onOpenChange,
    modal = true
  } = props;
  const triggerRef = reactExports.useRef(null);
  const contentRef = reactExports.useRef(null);
  const [open, setOpen] = useControllableState({
    prop: openProp,
    defaultProp: defaultOpen != null ? defaultOpen : false,
    onChange: onOpenChange,
    caller: DIALOG_NAME
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    DialogProvider,
    {
      scope: __scopeDialog,
      triggerRef,
      contentRef,
      contentId: useId(),
      titleId: useId(),
      descriptionId: useId(),
      open,
      onOpenChange: setOpen,
      onOpenToggle: reactExports.useCallback(() => setOpen((prevOpen) => !prevOpen), [setOpen]),
      modal,
      children
    }
  );
};
Dialog$1.displayName = DIALOG_NAME;
var TRIGGER_NAME$1 = "DialogTrigger";
var DialogTrigger$1 = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeDialog, ...triggerProps } = props;
    const context = useDialogContext(TRIGGER_NAME$1, __scopeDialog);
    const composedTriggerRef = useComposedRefs(forwardedRef, context.triggerRef);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Primitive.button,
      {
        type: "button",
        "aria-haspopup": "dialog",
        "aria-expanded": context.open,
        "aria-controls": context.open ? context.contentId : void 0,
        "data-state": getState$1(context.open),
        ...triggerProps,
        ref: composedTriggerRef,
        onClick: composeEventHandlers(props.onClick, context.onOpenToggle)
      }
    );
  }
);
DialogTrigger$1.displayName = TRIGGER_NAME$1;
var PORTAL_NAME = "DialogPortal";
var [PortalProvider, usePortalContext] = createDialogContext(PORTAL_NAME, {
  forceMount: void 0
});
var DialogPortal$1 = (props) => {
  const { __scopeDialog, forceMount, children, container } = props;
  const context = useDialogContext(PORTAL_NAME, __scopeDialog);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(PortalProvider, { scope: __scopeDialog, forceMount, children: reactExports.Children.map(children, (child) => /* @__PURE__ */ jsxRuntimeExports.jsx(Presence, { present: forceMount || context.open, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Portal, { asChild: true, container, children: child }) })) });
};
DialogPortal$1.displayName = PORTAL_NAME;
var OVERLAY_NAME = "DialogOverlay";
var DialogOverlay$1 = reactExports.forwardRef(
  (props, forwardedRef) => {
    const portalContext = usePortalContext(OVERLAY_NAME, props.__scopeDialog);
    const { forceMount = portalContext.forceMount, ...overlayProps } = props;
    const context = useDialogContext(OVERLAY_NAME, props.__scopeDialog);
    return context.modal ? /* @__PURE__ */ jsxRuntimeExports.jsx(Presence, { present: forceMount || context.open, children: /* @__PURE__ */ jsxRuntimeExports.jsx(DialogOverlayImpl, { ...overlayProps, ref: forwardedRef }) }) : null;
  }
);
DialogOverlay$1.displayName = OVERLAY_NAME;
var Slot = createSlot("DialogOverlay.RemoveScroll");
var DialogOverlayImpl = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeDialog, ...overlayProps } = props;
    const context = useDialogContext(OVERLAY_NAME, __scopeDialog);
    const registerDismissableSurface = useDismissableLayerSurface();
    const composedRefs = useComposedRefs(forwardedRef, registerDismissableSurface);
    return (
      // Make sure `Content` is scrollable even when it doesn't live inside `RemoveScroll`
      // ie. when `Overlay` and `Content` are siblings
      /* @__PURE__ */ jsxRuntimeExports.jsx(ReactRemoveScroll, { as: Slot, allowPinchZoom: true, shards: [context.contentRef], children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        Primitive.div,
        {
          "data-state": getState$1(context.open),
          ...overlayProps,
          ref: composedRefs,
          style: { pointerEvents: "auto", ...overlayProps.style }
        }
      ) })
    );
  }
);
var CONTENT_NAME = "DialogContent";
var DialogContent$1 = reactExports.forwardRef(
  (props, forwardedRef) => {
    const portalContext = usePortalContext(CONTENT_NAME, props.__scopeDialog);
    const { forceMount = portalContext.forceMount, ...contentProps } = props;
    const context = useDialogContext(CONTENT_NAME, props.__scopeDialog);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Presence, { present: forceMount || context.open, children: context.modal ? /* @__PURE__ */ jsxRuntimeExports.jsx(DialogContentModal, { ...contentProps, ref: forwardedRef }) : /* @__PURE__ */ jsxRuntimeExports.jsx(DialogContentNonModal, { ...contentProps, ref: forwardedRef }) });
  }
);
DialogContent$1.displayName = CONTENT_NAME;
var DialogContentModal = reactExports.forwardRef(
  (props, forwardedRef) => {
    const context = useDialogContext(CONTENT_NAME, props.__scopeDialog);
    const contentRef = reactExports.useRef(null);
    const composedRefs = useComposedRefs(forwardedRef, context.contentRef, contentRef);
    reactExports.useEffect(() => {
      const content = contentRef.current;
      if (content) return hideOthers(content);
    }, []);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      DialogContentImpl,
      {
        ...props,
        ref: composedRefs,
        trapFocus: context.open,
        disableOutsidePointerEvents: context.open,
        onCloseAutoFocus: composeEventHandlers(props.onCloseAutoFocus, (event) => {
          var _a;
          event.preventDefault();
          (_a = context.triggerRef.current) == null ? void 0 : _a.focus();
        }),
        onPointerDownOutside: composeEventHandlers(props.onPointerDownOutside, (event) => {
          const originalEvent = event.detail.originalEvent;
          const ctrlLeftClick = originalEvent.button === 0 && originalEvent.ctrlKey === true;
          const isRightClick = originalEvent.button === 2 || ctrlLeftClick;
          if (isRightClick) event.preventDefault();
        }),
        onFocusOutside: composeEventHandlers(
          props.onFocusOutside,
          (event) => event.preventDefault()
        )
      }
    );
  }
);
var DialogContentNonModal = reactExports.forwardRef(
  (props, forwardedRef) => {
    const context = useDialogContext(CONTENT_NAME, props.__scopeDialog);
    const hasInteractedOutsideRef = reactExports.useRef(false);
    const hasPointerDownOutsideRef = reactExports.useRef(false);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      DialogContentImpl,
      {
        ...props,
        ref: forwardedRef,
        trapFocus: false,
        disableOutsidePointerEvents: false,
        onCloseAutoFocus: (event) => {
          var _a, _b;
          (_a = props.onCloseAutoFocus) == null ? void 0 : _a.call(props, event);
          if (!event.defaultPrevented) {
            if (!hasInteractedOutsideRef.current) (_b = context.triggerRef.current) == null ? void 0 : _b.focus();
            event.preventDefault();
          }
          hasInteractedOutsideRef.current = false;
          hasPointerDownOutsideRef.current = false;
        },
        onInteractOutside: (event) => {
          var _a, _b;
          (_a = props.onInteractOutside) == null ? void 0 : _a.call(props, event);
          if (!event.defaultPrevented) {
            hasInteractedOutsideRef.current = true;
            if (event.detail.originalEvent.type === "pointerdown") {
              hasPointerDownOutsideRef.current = true;
            }
          }
          const target = event.target;
          const targetIsTrigger = (_b = context.triggerRef.current) == null ? void 0 : _b.contains(target);
          if (targetIsTrigger) event.preventDefault();
          if (event.detail.originalEvent.type === "focusin" && hasPointerDownOutsideRef.current) {
            event.preventDefault();
          }
        }
      }
    );
  }
);
var DialogContentImpl = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeDialog, trapFocus, onOpenAutoFocus, onCloseAutoFocus, ...contentProps } = props;
    const context = useDialogContext(CONTENT_NAME, __scopeDialog);
    useFocusGuards();
    return /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      FocusScope,
      {
        asChild: true,
        loop: true,
        trapped: trapFocus,
        onMountAutoFocus: onOpenAutoFocus,
        onUnmountAutoFocus: onCloseAutoFocus,
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          DismissableLayer,
          {
            role: "dialog",
            id: context.contentId,
            "aria-describedby": context.descriptionId,
            "aria-labelledby": context.titleId,
            "data-state": getState$1(context.open),
            ...contentProps,
            ref: forwardedRef,
            deferPointerDownOutside: true,
            onDismiss: () => context.onOpenChange(false)
          }
        )
      }
    ) });
  }
);
var TITLE_NAME = "DialogTitle";
var DialogTitle$1 = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeDialog, ...titleProps } = props;
    const context = useDialogContext(TITLE_NAME, __scopeDialog);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Primitive.h2, { id: context.titleId, ...titleProps, ref: forwardedRef });
  }
);
DialogTitle$1.displayName = TITLE_NAME;
var DESCRIPTION_NAME = "DialogDescription";
var DialogDescription$1 = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeDialog, ...descriptionProps } = props;
    const context = useDialogContext(DESCRIPTION_NAME, __scopeDialog);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Primitive.p, { id: context.descriptionId, ...descriptionProps, ref: forwardedRef });
  }
);
DialogDescription$1.displayName = DESCRIPTION_NAME;
var CLOSE_NAME = "DialogClose";
var DialogClose = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeDialog, ...closeProps } = props;
    const context = useDialogContext(CLOSE_NAME, __scopeDialog);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Primitive.button,
      {
        type: "button",
        ...closeProps,
        ref: forwardedRef,
        onClick: composeEventHandlers(props.onClick, () => context.onOpenChange(false))
      }
    );
  }
);
DialogClose.displayName = CLOSE_NAME;
function getState$1(open) {
  return open ? "open" : "closed";
}
function Dialog({
  ...props
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog$1, { "data-slot": "dialog", ...props });
}
function DialogTrigger({
  ...props
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTrigger$1, { "data-slot": "dialog-trigger", ...props });
}
function DialogPortal({
  ...props
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(DialogPortal$1, { "data-slot": "dialog-portal", ...props });
}
function DialogOverlay({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(DialogOverlay$1, { "data-slot": "dialog-overlay", className: cn("data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 fixed inset-0 z-50 bg-black/50", className), ...props });
}
function DialogContent({
  className,
  children,
  showCloseButton = true,
  ...props
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogPortal, { "data-slot": "dialog-portal", "data-forge-id": "forge-uzhnfm-56-4", "data-component": "DialogPortal", "data-source-pos": "src/components/ui/dialog.tsx:56:4:77:19", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(DialogOverlay, { "data-forge-id": "forge-uzho6d-57-6", "data-component": "DialogOverlay", "data-source-pos": "src/components/ui/dialog.tsx:57:6:57:23" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent$1, { "data-slot": "dialog-content", className: cn("bg-background data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 rounded-lg border p-6 shadow-lg duration-200 sm:max-w-lg", className), ...props, children: [
      children,
      showCloseButton && /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogClose, { "data-slot": "dialog-close", className: "ring-offset-background focus:ring-ring data-[state=open]:bg-accent data-[state=open]:text-muted-foreground absolute top-4 right-4 rounded-xs opacity-70 transition-opacity hover:opacity-100 focus:ring-2 focus:ring-offset-2 focus:outline-hidden disabled:pointer-events-none [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(X, { "data-forge-id": "forge-xuck07-72-12", "data-component": "XIcon", "data-source-pos": "src/components/ui/dialog.tsx:72:12:72:21" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", "data-forge-id": "forge-xubx0o-73-12", "data-component": "span", "data-source-pos": "src/components/ui/dialog.tsx:73:12:73:50", children: "Close" })
      ] })
    ] })
  ] });
}
function DialogHeader({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { "data-slot": "dialog-header", className: cn("flex flex-col gap-2 text-center sm:text-left", className), "data-forge-id": "forge-uzji64-83-4", "data-component": "div", "data-source-pos": "src/components/ui/dialog.tsx:83:4:87:6", ...props });
}
function DialogTitle({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle$1, { "data-slot": "dialog-title", className: cn("text-lg leading-none font-semibold", className), ...props });
}
function DialogDescription({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription$1, { "data-slot": "dialog-description", className: cn("text-muted-foreground text-sm", className), ...props });
}
function usePrevious(value) {
  const ref = reactExports.useRef({ value, previous: value });
  return reactExports.useMemo(() => {
    if (ref.current.value !== value) {
      ref.current.previous = ref.current.value;
      ref.current.value = value;
    }
    return ref.current.previous;
  }, [value]);
}
function useSize(element) {
  const [size, setSize] = reactExports.useState(void 0);
  useLayoutEffect2(() => {
    if (element) {
      setSize({ width: element.offsetWidth, height: element.offsetHeight });
      const resizeObserver = new ResizeObserver((entries) => {
        if (!Array.isArray(entries)) {
          return;
        }
        if (!entries.length) {
          return;
        }
        const entry = entries[0];
        let width;
        let height;
        if ("borderBoxSize" in entry) {
          const borderSizeEntry = entry["borderBoxSize"];
          const borderSize = Array.isArray(borderSizeEntry) ? borderSizeEntry[0] : borderSizeEntry;
          width = borderSize["inlineSize"];
          height = borderSize["blockSize"];
        } else {
          width = element.offsetWidth;
          height = element.offsetHeight;
        }
        setSize({ width, height });
      });
      resizeObserver.observe(element, { box: "border-box" });
      return () => resizeObserver.unobserve(element);
    } else {
      setSize(void 0);
    }
  }, [element]);
  return size;
}
var SWITCH_NAME = "Switch";
var [createSwitchContext] = createContextScope(SWITCH_NAME);
var [SwitchProviderImpl, useSwitchContext] = createSwitchContext(SWITCH_NAME);
function SwitchProvider(props) {
  const {
    __scopeSwitch,
    checked: checkedProp,
    children,
    defaultChecked,
    disabled,
    form,
    name,
    onCheckedChange,
    required,
    value = "on",
    // @ts-expect-error
    internal_do_not_use_render
  } = props;
  const [checked, setChecked] = useControllableState({
    prop: checkedProp,
    defaultProp: defaultChecked != null ? defaultChecked : false,
    onChange: onCheckedChange,
    caller: SWITCH_NAME
  });
  const [control, setControl] = reactExports.useState(null);
  const [bubbleInput, setBubbleInput] = reactExports.useState(null);
  const hasConsumerStoppedPropagationRef = reactExports.useRef(false);
  const isFormControl = control ? !!form || !!control.closest("form") : (
    // We set this to true by default so that events bubble to forms without JS (SSR)
    true
  );
  const context = {
    checked,
    setChecked,
    disabled,
    control,
    setControl,
    name,
    form,
    value,
    hasConsumerStoppedPropagationRef,
    required,
    defaultChecked,
    isFormControl,
    bubbleInput,
    setBubbleInput
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(SwitchProviderImpl, { scope: __scopeSwitch, ...context, children: isFunction(internal_do_not_use_render) ? internal_do_not_use_render(context) : children });
}
var TRIGGER_NAME = "SwitchTrigger";
var SwitchTrigger = reactExports.forwardRef(
  ({ __scopeSwitch, onClick, ...switchProps }, forwardedRef) => {
    const {
      value,
      disabled,
      checked,
      required,
      setControl,
      setChecked,
      hasConsumerStoppedPropagationRef,
      isFormControl,
      bubbleInput
    } = useSwitchContext(TRIGGER_NAME, __scopeSwitch);
    const composedRefs = useComposedRefs(forwardedRef, setControl);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Primitive.button,
      {
        type: "button",
        role: "switch",
        "aria-checked": checked,
        "aria-required": required,
        "data-state": getState(checked),
        "data-disabled": disabled ? "" : void 0,
        disabled,
        value,
        ...switchProps,
        ref: composedRefs,
        onClick: composeEventHandlers(onClick, (event) => {
          setChecked((prevChecked) => !prevChecked);
          if (bubbleInput && isFormControl) {
            hasConsumerStoppedPropagationRef.current = event.isPropagationStopped();
            if (!hasConsumerStoppedPropagationRef.current) event.stopPropagation();
          }
        })
      }
    );
  }
);
SwitchTrigger.displayName = TRIGGER_NAME;
var Switch$1 = reactExports.forwardRef(
  (props, forwardedRef) => {
    const {
      __scopeSwitch,
      name,
      checked,
      defaultChecked,
      required,
      disabled,
      value,
      onCheckedChange,
      form,
      ...switchProps
    } = props;
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      SwitchProvider,
      {
        __scopeSwitch,
        checked,
        defaultChecked,
        disabled,
        required,
        onCheckedChange,
        name,
        form,
        value,
        internal_do_not_use_render: ({ isFormControl }) => /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            SwitchTrigger,
            {
              ...switchProps,
              ref: forwardedRef,
              __scopeSwitch
            }
          ),
          isFormControl && /* @__PURE__ */ jsxRuntimeExports.jsx(
            SwitchBubbleInput,
            {
              __scopeSwitch
            }
          )
        ] })
      }
    );
  }
);
Switch$1.displayName = SWITCH_NAME;
var THUMB_NAME = "SwitchThumb";
var SwitchThumb = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeSwitch, ...thumbProps } = props;
    const context = useSwitchContext(THUMB_NAME, __scopeSwitch);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Primitive.span,
      {
        "data-state": getState(context.checked),
        "data-disabled": context.disabled ? "" : void 0,
        ...thumbProps,
        ref: forwardedRef
      }
    );
  }
);
SwitchThumb.displayName = THUMB_NAME;
var BUBBLE_INPUT_NAME = "SwitchBubbleInput";
var SwitchBubbleInput = reactExports.forwardRef(
  ({ __scopeSwitch, ...props }, forwardedRef) => {
    const {
      control,
      hasConsumerStoppedPropagationRef,
      checked,
      defaultChecked,
      required,
      disabled,
      name,
      value,
      form,
      bubbleInput,
      setBubbleInput
    } = useSwitchContext(BUBBLE_INPUT_NAME, __scopeSwitch);
    const composedRefs = useComposedRefs(forwardedRef, setBubbleInput);
    const prevChecked = usePrevious(checked);
    const controlSize = useSize(control);
    reactExports.useEffect(() => {
      const input = bubbleInput;
      if (!input) return;
      const inputProto = window.HTMLInputElement.prototype;
      const descriptor = Object.getOwnPropertyDescriptor(
        inputProto,
        "checked"
      );
      const setChecked = descriptor.set;
      const bubbles = !hasConsumerStoppedPropagationRef.current;
      if (prevChecked !== checked && setChecked) {
        const event = new Event("click", { bubbles });
        setChecked.call(input, checked);
        input.dispatchEvent(event);
      }
    }, [bubbleInput, prevChecked, checked, hasConsumerStoppedPropagationRef]);
    const defaultCheckedRef = reactExports.useRef(checked);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Primitive.input,
      {
        type: "checkbox",
        "aria-hidden": true,
        defaultChecked: defaultChecked != null ? defaultChecked : defaultCheckedRef.current,
        required,
        disabled,
        name,
        value,
        form,
        ...props,
        tabIndex: -1,
        ref: composedRefs,
        style: {
          ...props.style,
          ...controlSize,
          position: "absolute",
          pointerEvents: "none",
          opacity: 0,
          margin: 0,
          // We transform because the input is absolutely positioned but we have
          // rendered it **after** the button. This pulls it back to sit on top
          // of the button.
          transform: "translateX(-100%)"
        }
      }
    );
  }
);
SwitchBubbleInput.displayName = BUBBLE_INPUT_NAME;
function isFunction(value) {
  return typeof value === "function";
}
function getState(checked) {
  return checked ? "checked" : "unchecked";
}
function Switch({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Switch$1,
    {
      "data-slot": "switch",
      className: cn(
        "peer data-[state=checked]:bg-primary data-[state=unchecked]:bg-input focus-visible:border-ring focus-visible:ring-ring/50 dark:data-[state=unchecked]:bg-input/80 inline-flex h-[1.15rem] w-8 shrink-0 items-center rounded-full border border-transparent shadow-xs transition-all outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50",
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        SwitchThumb,
        {
          "data-slot": "switch-thumb",
          className: cn(
            "bg-background dark:data-[state=unchecked]:bg-foreground dark:data-[state=checked]:bg-primary-foreground pointer-events-none block size-4 rounded-full ring-0 transition-transform data-[state=checked]:translate-x-[calc(100%-2px)] data-[state=unchecked]:translate-x-0"
          )
        }
      )
    }
  );
}
const listingPlans = {
  free: {
    label: "Free",
    amountUsd: 0,
    billingLabel: "$0 / free"
  },
  starter: {
    label: "Starter",
    amountUsd: 10,
    billingLabel: "$10 / month"
  },
  builder: {
    label: "Builder",
    amountUsd: 100,
    billingLabel: "$100 / year · 22% off"
  }
};
function normalizeUrl(value) {
  const trimmedValue = value.trim();
  if (!trimmedValue) {
    return "";
  }
  if (/^https?:\/\//i.test(trimmedValue)) {
    return trimmedValue;
  }
  return `https://${trimmedValue}`;
}
function OctopusAIListingDialog({
  walletAddress,
  walletRecord,
  onConnectWallet,
  triggerLabel = "Open AI listing",
  embedded = false
}) {
  const [step, setStep] = reactExports.useState(1);
  const [planId, setPlanId] = reactExports.useState("starter");
  const [autoRenewEnabled, setAutoRenewEnabled] = reactExports.useState(true);
  const [iconSrc, setIconSrc] = reactExports.useState("");
  const [iconName, setIconName] = reactExports.useState("");
  const [websiteUrl, setWebsiteUrl] = reactExports.useState("");
  const [detail, setDetail] = reactExports.useState("");
  const [socialUrl, setSocialUrl] = reactExports.useState("");
  const [guideFileName, setGuideFileName] = reactExports.useState("");
  const [guideFileUrl, setGuideFileUrl] = reactExports.useState("");
  const [statusMessage, setStatusMessage] = reactExports.useState("Submit your AI details first, then verify the USDC payment to place the listing in the admin review queue.");
  const [isSubmitting, setIsSubmitting] = reactExports.useState(false);
  const profileDefaults = getDefaultListingSubmissionProfile(walletRecord);
  const selectedPlan = listingPlans[planId];
  const detailWordCount = detail.trim().split(/\s+/).filter(Boolean).length;
  const canGoToPayment = iconSrc.length > 0 && normalizeUrl(websiteUrl).length > 0 && detailWordCount <= 500 && detail.trim().length > 0 && normalizeUrl(socialUrl).length > 0 && guideFileName.length > 0;
  const currentAmount = reactExports.useMemo(() => selectedPlan.amountUsd, [selectedPlan.amountUsd]);
  const handleIconChange = (event) => {
    var _a;
    const file = (_a = event.target.files) == null ? void 0 : _a[0];
    if (!file) {
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setIconSrc(typeof reader.result === "string" ? reader.result : "");
      setIconName(file.name);
    };
    reader.readAsDataURL(file);
  };
  const handleGuideChange = (event) => {
    var _a;
    const file = (_a = event.target.files) == null ? void 0 : _a[0];
    if (!file) {
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setGuideFileUrl(typeof reader.result === "string" ? reader.result : "");
      setGuideFileName(file.name);
    };
    reader.readAsDataURL(file);
  };
  const handleSubmitListing = async () => {
    const connectedWallet = walletAddress != null ? walletAddress : await onConnectWallet();
    if (!connectedWallet) {
      setStatusMessage("Connect a Phantom wallet first to continue with the AI listing flow.");
      return;
    }
    const appendSubmission = (paymentReference, paymentRequestId) => {
      appendAIListingSubmission({
        id: `listing-${Date.now()}`,
        walletAddress: connectedWallet,
        displayName: (walletRecord == null ? void 0 : walletRecord.displayName) || (walletRecord == null ? void 0 : walletRecord.username) || profileDefaults.displayName,
        twitterHandle: (walletRecord == null ? void 0 : walletRecord.twitterHandle) || profileDefaults.twitterHandle,
        iconSrc,
        iconName,
        websiteUrl: normalizeUrl(websiteUrl),
        description: detail.trim(),
        socialUrl: normalizeUrl(socialUrl),
        guideFileName,
        guideFileUrl,
        planId,
        billingLabel: selectedPlan.billingLabel,
        amountUsd: currentAmount,
        autoRenewEnabled,
        status: "pending",
        badge: "none",
        paymentReference,
        paymentRequestId,
        visibleInExplore: true,
        visitorCount: 0
      });
    };
    if (currentAmount === 0) {
      appendSubmission();
      setStatusMessage("Your free AI listing is now visible in Explore AI and is waiting for admin review.");
      setStep(1);
      return;
    }
    const provider = getSolanaProvider();
    if (!(provider == null ? void 0 : provider.signAndSendTransaction) && !(provider == null ? void 0 : provider.signTransaction)) {
      setStatusMessage("This wallet cannot complete the live USDC listing payment yet.");
      return;
    }
    try {
      setIsSubmitting(true);
      setStatusMessage("Phantom is opening so you can validate the USDC payment for this AI listing.");
      const paymentRequest = await buildTransaction({
        kind: "listing",
        recipient: solanaPaymentAddress,
        amount: currentAmount,
        walletAddress: connectedWallet,
        currency: "USDC",
        tokenMint: solanaUsdcMintAddress,
        tokenDecimals: 6,
        label: "Octopus Market AI listing",
        message: `${selectedPlan.label} AI listing payment`,
        memo: `${selectedPlan.label} AI listing subscription`,
        metadata: {
          onChainTransfer: true,
          plan: selectedPlan.label,
          listingAmountUsd: currentAmount,
          listingAmountUsdc: currentAmount,
          totalChargeUsdc: currentAmount,
          reserveFee: 0,
          username: (walletRecord == null ? void 0 : walletRecord.displayName) || (walletRecord == null ? void 0 : walletRecord.username) || profileDefaults.displayName
        }
      });
      await submitSolanaTransfer(paymentRequest);
      const foundReference = await findReference(paymentRequest.reference);
      if (!(foundReference == null ? void 0 : foundReference.signature)) {
        throw new Error("reference-not-found");
      }
      await validateTransfer(foundReference.signature, {
        recipient: solanaPaymentAddress,
        amount: currentAmount,
        reference: paymentRequest.reference,
        currency: "USDC",
        tokenMint: solanaUsdcMintAddress,
        tokenDecimals: 6
      });
      const validatedPayment = await fetchTransaction(paymentRequest.id);
      if (!validatedPayment || validatedPayment.status !== "validated") {
        throw new Error("validated-transfer-required");
      }
      appendSubmission(validatedPayment.reference, validatedPayment.id);
      setStatusMessage("Your AI listing is now visible in Explore AI and is waiting for admin review, moderation, and badge decisions.");
      setStep(1);
    } catch (error) {
      setStatusMessage(error instanceof Error ? `The AI listing payment could not be completed: ${error.message}` : "The AI listing payment failed.");
    } finally {
      setIsSubmitting(false);
    }
  };
  const content = /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: embedded ? "min-h-0 space-y-5" : "space-y-6", "data-forge-id": "forge-9lqdy8-249-4", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:249:4:415:10", children: [
    !embedded ? /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { "data-forge-id": "forge-9lqv0b-251-8", "data-component": "DialogHeader", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:251:8:259:23", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "mb-2 w-fit border border-orange-200 bg-orange-100 text-orange-700 hover:bg-orange-100 dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-dlp47v-252-10", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:252:10:254:18", children: "AI listing submission" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { className: "text-2xl", "data-forge-id": "forge-dlr16g-255-10", "data-component": "DialogTitle", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:255:10:255:92", children: "Submit a new AI for Octopus Market" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { className: "text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-dlro5z-256-10", "data-component": "DialogDescription", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:256:10:258:30", children: "Step 1 collects your AI details. Step 2 confirms the payment only when the selected plan is paid. Free listings are published immediately in Explore AI and still go through admin review." })
    ] }) : null,
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: embedded ? "max-h-[78vh] overflow-y-auto overscroll-contain pr-2 lg:max-h-[82vh]" : "max-h-[80vh] overflow-y-auto overscroll-contain pr-2", "data-forge-id": "forge-9lriqh-262-6", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:262:6:414:12", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-6 lg:grid-cols-[1.35fr_0.85fr] xl:grid-cols-[1.55fr_0.75fr]", "data-forge-id": "forge-9lrjh8-263-8", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:263:8:413:14", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", "data-forge-id": "forge-dma6sa-264-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:264:10:353:16", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 md:grid-cols-2", "data-forge-id": "forge-dmatrv-265-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:265:12:283:18", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: step === 1 ? "default" : "outline", className: step === 1 ? "min-h-12 justify-center rounded-2xl bg-orange-500 px-4 text-center text-sm text-white hover:bg-orange-400 md:whitespace-nowrap" : "min-h-12 justify-center rounded-2xl border-orange-200 bg-white px-4 text-center text-sm text-zinc-950 hover:bg-orange-50 md:whitespace-nowrap dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900", onClick: () => setStep(1), "data-forge-id": "forge-dmbgrg-266-14", "data-component": "Button", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:266:14:273:23", children: "Step 1 · AI details" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", variant: step === 2 ? "default" : "outline", className: step === 2 ? "min-h-12 justify-center rounded-2xl bg-orange-500 px-4 text-center text-sm text-white hover:bg-orange-400 md:whitespace-nowrap" : "min-h-12 justify-center rounded-2xl border-orange-200 bg-white px-4 text-center text-sm text-zinc-950 hover:bg-orange-50 md:whitespace-nowrap dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900", onClick: () => setStep(2), disabled: !canGoToPayment, "data-forge-id": "forge-dmtzdr-274-14", "data-component": "Button", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:274:14:282:23", children: [
            "Step 2 · ",
            currentAmount === 0 ? "Review listing" : "Pay with USDC"
          ] })
        ] }),
        step === 1 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 rounded-3xl border border-orange-200 bg-orange-50/70 p-5 xl:min-h-[31rem] dark:border-white/10 dark:bg-white/5", "data-forge-id": "forge-dnf1y6-286-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:286:14:322:20", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block rounded-2xl border border-dashed border-orange-300 bg-white p-4 text-sm text-zinc-700 dark:border-white/10 dark:bg-zinc-950 dark:text-zinc-300", "data-forge-id": "forge-dnfoxr-287-16", "data-component": "label", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:287:16:294:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "mb-2 flex items-center gap-2 font-medium", "data-forge-id": "forge-dngbxc-288-18", "data-component": "span", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:288:18:291:25", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ImagePlus, { className: "size-4 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-dngyxi-289-20", "data-component": "ImagePlus", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:289:20:289:89" }),
              "Submit AI icon"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", accept: "image/*", className: "mt-2 block w-full text-xs", onChange: handleIconChange, "data-forge-id": "forge-dnwalj-292-18", "data-component": "input", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:292:18:292:122" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mt-3 block text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-dnwxl2-293-18", "data-component": "span", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:293:18:293:128", children: iconName || "PNG, JPG, or WEBP" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: websiteUrl, onChange: (event) => setWebsiteUrl(event.target.value), placeholder: "AI website URL", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-dny7k2-295-16", "data-component": "Input", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:295:16:300:18" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: detail, onChange: (event) => setDetail(event.target.value), placeholder: "AI details, maximum 500 words", className: "min-h-44 border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-dzz4nw-301-16", "data-component": "Textarea", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:301:16:306:18" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-right text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-e02yl2-307-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:307:16:307:120", children: [
            detailWordCount,
            " / 500 words"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: socialUrl, onChange: (event) => setSocialUrl(event.target.value), placeholder: "AI social network URL", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-e03lkl-308-16", "data-component": "Input", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:308:16:313:18" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block rounded-2xl border border-dashed border-orange-300 bg-white p-4 text-sm text-zinc-700 dark:border-white/10 dark:bg-zinc-950 dark:text-zinc-300", "data-forge-id": "forge-e0ku7u-314-16", "data-component": "label", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:314:16:321:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "mb-2 flex items-center gap-2 font-medium", "data-forge-id": "forge-e0lh7f-315-18", "data-component": "span", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:315:18:318:25", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "size-4 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-e0m47l-316-20", "data-component": "FileText", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:316:20:316:88" }),
              "Submit a PDF guide"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", accept: "application/pdf", className: "mt-2 block w-full text-xs", onChange: handleGuideChange, "data-forge-id": "forge-e0o15j-319-18", "data-component": "input", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:319:18:319:131" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mt-3 block text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-e122v5-320-18", "data-component": "span", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:320:18:320:134", children: guideFileName || "PDF guide required" })
          ] })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 rounded-3xl border border-orange-200 bg-orange-50/70 p-5 xl:min-h-[31rem] dark:border-white/10 dark:bg-white/5", "data-forge-id": "forge-e14mt5-324-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:324:14:351:20", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-3 lg:grid-cols-3", "data-forge-id": "forge-e159sq-325-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:325:16:341:22", children: Object.entries(listingPlans).map(([key, plan]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => setPlanId(key), className: `rounded-2xl border p-4 text-left transition ${planId === key ? "border-orange-300 bg-white shadow-sm dark:border-orange-400/40 dark:bg-orange-500/10" : "border-orange-200 bg-white hover:border-orange-300 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:hover:bg-zinc-900"}`, "data-forge-id": "forge-e16jsh-327-20", "data-component": "button", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:327:20:339:29", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-e1qcdw-337-22", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:337:22:337:95", children: plan.label }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-e1qzdf-338-22", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:338:22:338:106", children: plan.billingLabel })
          ] }, key)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-4 rounded-2xl border border-orange-200 bg-white px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-e26y0v-342-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:342:16:350:22", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-e27l0g-343-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:343:18:348:24", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-e2880m-344-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:344:20:344:98", children: "Automatic renewal" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-e28v05-345-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:345:20:347:24", children: "Activate or disable the recurring payment from your account settings when you choose a paid plan." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { checked: autoRenewEnabled, onCheckedChange: setAutoRenewEnabled, disabled: planId === "free", "data-forge-id": "forge-e2bexm-349-18", "data-component": "Switch", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:349:18:349:122" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5", "data-forge-id": "forge-e2snkn-355-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:355:10:412:16", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "border-orange-200 bg-white dark:border-white/10 dark:bg-white/5", "data-forge-id": "forge-e2tak8-356-12", "data-component": "Card", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:356:12:405:19", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4 p-5", "data-forge-id": "forge-e2txjt-357-14", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:357:14:404:28", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-sm font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-e2ukje-358-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:358:16:361:22", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Receipt, { className: "size-4 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-e2v7iz-359-18", "data-component": "Receipt", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:359:18:359:85" }),
            "Listing summary"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50/80 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-e3aj7l-362-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:362:16:365:22", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-e3b676-363-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:363:18:363:119", children: "Linked wallet" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 break-all font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-e3bt6p-364-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:364:18:364:142", children: walletAddress || "Connect Phantom to continue" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50/80 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-e3d35p-366-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:366:16:372:22", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-e3dq5a-367-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:367:18:367:113", children: "Profile" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-e3ed4t-368-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:368:18:370:22", children: (walletRecord == null ? void 0 : walletRecord.displayName) || (walletRecord == null ? void 0 : walletRecord.username) || profileDefaults.displayName || "No profile saved" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-e3toth-371-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:371:18:371:168", children: (walletRecord == null ? void 0 : walletRecord.twitterHandle) || profileDefaults.twitterHandle || "No X handle saved" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-1", "data-forge-id": "forge-e3uysh-373-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:373:16:384:22", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50/80 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-e3vls2-374-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:374:18:377:24", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-e3w8s8-375-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:375:20:375:121", children: "Selected plan" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-e3wvrr-376-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:376:20:376:116", children: selectedPlan.label })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50/80 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-e3y5q6-378-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:378:18:383:24", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-e3ysqc-379-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:379:20:379:115", children: "Payment" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-e4cufy-380-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:380:20:382:24", children: currentAmount === 0 ? "Free listing" : `${currentAmount.toFixed(2)} ${paymentTokenSymbol}` })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50/80 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-e4g1cw-385-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:385:16:393:22", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-e4goch-386-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:386:18:386:122", children: "Validation rules" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 space-y-2 text-sm text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-e4hbc0-387-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:387:18:392:24", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { "data-forge-id": "forge-e4hyc6-388-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:388:20:388:113", children: "Listing becomes visible immediately in Explore AI and remains subject to admin review." }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { "data-forge-id": "forge-e4ilbp-389-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:389:20:389:56", children: "No badge is added by default." }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { "data-forge-id": "forge-e4wn1b-390-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:390:20:390:69", children: "The blue badge is controlled by the admin." }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { "data-forge-id": "forge-e4xa0u-391-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:391:20:391:81", children: "The gold badge stays free only after 6 months minimum." })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "bg-orange-100 dark:bg-white/10", "data-forge-id": "forge-e4z6yq-394-16", "data-component": "Separator", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:394:16:394:72" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", className: "w-full rounded-2xl bg-orange-500 text-white hover:bg-orange-400", onClick: () => void handleSubmitListing(), disabled: !canGoToPayment || isSubmitting, "data-forge-id": "forge-e4zty9-395-16", "data-component": "Button", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:395:16:403:25", children: [
            isSubmitting ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-4 animate-spin", "data-forge-id": "forge-eh0r3r-401-34", "data-component": "LoaderCircle", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:401:34:401:82" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Wallet, { className: "size-4", "data-forge-id": "forge-eh0r83-401-85", "data-component": "Wallet", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:401:85:401:114" }),
            currentAmount === 0 ? "Submit free listing" : "Pay with USDC"
          ] })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Alert, { className: "border-orange-200 bg-orange-50/70 text-zinc-950 dark:border-white/10 dark:bg-white/5 dark:text-white", "data-forge-id": "forge-eh4kz5-407-12", "data-component": "Alert", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:407:12:411:20", children: [
          isSubmitting ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-4 animate-spin", "data-forge-id": "forge-eh580c-408-30", "data-component": "LoaderCircle", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:408:30:408:78" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "size-4", "data-forge-id": "forge-eh584o-408-81", "data-component": "ShieldCheck", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:408:81:408:115" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(AlertTitle, { "data-forge-id": "forge-eh5uy9-409-14", "data-component": "AlertTitle", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:409:14:409:109", children: isSubmitting ? "Payment validation in progress" : "Listing workflow" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDescription, { "data-forge-id": "forge-ehjwnv-410-14", "data-component": "AlertDescription", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:410:14:410:66", children: statusMessage })
        ] })
      ] })
    ] }) })
  ] });
  if (embedded) {
    return content;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Dialog, { "data-forge-id": "forge-9mskpq-423-4", "data-component": "Dialog", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:423:4:430:13", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTrigger, { asChild: true, "data-forge-id": "forge-9mslgh-424-6", "data-component": "DialogTrigger", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:424:6:426:22", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { className: "rounded-2xl bg-orange-500 text-white hover:bg-orange-400", "data-forge-id": "forge-9msm78-425-8", "data-component": "Button", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:425:8:425:108", children: triggerLabel }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(DialogContent, { className: "max-h-[94vh] w-[98vw] max-w-[98vw] overflow-hidden border-orange-200 bg-white text-zinc-950 sm:max-w-[96vw] xl:max-w-[1440px] dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-9msnok-427-6", "data-component": "DialogContent", "data-source-pos": "src/components/octopus-market/octopus-ai-listing-dialog.tsx:427:6:429:22", children: content })
  ] });
}
const octopusAiListingDialog = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  OctopusAIListingDialog
}, Symbol.toStringTag, { value: "Module" }));
export {
  Dialog as D,
  ImagePlus as I,
  OctopusAIListingDialog as O,
  Switch as S,
  DialogContent as a,
  DialogHeader as b,
  DialogTitle as c,
  DialogDescription as d,
  useSize as e,
  octopusAiListingDialog as o,
  usePrevious as u
};
