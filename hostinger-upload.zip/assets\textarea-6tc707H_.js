import { j as jsxRuntimeExports, aw as cn } from "./index-C-7_nSR2.js";
function Textarea({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("textarea", { "data-slot": "textarea", className: cn("border-input placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive dark:bg-input/30 flex field-sizing-content min-h-16 w-full rounded-md border bg-transparent px-3 py-2 text-base shadow-xs transition-[color,box-shadow] outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className), "data-forge-id": "forge-ssk90-7-4", "data-component": "textarea", "data-source-pos": "src/components/ui/textarea.tsx:7:4:14:6", ...props });
}
export {
  Textarea as T
};
