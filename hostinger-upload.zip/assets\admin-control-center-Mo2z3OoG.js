import { c as createLucideIcon, r as reactExports, j as jsxRuntimeExports, C as Card, a as CardHeader, B as Badge, b as CardTitle, d as Button, e as CardContent, I as Input, u as upsertAdminPaymentNotification, f as updateAdminPaymentNotificationStatus, p as predictionMarketTreasuryAddress, g as readPredictionResolutions, h as readCentralWalletRecords, i as readCentralPaymentRecords, k as readCentralHistoryRecords, l as getClaimedPredictions, m as hydrateCentralRegistry, n as readAdminPaymentNotifications, s as subscribeToCentralRegistry, o as subscribeToAdminStorage, q as subscribeToPredictionMarketStorage, t as subscribeToAIListings, v as readAIListings, w as appendAIListingSubmission, x as markClaimAsPaid, y as toast, z as CardDescription, S as ShieldCheck, A as Separator, D as formatWalletAddress, E as updateAIListingSubmission, F as syncAdminNotificationsFromTreasury } from "./index-C-7_nSR2.js";
import { T as Textarea } from "./textarea-6tc707H_.js";
import { C as CircleCheck } from "./circle-check-DVTHR8mg.js";
import { C as Coins } from "./coins-Cw0iSkkx.js";
const __iconNode$2 = [
  ["path", { d: "M10.268 21a2 2 0 0 0 3.464 0", key: "vwvbt9" }],
  [
    "path",
    {
      d: "M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",
      key: "11g9vi"
    }
  ]
];
const Bell = createLucideIcon("bell", __iconNode$2);
const __iconNode$1 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m15 9-6 6", key: "1uzhvr" }],
  ["path", { d: "m9 9 6 6", key: "z0biqf" }]
];
const CircleX = createLucideIcon("circle-x", __iconNode$1);
const __iconNode = [
  ["path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", key: "1yyitq" }],
  ["path", { d: "M16 3.128a4 4 0 0 1 0 7.744", key: "16gr8j" }],
  ["path", { d: "M22 21v-2a4 4 0 0 0-3-3.87", key: "kshegd" }],
  ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }]
];
const Users = createLucideIcon("users", __iconNode);
const paymentFlowOptions = ["prediction", "launch", "listing"];
function formatMoment$1(timestamp) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(timestamp));
}
function AdminPaymentsManualConfirm({
  walletAddress,
  initialPending
}) {
  const [showManualForm, setShowManualForm] = reactExports.useState(false);
  const [toast2, setToast] = reactExports.useState(null);
  const [manualForm, setManualForm] = reactExports.useState({
    username: "",
    type: "prediction",
    amount: "",
    txSignature: "",
    userWallet: "",
    title: ""
  });
  const pendingPayments = reactExports.useMemo(() => initialPending.filter((payment) => payment.status === "pending"), [initialPending]);
  const showToast = (message) => {
    setToast(message);
    window.setTimeout(() => setToast(null), 3e3);
  };
  const handleManualAdd = () => {
    const amount = Number(manualForm.amount);
    if (!manualForm.username.trim() || !manualForm.txSignature.trim() || !manualForm.userWallet.trim() || !manualForm.title.trim() || !Number.isFinite(amount) || amount <= 0) {
      showToast("Fill every field before adding a manual payment.");
      return;
    }
    const paymentReference = `manual-${Date.now()}`;
    upsertAdminPaymentNotification({
      id: `admin-${paymentReference}`,
      paymentRequestId: paymentReference,
      paymentReference,
      flow: manualForm.type,
      title: manualForm.title.trim(),
      subtitle: "Manual confirmation queue",
      username: manualForm.username.trim(),
      userWallet: manualForm.userWallet.trim(),
      recipientWallet: walletAddress || predictionMarketTreasuryAddress,
      amountUsdc: amount,
      reserveFeeUsdc: 0,
      totalPaidUsdc: amount,
      createdAt: Date.now(),
      status: "pending"
    });
    setManualForm({
      username: "",
      type: "prediction",
      amount: "",
      txSignature: "",
      userWallet: "",
      title: ""
    });
    setShowManualForm(false);
    showToast("Manual payment added to the pending approval queue.");
  };
  const handleManualApprove = (paymentReference) => {
    updateAdminPaymentNotificationStatus(paymentReference, "approved", walletAddress || predictionMarketTreasuryAddress);
    showToast("Payment approved manually.");
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950/80 dark:text-white", "data-forge-id": "forge-1dspqm-112-4", "data-component": "Card", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:112:4:235:11", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { className: "flex flex-row items-start justify-between gap-4", "data-forge-id": "forge-1dsqhd-113-6", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:113:6:128:19", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-1dsr84-114-8", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:114:8:119:14", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "mb-3 border border-orange-200 bg-orange-100 text-orange-700 hover:bg-orange-100 dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-s5bz4u-115-10", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:115:10:117:18", children: "Manual admin confirm" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-xl", "data-forge-id": "forge-s5a269-118-10", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:118:10:118:84", children: "Temporary manual payment review" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", className: "rounded-2xl border-orange-200 bg-white text-zinc-950 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-900 dark:text-white dark:hover:bg-zinc-800", onClick: () => setShowManualForm((currentValue) => !currentValue), "data-forge-id": "forge-1dtb8v-120-8", "data-component": "Button", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:120:8:127:17", children: showManualForm ? "Close" : "Add manually" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4", "data-forge-id": "forge-1dthx2-129-6", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:129:6:234:20", children: [
      toast2 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-orange-200 bg-orange-50 px-4 py-3 text-sm text-orange-700 dark:border-orange-400/20 dark:bg-orange-500/10 dark:text-orange-300", "data-forge-id": "forge-s4axw8-131-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:131:10:133:16", children: toast2 }) : null,
      showManualForm ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 rounded-2xl border border-orange-100 bg-orange-50 p-4 md:grid-cols-2 xl:grid-cols-6 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-s473z2-137-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:137:10:195:16", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: manualForm.username, onChange: (event) => setManualForm((currentValue) => ({
          ...currentValue,
          username: event.target.value
        })), placeholder: "Username", className: "border-orange-200 bg-white dark:border-white/10 dark:bg-zinc-950", "data-forge-id": "forge-s46gzh-138-12", "data-component": "Input", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:138:12:143:14" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: manualForm.userWallet, onChange: (event) => setManualForm((currentValue) => ({
          ...currentValue,
          userWallet: event.target.value
        })), placeholder: "User wallet", className: "border-orange-200 bg-white dark:border-white/10 dark:bg-zinc-950", "data-forge-id": "forge-s3p8c8-144-12", "data-component": "Input", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:144:12:149:14" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: manualForm.title, onChange: (event) => setManualForm((currentValue) => ({
          ...currentValue,
          title: event.target.value
        })), placeholder: "Flow title", className: "border-orange-200 bg-white dark:border-white/10 dark:bg-zinc-950", "data-forge-id": "forge-s37zoz-150-12", "data-component": "Input", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:150:12:155:14" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("select", { value: manualForm.type, onChange: (event) => setManualForm((currentValue) => ({
          ...currentValue,
          type: event.target.value
        })), className: "h-10 rounded-md border border-orange-200 bg-white px-3 text-sm dark:border-white/10 dark:bg-zinc-950", "data-forge-id": "forge-s345rt-156-12", "data-component": "select", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:156:12:171:21", children: paymentFlowOptions.map((option) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: option, "data-forge-id": "forge-s2jq6t-167-16", "data-component": "option", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:167:16:169:25", children: option }, option)) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", step: "0.01", value: manualForm.amount, onChange: (event) => setManualForm((currentValue) => ({
          ...currentValue,
          amount: event.target.value
        })), placeholder: "Amount in USDC", className: "border-orange-200 bg-white dark:border-white/10 dark:bg-zinc-950", "data-forge-id": "forge-s234j7-172-12", "data-component": "Input", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:172:12:179:14" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: manualForm.txSignature, onChange: (event) => setManualForm((currentValue) => ({
          ...currentValue,
          txSignature: event.target.value
        })), placeholder: "Tx signature", className: "border-orange-200 bg-white dark:border-white/10 dark:bg-zinc-950", "data-forge-id": "forge-s1klww-180-12", "data-component": "Input", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:180:12:185:14" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "md:col-span-2 xl:col-span-6", "data-forge-id": "forge-s1grzq-186-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:186:12:194:18", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", className: "rounded-2xl bg-orange-500 text-white hover:bg-orange-400", onClick: handleManualAdd, "data-forge-id": "forge-s1g505-187-14", "data-component": "Button", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:187:14:193:23", children: "Add and send to pending approvals" }) })
      ] }) : null,
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", "data-forge-id": "forge-1dxy34-198-8", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:198:8:233:14", children: pendingPayments.length > 0 ? pendingPayments.slice(0, 5).map((payment) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-rowpa0-201-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:201:14:226:20", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3", "data-forge-id": "forge-rou5bu-205-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:205:16:225:22", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-rotic9-206-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:206:18:211:24", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-rosvc3-207-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:207:20:207:96", children: payment.title }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-ros8ck-208-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:208:20:210:24", children: [
            payment.username || payment.userWallet,
            " · ",
            payment.flow,
            " · ",
            formatMoment$1(payment.createdAt)
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", "data-forge-id": "forge-roc9p0-212-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:212:18:224:24", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-sm font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-robmou-213-20", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:213:20:215:27", children: [
            payment.totalPaidUsdc.toFixed(2),
            " USDC"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", size: "sm", className: "rounded-full bg-emerald-600 text-white hover:bg-emerald-500", onClick: () => handleManualApprove(payment.paymentReference), "data-forge-id": "forge-ro9pq9-216-20", "data-component": "Button", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:216:20:223:29", children: "Approve manually" })
        ] })
      ] }) }, payment.id)) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-dashed border-orange-200 bg-white px-4 py-4 text-sm text-zinc-600 dark:border-white/10 dark:bg-zinc-950/80 dark:text-zinc-400", "data-forge-id": "forge-rno074-229-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-payments-manual-confirm.tsx:229:12:231:18", children: "No manual approval is waiting right now." }) })
    ] })
  ] });
}
function formatCurrency(amount) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 2
  }).format(amount);
}
function formatMoment(timestamp) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(timestamp));
}
function formatNotificationWalletLabel(notification, walletSummaryByAddress) {
  const walletSummary = walletSummaryByAddress[notification.userWallet];
  return (walletSummary == null ? void 0 : walletSummary.walletRecord.displayName) || (walletSummary == null ? void 0 : walletSummary.walletRecord.username) || notification.username || "Unknown wallet";
}
function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : "");
    reader.onerror = () => reject(new Error("file-read-error"));
    reader.readAsDataURL(file);
  });
}
function AdminControlCenter({
  walletAddress
}) {
  const [walletRecords, setWalletRecords] = reactExports.useState([]);
  const [paymentRecords, setPaymentRecords] = reactExports.useState([]);
  const [historyRecords, setHistoryRecords] = reactExports.useState([]);
  const [resolutions, setResolutions] = reactExports.useState(() => readPredictionResolutions());
  const [claimsHistory, setClaimsHistory] = reactExports.useState([]);
  const [markingPaidId, setMarkingPaidId] = reactExports.useState(null);
  const [selectedPanel, setSelectedPanel] = reactExports.useState("pending");
  const [aiListingRefreshIndex, setAIListingRefreshIndex] = reactExports.useState(0);
  const [reviewActionByReference, setReviewActionByReference] = reactExports.useState({});
  const [showAdminListingForm, setShowAdminListingForm] = reactExports.useState(false);
  const [adminListingStatusMessage, setAdminListingStatusMessage] = reactExports.useState("Admin can publish an AI listing with 0 fee and make it visible immediately on the platform.");
  const [adminListingDraft, setAdminListingDraft] = reactExports.useState({
    displayName: "",
    twitterHandle: "",
    websiteUrl: "",
    description: "",
    socialUrl: "",
    iconSrc: "",
    iconName: "",
    guideFileName: "",
    guideFileUrl: ""
  });
  const loadCentralData = reactExports.useCallback(async () => {
    const [nextWalletRecords, nextPaymentRecords, nextHistoryRecords] = await Promise.all([readCentralWalletRecords(), readCentralPaymentRecords(), readCentralHistoryRecords()]);
    setWalletRecords(nextWalletRecords);
    setPaymentRecords(nextPaymentRecords);
    setHistoryRecords(nextHistoryRecords);
  }, []);
  const loadClaims = reactExports.useCallback(async () => {
    const rows = await getClaimedPredictions();
    setClaimsHistory(rows.map((row) => {
      var _a, _b, _c;
      return {
        id: row.id,
        marketId: row.market_id,
        marketTitle: row.market_title,
        categoryLabel: row.category_label,
        selectionId: row.selection_id,
        selectionLabel: row.selection_label,
        amount: Number(row.amount),
        reserveFee: Number(row.reserve_fee),
        totalCharged: Number(row.total_charged),
        claimFeeRate: Number(row.claim_fee_rate),
        payoutMultiple: Number(row.payout_multiple),
        grossReward: Number(row.gross_reward),
        netReward: Number(row.net_reward),
        walletAddress: row.wallet_address,
        paymentReference: row.payment_reference,
        paymentRequestId: row.payment_request_id,
        createdAt: new Date(row.created_at).getTime(),
        reportedAt: new Date(row.reported_at).getTime(),
        claimedAt: row.claimed_at ? new Date(row.claimed_at).getTime() : void 0,
        claimReference: (_a = row.claim_reference) != null ? _a : void 0,
        payoutStatus: (_b = row.payout_status) != null ? _b : void 0,
        paidAt: row.paid_at ? new Date(row.paid_at).getTime() : void 0,
        paidByWallet: (_c = row.paid_by_wallet) != null ? _c : void 0
      };
    }));
  }, []);
  reactExports.useEffect(() => {
    void hydrateCentralRegistry({
      payments: readAdminPaymentNotifications()
    }).then(loadCentralData);
    void loadClaims();
  }, [loadCentralData, loadClaims]);
  reactExports.useEffect(() => {
    return subscribeToCentralRegistry(() => {
      void loadCentralData();
    });
  }, [loadCentralData]);
  reactExports.useEffect(() => {
    return subscribeToAdminStorage(() => {
      void hydrateCentralRegistry({
        payments: readAdminPaymentNotifications()
      }).then(loadCentralData);
    });
  }, [loadCentralData]);
  reactExports.useEffect(() => {
    return subscribeToPredictionMarketStorage(() => {
      setResolutions(readPredictionResolutions());
      void loadClaims();
      void hydrateCentralRegistry().then(loadCentralData);
    });
  }, [loadCentralData, loadClaims]);
  reactExports.useEffect(() => {
    return subscribeToAIListings(() => {
      setAIListingRefreshIndex((currentValue) => currentValue + 1);
    });
  }, []);
  reactExports.useEffect(() => {
    if (!walletAddress || walletAddress !== predictionMarketTreasuryAddress) {
      return;
    }
    const syncTreasuryPayments = () => {
      void syncAdminNotificationsFromTreasury().then(() => {
        void hydrateCentralRegistry({
          payments: readAdminPaymentNotifications()
        }).then(loadCentralData);
      });
    };
    const handleVisibilitySync = () => {
      if (!document.hidden) {
        syncTreasuryPayments();
      }
    };
    syncTreasuryPayments();
    const intervalId = window.setInterval(syncTreasuryPayments, 12e3);
    window.addEventListener("focus", handleVisibilitySync);
    document.addEventListener("visibilitychange", handleVisibilitySync);
    return () => {
      window.clearInterval(intervalId);
      window.removeEventListener("focus", handleVisibilitySync);
      document.removeEventListener("visibilitychange", handleVisibilitySync);
    };
  }, [loadCentralData, walletAddress]);
  const isAdminWallet = walletAddress === predictionMarketTreasuryAddress;
  const pendingNotifications = reactExports.useMemo(() => paymentRecords.filter((notification) => notification.status === "pending"), [paymentRecords]);
  const approvedNotifications = reactExports.useMemo(() => paymentRecords.filter((notification) => notification.status === "approved"), [paymentRecords]);
  const rejectedNotifications = reactExports.useMemo(() => paymentRecords.filter((notification) => notification.status === "rejected"), [paymentRecords]);
  const predictionParticipants = reactExports.useMemo(() => paymentRecords.filter((notification) => notification.flow === "prediction" && notification.userWallet !== predictionMarketTreasuryAddress), [paymentRecords]);
  const walletSummaries = reactExports.useMemo(() => {
    return walletRecords.filter((walletRecord) => walletRecord.address !== predictionMarketTreasuryAddress).map((walletRecord) => {
      const entries = historyRecords.filter((entry) => entry.walletAddress === walletRecord.address);
      const payments = paymentRecords.filter((payment) => payment.userWallet === walletRecord.address);
      const approvedReferences = new Set(payments.filter((payment) => payment.status === "approved").map((payment) => payment.paymentReference));
      const rejectedReferences = new Set(payments.filter((payment) => payment.status === "rejected").map((payment) => payment.paymentReference));
      const totalWon = entries.reduce((total, entry) => {
        if (approvedReferences.has(entry.paymentReference) && entry.claimedAt) {
          return total + entry.netReward;
        }
        return total;
      }, 0);
      const totalLost = entries.reduce((total, entry) => {
        if (rejectedReferences.has(entry.paymentReference)) {
          return total + entry.totalCharged;
        }
        const resolution = resolutions[entry.marketId];
        const payment = payments.find((item) => item.paymentReference === entry.paymentReference);
        if ((payment == null ? void 0 : payment.status) === "approved" && resolution && resolution.outcomeId !== entry.selectionId) {
          return total + entry.totalCharged;
        }
        return total;
      }, 0);
      return {
        address: walletRecord.address,
        walletRecord,
        entries,
        payments,
        predictionCount: payments.filter((payment) => payment.flow === "prediction").length,
        pendingCount: payments.filter((payment) => payment.status === "pending").length,
        approvedCount: payments.filter((payment) => payment.status === "approved").length,
        rejectedCount: payments.filter((payment) => payment.status === "rejected").length,
        totalWon,
        totalLost,
        totalStaked: entries.reduce((total, entry) => total + entry.amount, 0)
      };
    }).sort((left, right) => right.walletRecord.latestActivityAt - left.walletRecord.latestActivityAt);
  }, [historyRecords, paymentRecords, resolutions, walletRecords]);
  const walletSummaryByAddress = reactExports.useMemo(() => walletSummaries.reduce((summaries, summary) => {
    summaries[summary.address] = summary;
    return summaries;
  }, {}), [walletSummaries]);
  const uniquePredictionWallets = reactExports.useMemo(() => Array.from(new Set(predictionParticipants.map((notification) => notification.userWallet))), [predictionParticipants]);
  const adminWalletSummary = reactExports.useMemo(() => {
    if (!walletAddress) {
      return null;
    }
    const receivedNotifications = paymentRecords.filter((notification) => notification.recipientWallet === walletAddress);
    const reviewedNotifications = paymentRecords.filter((notification) => notification.reviewedByWallet === walletAddress);
    const resolvedMarketsCount = Object.values(resolutions).filter((resolution) => resolution.resolvedByWallet === walletAddress).length;
    const lastActivityAt = [...receivedNotifications.map((notification) => notification.updatedAt || notification.createdAt), ...reviewedNotifications.map((notification) => {
      var _a;
      return (_a = notification.reviewedAt) != null ? _a : 0;
    }), ...Object.values(resolutions).filter((resolution) => resolution.resolvedByWallet === walletAddress).map((resolution) => resolution.resolvedAt)].reduce((latest, value) => Math.max(latest, value), 0);
    return {
      address: walletAddress,
      connectedNow: true,
      lastActivityAt: lastActivityAt || null,
      receivedPaymentsCount: receivedNotifications.length,
      pendingReceivedCount: receivedNotifications.filter((notification) => notification.status === "pending").length,
      approvedReceivedCount: receivedNotifications.filter((notification) => notification.status === "approved").length,
      rejectedReceivedCount: receivedNotifications.filter((notification) => notification.status === "rejected").length,
      totalReceivedUsdc: receivedNotifications.reduce((total, notification) => total + notification.totalPaidUsdc, 0),
      totalApprovedUsdc: receivedNotifications.filter((notification) => notification.status === "approved").reduce((total, notification) => total + notification.totalPaidUsdc, 0),
      totalPendingUsdc: receivedNotifications.filter((notification) => notification.status === "pending").reduce((total, notification) => total + notification.totalPaidUsdc, 0),
      reviewedPaymentsCount: reviewedNotifications.length,
      resolvedMarketsCount
    };
  }, [paymentRecords, resolutions, walletAddress]);
  const participantGroups = reactExports.useMemo(() => {
    return predictionParticipants.reduce((groups, participant) => {
      var _a;
      const key = participant.categoryLabel || "Prediction";
      groups[key] = [...(_a = groups[key]) != null ? _a : [], participant];
      return groups;
    }, {});
  }, [predictionParticipants]);
  reactExports.useEffect(() => {
    setReviewActionByReference((currentValue) => {
      const activeReferences = new Set(pendingNotifications.map((notification) => notification.paymentReference));
      let hasChange = false;
      const nextValue = Object.fromEntries(Object.entries(currentValue).filter(([paymentReference]) => {
        const shouldKeep = activeReferences.has(paymentReference);
        if (!shouldKeep) {
          hasChange = true;
        }
        return shouldKeep;
      }));
      return hasChange ? nextValue : currentValue;
    });
  }, [pendingNotifications]);
  const aiListings = reactExports.useMemo(() => readAIListings(), [aiListingRefreshIndex]);
  const pendingAIListings = reactExports.useMemo(() => aiListings.filter((listing) => listing.status === "pending"), [aiListings]);
  const handleAdminListingFileUpload = reactExports.useCallback(async (key, nameKey, fileList) => {
    const file = fileList == null ? void 0 : fileList[0];
    if (!file) {
      return;
    }
    try {
      const fileUrl = await readFileAsDataUrl(file);
      setAdminListingDraft((currentValue) => ({
        ...currentValue,
        [key]: fileUrl,
        [nameKey]: file.name
      }));
    } catch (e) {
      setAdminListingStatusMessage("The selected file could not be loaded. Please try another file.");
    }
  }, []);
  const handleCreateAdminListing = reactExports.useCallback(() => {
    if (!walletAddress) {
      setAdminListingStatusMessage("Connect the admin wallet first to publish a 0 fee AI listing.");
      return;
    }
    if (!adminListingDraft.displayName.trim() || !adminListingDraft.websiteUrl.trim() || !adminListingDraft.description.trim()) {
      setAdminListingStatusMessage("Name, website, and description are required before the admin can publish an AI listing.");
      return;
    }
    appendAIListingSubmission({
      id: `admin-ai-${Date.now()}`,
      walletAddress,
      displayName: adminListingDraft.displayName.trim(),
      twitterHandle: adminListingDraft.twitterHandle.trim(),
      iconSrc: adminListingDraft.iconSrc || "./placeholder.svg",
      iconName: adminListingDraft.iconName || "placeholder.svg",
      websiteUrl: adminListingDraft.websiteUrl.trim(),
      description: adminListingDraft.description.trim(),
      socialUrl: adminListingDraft.socialUrl.trim() || adminListingDraft.websiteUrl.trim(),
      guideFileName: adminListingDraft.guideFileName || "Admin guide",
      guideFileUrl: adminListingDraft.guideFileUrl || adminListingDraft.websiteUrl.trim(),
      planId: "free",
      billingLabel: "$0 / admin",
      amountUsd: 0,
      autoRenewEnabled: false,
      status: "approved",
      badge: "none",
      adminNotes: "Published by admin with 0 fee.",
      visibleInExplore: true,
      visitorCount: 0
    });
    setAdminListingDraft({
      displayName: "",
      twitterHandle: "",
      websiteUrl: "",
      description: "",
      socialUrl: "",
      iconSrc: "",
      iconName: "",
      guideFileName: "",
      guideFileUrl: ""
    });
    setShowAdminListingForm(false);
    setAdminListingStatusMessage("The admin AI listing is now published on the platform with 0 fee.");
  }, [adminListingDraft, walletAddress]);
  const handleMarkAsPaid = reactExports.useCallback(async (entryId) => {
    var _a;
    if (!walletAddress) return;
    try {
      setMarkingPaidId(entryId);
      const result = await markClaimAsPaid(entryId, walletAddress);
      if (result.success) {
        toast.success("Paiement confirmé", {
          description: "Le claim a été marqué comme payé."
        });
      } else {
        toast.error("Échec", {
          description: (_a = result.error) != null ? _a : "Impossible de marquer ce claim comme payé."
        });
      }
      await loadClaims();
    } finally {
      setMarkingPaidId(null);
    }
  }, [loadClaims, walletAddress]);
  if (!isAdminWallet) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "admin-center", className: "pb-20", "data-forge-id": "forge-7c0op8-499-4", "data-component": "section", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:499:4:1196:14", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8", "data-forge-id": "forge-7cejqn-500-6", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:500:6:1195:12", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 shadow-[0_20px_60px_rgba(249,115,22,0.12)] dark:border-white/10 dark:bg-white/5 dark:text-white", "data-forge-id": "forge-7cekhe-501-8", "data-component": "Card", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:501:8:1194:15", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-el83wk-502-10", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:502:10:515:23", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-3", "data-forge-id": "forge-el8qw5-503-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:503:12:510:18", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-orange-100 text-orange-700 hover:bg-orange-100 dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-el9dvq-504-14", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:504:14:506:22", children: "Admin control center" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-white text-zinc-700 hover:bg-white dark:border-white/10 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-900", "data-forge-id": "forge-elbaub-507-14", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:507:14:509:22", children: "Central wallet activity feed" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-3xl", "data-forge-id": "forge-elr9ig-511-12", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:511:12:511:121", children: "Centralized wallet tracking, payment review, and player oversight" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { className: "text-base leading-7 text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-elrwhz-512-12", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:512:12:514:30", children: "The admin wallet can now consult every tracked user wallet, payment flow, prediction history, and gains or losses from one shared Octopus Market registry." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-6", "data-forge-id": "forge-elugg1-516-10", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:516:10:1193:24", children: [
      adminWalletSummary ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-orange-200 bg-gradient-to-br from-orange-100 via-white to-orange-50 p-5 dark:border-white/10 dark:bg-gradient-to-br dark:from-orange-500/10 dark:via-zinc-950 dark:to-black", "data-forge-id": "forge-elvqf7-518-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:518:14:570:20", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-4", "data-forge-id": "forge-elwdes-519-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:519:16:542:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-emaf4g-520-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:520:18:530:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-emb24m-521-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:521:20:521:112", children: "Admin wallet activity" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-embp45-522-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:522:20:524:24", children: "The receiver wallet gets its own overview for incoming platform payments, validations, and market settlement actions." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-emdm2q-525-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:525:20:525:114", children: adminWalletSummary.address }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-eme929-526-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:526:20:529:24", children: [
              adminWalletSummary.connectedNow ? "Connected now" : "Not connected",
              adminWalletSummary.lastActivityAt ? ` · Latest admin activity ${formatMoment(adminWalletSummary.lastActivityAt)}` : " · Waiting for first admin action"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-2 text-right text-sm text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-emuupc-531-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:531:18:541:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-emvhpi-532-20", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:532:20:534:27", children: [
              "Total received ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-zinc-950 dark:text-white", "data-forge-id": "forge-emw4q3-533-37", "data-component": "strong", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:533:37:533:150", children: formatCurrency(adminWalletSummary.totalReceivedUsdc) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-emxeo3-535-20", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:535:20:537:27", children: [
              "Approved received ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-emerald-600 dark:text-emerald-300", "data-forge-id": "forge-emy1pc-536-40", "data-component": "strong", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:536:40:536:162", children: formatCurrency(adminWalletSummary.totalApprovedUsdc) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-emzbmo-538-20", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:538:20:540:27", children: [
              "Pending received ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-orange-600 dark:text-orange-300", "data-forge-id": "forge-emzynb-539-39", "data-component": "strong", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:539:39:539:158", children: formatCurrency(adminWalletSummary.totalPendingUsdc) })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 grid gap-2 sm:grid-cols-3 xl:grid-cols-6", "data-forge-id": "forge-engk98-544-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:544:16:569:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-white px-3 py-3 text-xs text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300", "data-forge-id": "forge-enh78t-545-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:545:18:548:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-enhu8z-546-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:546:20:546:117", children: "Incoming payments" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-enih8i-547-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:547:20:547:138", children: adminWalletSummary.receivedPaymentsCount })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-white px-3 py-3 text-xs text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300", "data-forge-id": "forge-enjr6x-549-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:549:18:552:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-enxsx6-550-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:550:20:550:107", children: "Pending" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-enyfwp-551-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:551:20:551:137", children: adminWalletSummary.pendingReceivedCount })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-white px-3 py-3 text-xs text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300", "data-forge-id": "forge-enzpv4-553-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:553:18:556:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-eo0cva-554-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:554:20:554:108", children: "Approved" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-eo0zut-555-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:555:20:555:138", children: adminWalletSummary.approvedReceivedCount })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-white px-3 py-3 text-xs text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300", "data-forge-id": "forge-eo29t8-557-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:557:18:560:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-eo2wte-558-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:558:20:558:108", children: "Rejected" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-eo3jsx-559-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:559:20:559:138", children: adminWalletSummary.rejectedReceivedCount })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-white px-3 py-3 text-xs text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300", "data-forge-id": "forge-eoi8hf-561-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:561:18:564:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-eoivhl-562-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:562:20:562:108", children: "Reviewed" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-eojih4-563-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:563:20:563:138", children: adminWalletSummary.reviewedPaymentsCount })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-white px-3 py-3 text-xs text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300", "data-forge-id": "forge-eoksfj-565-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:565:18:568:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-eolffp-566-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:566:20:566:115", children: "Markets settled" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-eom2f8-567-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:567:20:567:137", children: adminWalletSummary.resolvedMarketsCount })
          ] })
        ] })
      ] }) : null,
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 md:grid-cols-5", "data-forge-id": "forge-ep3b1o-573-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:573:12:634:18", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => setSelectedPanel("wallets"), className: `rounded-2xl border px-4 py-4 text-left transition ${selectedPanel === "wallets" ? "border-orange-300 bg-orange-100/90" : "border-orange-100 bg-orange-50 hover:border-orange-300 dark:border-white/10 dark:bg-black/20 dark:hover:border-white/20"}`, "data-forge-id": "forge-ep3y19-574-14", "data-component": "button", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:574:14:585:23", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-sm font-medium text-zinc-900 dark:text-zinc-100", "data-forge-id": "forge-ep74yy-579-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:579:16:582:22", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "size-4 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-epl6om-580-18", "data-component": "Users", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:580:18:580:83" }),
            "Connected wallets"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-3xl font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-epn3n5-583-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:583:16:583:117", children: walletSummaries.length }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-epnqmo-584-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:584:16:584:176", children: "Every tracked non-admin wallet appears here with activity, payments, history, wins, and losses." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => setSelectedPanel("pending"), className: `rounded-2xl border px-4 py-4 text-left transition ${selectedPanel === "pending" ? "border-orange-300 bg-orange-100/90" : "border-orange-100 bg-orange-50 hover:border-orange-300 dark:border-white/10 dark:bg-black/20 dark:hover:border-white/20"}`, "data-forge-id": "forge-epp0lo-586-14", "data-component": "button", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:586:14:597:23", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-sm font-medium text-zinc-900 dark:text-zinc-100", "data-forge-id": "forge-eq5m9g-591-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:591:16:594:22", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Bell, { className: "size-4 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-eq6991-592-18", "data-component": "Bell", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:592:18:592:82" }),
            "Pending approvals"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-3xl font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-eq867k-595-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:595:16:595:122", children: pendingNotifications.length }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-eq8t73-596-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:596:16:596:149", children: "Review waiting payments with the full user snapshot behind each one." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => setSelectedPanel("approved"), className: `rounded-2xl border px-4 py-4 text-left transition ${selectedPanel === "approved" ? "border-emerald-300 bg-emerald-50/90" : "border-orange-100 bg-orange-50 hover:border-emerald-300 dark:border-white/10 dark:bg-black/20 dark:hover:border-emerald-500/30"}`, "data-forge-id": "forge-eqa363-598-14", "data-component": "button", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:598:14:609:23", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-sm font-medium text-zinc-900 dark:text-zinc-100", "data-forge-id": "forge-f2adag-603-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:603:16:606:22", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "size-4 text-emerald-500 dark:text-emerald-300", "data-forge-id": "forge-f2b0a1-604-18", "data-component": "CheckCircle2", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:604:18:604:92" }),
            "Approved payments"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-3xl font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-f2cx8k-607-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:607:16:607:123", children: approvedNotifications.length }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-f2dk83-608-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:608:16:608:157", children: "Review approved receipts with user totals, history, and validation timeline." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => setSelectedPanel("participants"), className: `rounded-2xl border px-4 py-4 text-left transition ${selectedPanel === "participants" ? "border-orange-300 bg-orange-100/90" : "border-orange-100 bg-orange-50 hover:border-orange-300 dark:border-white/10 dark:bg-black/20 dark:hover:border-white/20"}`, "data-forge-id": "forge-f2s8x6-610-14", "data-component": "button", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:610:14:621:23", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-sm font-medium text-zinc-900 dark:text-zinc-100", "data-forge-id": "forge-f2vfuv-615-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:615:16:618:22", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "size-4 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-f2w2ug-616-18", "data-component": "ShieldCheck", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:616:18:616:89" }),
            "Prediction participants"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-3xl font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-f2xzsz-619-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:619:16:619:125", children: uniquePredictionWallets.length }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-f3c1il-620-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:620:16:620:151", children: "Open to inspect players by section with wallet-level totals and dates." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => setSelectedPanel("claims"), className: `rounded-2xl border px-4 py-4 text-left transition ${selectedPanel === "claims" ? "border-emerald-300 bg-emerald-50/90" : "border-orange-100 bg-orange-50 hover:border-emerald-300 dark:border-white/10 dark:bg-black/20 dark:hover:border-emerald-500/30"}`, "data-forge-id": "forge-f3dbhl-622-14", "data-component": "button", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:622:14:633:23", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-sm font-medium text-zinc-900 dark:text-zinc-100", "data-forge-id": "forge-f3gifa-627-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:627:16:630:22", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Coins, { className: "size-4 text-emerald-500 dark:text-emerald-300", "data-forge-id": "forge-f3h5ev-628-18", "data-component": "Coins", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:628:18:628:85" }),
            "Claims"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-3xl font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-f3wh3h-631-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:631:16:631:115", children: claimsHistory.length }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-f3x430-632-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:632:16:632:151", children: "Rewards claimed by users. Mark as paid once the USDC transfer is sent." })
        ] })
      ] }),
      selectedPanel === "wallets" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-orange-200 bg-orange-50/70 p-5 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-f40b0l-637-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:637:14:731:20", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-f40y06-638-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:638:16:638:112", children: "Connected wallets details" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-f41kzp-639-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:639:16:641:20", children: "Every non-admin wallet connected to Octopus Market appears here with first connection, latest activity, payment counts, history, wins, and losses." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-5 space-y-3", "data-forge-id": "forge-f4gwod-642-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:642:16:730:22", children: walletSummaries.length > 0 ? walletSummaries.map((wallet) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-white px-4 py-4 dark:border-white/10 dark:bg-zinc-950/80", "data-forge-id": "forge-f4itnp-645-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:645:22:723:28", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-3", "data-forge-id": "forge-f4jgna-646-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:646:24:665:30", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-f4k3mv-647-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:647:26:659:32", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-f4kqmg-648-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:648:28:651:32", children: [
                wallet.walletRecord.displayName || wallet.walletRecord.username ? `${wallet.walletRecord.displayName || wallet.walletRecord.username} · ` : "",
                wallet.address
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-f50pan-652-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:652:28:654:32", children: [
                "First seen ",
                formatMoment(wallet.walletRecord.firstConnectedAt),
                " · Last seen ",
                formatMoment(wallet.walletRecord.lastConnectedAt),
                " · Latest activity ",
                formatMoment(wallet.walletRecord.latestActivityAt)
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-f52m98-655-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:655:28:655:134", children: wallet.walletRecord.latestActivityLabel }),
              wallet.walletRecord.twitterHandle ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-f53w8x-657-30", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:657:30:657:130", children: wallet.walletRecord.twitterHandle }) : null
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-2 text-right text-sm text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-f5j7ww-660-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:660:26:664:32", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-f5juwh-661-28", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:661:28:661:143", children: [
                "Stake: ",
                /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-zinc-950 dark:text-white", "data-forge-id": "forge-f5juy0-661-41", "data-component": "strong", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:661:41:661:136", children: formatCurrency(wallet.totalStaked) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-f5khw0-662-28", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:662:28:662:147", children: [
                "Won: ",
                /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-emerald-600 dark:text-emerald-300", "data-forge-id": "forge-f5khww-662-39", "data-component": "strong", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:662:39:662:140", children: formatCurrency(wallet.totalWon) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-f5l4vj-663-28", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:663:28:663:141", children: [
                "Lost: ",
                /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-red-600 dark:text-red-300", "data-forge-id": "forge-f5l4x1-663-40", "data-component": "strong", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:663:40:663:134", children: formatCurrency(wallet.totalLost) })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 grid gap-2 sm:grid-cols-5", "data-forge-id": "forge-f5n1u0-666-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:666:24:687:30", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-3 py-3 text-xs text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300", "data-forge-id": "forge-f5notl-667-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:667:26:670:32", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-f5obt6-668-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:668:28:668:119", children: "Connections" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-f5oysp-669-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:669:28:669:141", children: wallet.walletRecord.connectionCount })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-3 py-3 text-xs text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300", "data-forge-id": "forge-f63nhs-671-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:671:26:674:32", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-f64ahd-672-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:672:28:672:126", children: "Prediction entries" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-f64xgw-673-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:673:28:673:128", children: wallet.predictionCount })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-3 py-3 text-xs text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300", "data-forge-id": "forge-f667fw-675-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:675:26:678:32", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-f66ufh-676-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:676:28:676:115", children: "Pending" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-f67hf0-677-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:677:28:677:125", children: wallet.pendingCount })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-3 py-3 text-xs text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300", "data-forge-id": "forge-f68re0-679-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:679:26:682:32", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-f6mt3o-680-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:680:28:680:116", children: "Approved" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-f6ng37-681-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:681:28:681:126", children: wallet.approvedCount })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-3 py-3 text-xs text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300", "data-forge-id": "forge-f6oq27-683-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:683:26:686:32", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-f6pd1s-684-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:684:28:684:116", children: "Rejected" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-f6q01b-685-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:685:28:685:126", children: wallet.rejectedCount })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "my-3 bg-orange-100 dark:bg-white/10", "data-forge-id": "forge-f6rwzs-688-24", "data-component": "Separator", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:688:24:688:85" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 text-sm text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-f6sjzb-689-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:689:24:722:30", children: wallet.entries.length > 0 ? wallet.entries.map((entry) => {
            const payment = wallet.payments.find((item) => item.paymentReference === entry.paymentReference);
            const resolution = resolutions[entry.marketId];
            const resultLabel = (payment == null ? void 0 : payment.status) === "rejected" ? "Rejected" : resolution ? resolution.outcomeId === entry.selectionId ? "Win" : "Lose" : "Pending";
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-orange-100 bg-orange-50 px-3 py-3 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-fjbzq9-703-32", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:703:32:714:38", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-fjcmpu-704-34", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:704:34:709:40", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-fjd9pf-705-36", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:705:36:705:116", children: entry.marketTitle }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-fjdwoy-706-36", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:706:36:708:40", children: [
                  entry.selectionLabel,
                  " · ",
                  formatMoment(entry.createdAt),
                  " · Ref ",
                  entry.paymentReference
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-1 text-right text-xs text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-fjtvd3-710-34", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:710:34:713:40", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "data-forge-id": "forge-fjuico-711-36", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:711:36:711:79", children: formatCurrency(entry.amount) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "data-forge-id": "forge-fjv5c7-712-36", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:712:36:712:62", children: resultLabel })
              ] })
            ] }, entry.id);
          }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-dashed border-orange-200 bg-white px-4 py-4 text-sm text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-400", "data-forge-id": "forge-fjyz8k-718-28", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:718:28:720:34", children: "No prediction history for this wallet yet." }) })
        ] }, wallet.address)) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-dashed border-orange-200 bg-white px-4 py-5 text-sm text-zinc-600 dark:border-white/10 dark:bg-zinc-950/80 dark:text-zinc-400", "data-forge-id": "forge-fkhhun-726-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:726:20:728:26", children: "No connected wallets have been tracked yet." }) })
      ] }) : null,
      selectedPanel === "pending" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-orange-200 bg-orange-50/70 p-5 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-fl0nfq-735-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:735:14:834:20", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-fl1afb-736-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:736:16:736:104", children: "Pending approvals" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-fl1xeu-737-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:737:16:739:20", children: "Review every payment waiting for admin validation, then approve or reject it with the user activity snapshot visible below." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-5 space-y-3", "data-forge-id": "forge-flh93i-740-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:740:16:833:22", children: pendingNotifications.length > 0 ? pendingNotifications.map((notification) => {
          var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-white px-4 py-4 dark:border-white/10 dark:bg-zinc-950/80", "data-forge-id": "forge-flj62u-743-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:743:22:826:28", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-3", "data-forge-id": "forge-fljt2f-744-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:744:24:750:30", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-flkg20-745-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:745:26:748:32", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-fll31l-746-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:746:28:746:111", children: notification.title }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-fllq14-747-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:747:28:747:176", children: notification.subtitle || notification.categoryLabel || "Waiting for admin review" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-fln004-749-26", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:749:26:749:146", children: [
                formatCurrency(notification.totalPaidUsdc),
                " USDC"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Separator, { className: "my-3 bg-orange-100 dark:bg-white/10", "data-forge-id": "forge-fm1op7-751-24", "data-component": "Separator", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:751:24:751:85" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 text-sm text-zinc-700 xl:grid-cols-[minmax(0,2.2fr)_minmax(120px,0.9fr)_minmax(120px,0.9fr)_minmax(140px,0.8fr)] dark:text-zinc-300", "data-forge-id": "forge-fm2boq-752-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:752:24:772:30", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", "data-forge-id": "forge-fm2yob-753-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:753:26:759:32", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-fm3lnw-754-28", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:754:28:754:128", children: "Wallet" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 truncate font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-fm48nf-755-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:755:28:757:32", children: formatNotificationWalletLabel(notification, walletSummaryByAddress) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 break-all font-mono text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-fm65m0-758-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:758:28:758:138", children: notification.userWallet })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", "data-forge-id": "forge-fmkub3-760-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:760:26:763:32", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-fmlhao-761-28", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:761:28:761:129", children: "Section" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 break-words font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-fmm4a7-762-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:762:28:762:153", children: notification.categoryLabel || "Platform flow" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", "data-forge-id": "forge-fmne97-764-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:764:26:767:32", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-fmo18s-765-28", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:765:28:765:128", children: "Choice" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 break-words font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-fmoo8b-766-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:766:28:766:153", children: notification.selectionLabel || "Payment only" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", "data-forge-id": "forge-fmpy7b-768-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:768:26:771:32", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-fmql6w-769-28", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:769:28:769:133", children: "Received at" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-fn4mwi-770-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:770:28:770:132", children: formatMoment(notification.createdAt) })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 rounded-2xl border border-orange-100 bg-orange-50 px-4 py-3 text-xs text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300", "data-forge-id": "forge-fn6juz-773-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:773:24:782:30", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-fn76uk-774-26", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:774:26:774:109", children: "User activity snapshot" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 flex flex-wrap gap-x-4 gap-y-2", "data-forge-id": "forge-fn7tu3-775-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:775:26:781:32", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-fn8gto-776-28", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:776:28:776:136", children: [
                  "Total stake ",
                  formatCurrency((_b = (_a = walletSummaryByAddress[notification.userWallet]) == null ? void 0 : _a.totalStaked) != null ? _b : 0)
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-fn93t7-777-28", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:777:28:777:117", children: [
                  "Pending ",
                  (_d = (_c = walletSummaryByAddress[notification.userWallet]) == null ? void 0 : _c.pendingCount) != null ? _d : 0
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-fn9qsq-778-28", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:778:28:778:119", children: [
                  "Approved ",
                  (_f = (_e = walletSummaryByAddress[notification.userWallet]) == null ? void 0 : _e.approvedCount) != null ? _f : 0
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-fnads9-779-28", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:779:28:779:125", children: [
                  "Won ",
                  formatCurrency((_h = (_g = walletSummaryByAddress[notification.userWallet]) == null ? void 0 : _g.totalWon) != null ? _h : 0)
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-fnofhv-780-28", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:780:28:780:127", children: [
                  "Lost ",
                  formatCurrency((_j = (_i = walletSummaryByAddress[notification.userWallet]) == null ? void 0 : _i.totalLost) != null ? _j : 0)
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 flex flex-wrap items-center gap-3", "data-forge-id": "forge-fnqcgc-783-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:783:24:825:30", children: (() => {
              const reviewAction = reviewActionByReference[notification.paymentReference];
              const approveIsActive = reviewAction === "approved";
              const rejectIsActive = reviewAction === "rejected";
              return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", className: `rounded-2xl text-white transition-colors ${approveIsActive ? "bg-emerald-700 ring-2 ring-emerald-200 hover:bg-emerald-700 dark:ring-emerald-500/30" : "bg-emerald-600 hover:bg-emerald-500"}`, onClick: () => {
                  setReviewActionByReference((currentValue) => ({
                    ...currentValue,
                    [notification.paymentReference]: "approved"
                  }));
                  updateAdminPaymentNotificationStatus(notification.paymentReference, "approved", walletAddress != null ? walletAddress : predictionMarketTreasuryAddress);
                  toast.success("Paiement approuvé", {
                    description: `Référence ${notification.paymentReference.slice(0, 8)}… validée.`
                  });
                }, "data-forge-id": "forge-fo8v2p-791-26", "data-component": "Button", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:791:26:805:35", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "size-4", "data-forge-id": "forge-g0dm3r-803-28", "data-component": "CheckCircle2", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:803:28:803:63" }),
                  approveIsActive ? "Approved" : "Approve"
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", variant: "outline", className: `rounded-2xl transition-colors ${rejectIsActive ? "border-red-300 bg-red-100 text-red-700 hover:bg-red-100 dark:border-red-500/40 dark:bg-red-500/20 dark:text-red-200 dark:hover:bg-red-500/20" : "border-red-200 bg-white text-red-600 hover:bg-red-50 dark:border-red-500/30 dark:bg-zinc-950 dark:text-red-300 dark:hover:bg-red-500/10"}`, onClick: () => {
                  setReviewActionByReference((currentValue) => ({
                    ...currentValue,
                    [notification.paymentReference]: "rejected"
                  }));
                  updateAdminPaymentNotificationStatus(notification.paymentReference, "rejected", walletAddress != null ? walletAddress : predictionMarketTreasuryAddress);
                  toast.error("Paiement rejeté", {
                    description: `Référence ${notification.paymentReference.slice(0, 8)}… rejetée.`
                  });
                }, "data-forge-id": "forge-g0fj2a-806-26", "data-component": "Button", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:806:26:821:35", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "size-4", "data-forge-id": "forge-g118ma-819-28", "data-component": "XCircle", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:819:28:819:58" }),
                  rejectIsActive ? "Rejected" : "Reject"
                ] })
              ] });
            })() })
          ] }, notification.id);
        }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-dashed border-orange-200 bg-white px-4 py-5 text-sm text-zinc-600 dark:border-white/10 dark:bg-zinc-950/80 dark:text-zinc-400", "data-forge-id": "forge-g1l17f-829-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:829:20:831:26", children: "No pending approvals right now." }) })
      ] }) : null,
      selectedPanel === "approved" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-emerald-200 bg-emerald-50/70 p-5 dark:border-emerald-500/20 dark:bg-emerald-500/10", "data-forge-id": "forge-g246si-838-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:838:14:873:20", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-g24ts3-839-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:839:16:839:112", children: "Approved payments history" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-g2ivhp-840-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:840:16:842:20", children: "Review every payment already confirmed as received by the admin wallet, together with the related user wallet metrics and history." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-5 space-y-3", "data-forge-id": "forge-g2ksga-843-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:843:16:872:22", children: approvedNotifications.length > 0 ? approvedNotifications.map((notification) => {
          var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-emerald-200 bg-white px-4 py-4 dark:border-emerald-500/20 dark:bg-zinc-950/80", "data-forge-id": "forge-g2mpfm-846-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:846:22:865:28", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-3", "data-forge-id": "forge-g2ncf7-847-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:847:24:853:30", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-g2nzes-848-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:848:26:851:32", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-g2omed-849-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:849:28:849:111", children: notification.title }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-g32o3z-850-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:850:28:850:139", children: notification.subtitle || "Approved by admin" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-g33y2z-852-26", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:852:26:852:146", children: [
                formatCurrency(notification.totalPaidUsdc),
                " USDC"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-g3581z-854-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:854:24:864:30", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-g35v1k-855-26", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:855:26:859:33", children: [
                "User ",
                ((_a = walletSummaryByAddress[notification.userWallet]) == null ? void 0 : _a.walletRecord.displayName) || ((_b = walletSummaryByAddress[notification.userWallet]) == null ? void 0 : _b.walletRecord.username) || notification.username ? `${((_c = walletSummaryByAddress[notification.userWallet]) == null ? void 0 : _c.walletRecord.displayName) || ((_d = walletSummaryByAddress[notification.userWallet]) == null ? void 0 : _d.walletRecord.username) || notification.username} · ${formatWalletAddress(notification.userWallet)}` : formatWalletAddress(notification.userWallet)
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-g3mgpa-860-26", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:860:26:860:152", children: [
                "Approved ",
                notification.reviewedAt ? formatMoment(notification.reviewedAt) : formatMoment(notification.createdAt)
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-g3n3ot-861-26", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:861:26:861:134", children: [
                "Total stake ",
                formatCurrency((_f = (_e = walletSummaryByAddress[notification.userWallet]) == null ? void 0 : _e.totalStaked) != null ? _f : 0)
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-g3nqoc-862-26", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:862:26:862:124", children: [
                "Wins ",
                formatCurrency((_h = (_g = walletSummaryByAddress[notification.userWallet]) == null ? void 0 : _g.totalWon) != null ? _h : 0)
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-g3odnv-863-26", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:863:26:863:127", children: [
                "Losses ",
                formatCurrency((_j = (_i = walletSummaryByAddress[notification.userWallet]) == null ? void 0 : _i.totalLost) != null ? _j : 0)
              ] })
            ] })
          ] }, notification.id);
        }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-dashed border-emerald-200 bg-white px-4 py-5 text-sm text-zinc-600 dark:border-emerald-500/20 dark:bg-zinc-950/80 dark:text-zinc-400", "data-forge-id": "forge-g3rklc-868-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:868:20:870:26", children: "No approved payment history yet." }) })
      ] }) : null,
      selectedPanel === "participants" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-orange-200 bg-orange-50/70 p-5 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-g4aq6f-877-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:877:14:921:20", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-g4bd60-878-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:878:16:878:121", children: "Prediction participants by section" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-g4c05j-879-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:879:16:881:20", children: "Follow the total number of participants and inspect which user wallet joined each section with their payment and activity details." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-5 space-y-4", "data-forge-id": "forge-g4rbu7-882-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:882:16:920:22", children: Object.entries(participantGroups).length > 0 ? Object.entries(participantGroups).map(([categoryLabel, participants]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-white px-4 py-4 dark:border-white/10 dark:bg-zinc-950/80", "data-forge-id": "forge-g4t8tj-885-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:885:22:913:28", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3", "data-forge-id": "forge-g4tvt4-886-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:886:24:891:30", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-g4uisp-887-26", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:887:26:887:104", children: categoryLabel }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { className: "border border-orange-200 bg-orange-100 text-orange-700 hover:bg-orange-100 dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-g4v5s8-888-26", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:888:26:890:34", children: [
              participants.length,
              " participant",
              participants.length > 1 ? "s" : ""
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 space-y-2 text-sm text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-g5b4gd-892-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:892:24:912:30", children: participants.map((participant) => {
            var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-orange-100 bg-orange-50 px-3 py-3 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-g5cefj-894-28", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:894:28:910:34", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-g5d1fp-895-30", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:895:30:902:36", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-g5dofa-896-32", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:896:32:900:36", children: ((_a = walletSummaryByAddress[participant.userWallet]) == null ? void 0 : _a.walletRecord.displayName) || ((_b = walletSummaryByAddress[participant.userWallet]) == null ? void 0 : _b.walletRecord.username) || participant.username ? `${((_c = walletSummaryByAddress[participant.userWallet]) == null ? void 0 : _c.walletRecord.displayName) || ((_d = walletSummaryByAddress[participant.userWallet]) == null ? void 0 : _d.walletRecord.username) || participant.username} · ${participant.userWallet}` : participant.userWallet }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-ghdyjl-901-32", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:901:32:901:145", children: participant.selectionLabel || "Pending choice" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-right text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-ghf8il-903-30", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:903:30:906:36", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { "data-forge-id": "forge-ghfvi6-904-32", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:904:32:904:82", children: formatCurrency(participant.totalPaidUsdc) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { "data-forge-id": "forge-ghgihp-905-32", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:905:32:905:76", children: formatMoment(participant.createdAt) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-ghhsgp-907-30", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:907:30:909:36", children: [
                "Wallet totals · stake ",
                formatCurrency((_f = (_e = walletSummaryByAddress[participant.userWallet]) == null ? void 0 : _e.totalStaked) != null ? _f : 0),
                " · approved ",
                (_h = (_g = walletSummaryByAddress[participant.userWallet]) == null ? void 0 : _g.approvedCount) != null ? _h : 0,
                " · pending ",
                (_j = (_i = walletSummaryByAddress[participant.userWallet]) == null ? void 0 : _i.pendingCount) != null ? _j : 0
              ] })
            ] }, participant.id);
          }) })
        ] }, categoryLabel)) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-dashed border-orange-200 bg-white px-4 py-5 text-sm text-zinc-600 dark:border-white/10 dark:bg-zinc-950/80 dark:text-zinc-400", "data-forge-id": "forge-gi0y1o-916-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:916:20:918:26", children: "No prediction participants yet." }) })
      ] }) : null,
      selectedPanel === "claims" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-emerald-200 bg-emerald-50/70 p-5 dark:border-emerald-500/20 dark:bg-black/20", "data-forge-id": "forge-gik3mr-925-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:925:14:988:20", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-gikqmc-926-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:926:16:926:114", children: "Claims — rewards to pay out" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-gildlv-927-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:927:16:929:20", children: "Users who won a bet and clicked Claim appear here. Mark each one as Paid once you have sent the USDC to their wallet." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-5 space-y-3", "data-forge-id": "forge-gj0paj-930-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:930:16:987:22", children: claimsHistory.length > 0 ? claimsHistory.map((entry) => {
          const isPaid = entry.payoutStatus === "paid";
          const isMarkingThis = markingPaidId === entry.id;
          return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `rounded-2xl border px-4 py-4 ${isPaid ? "border-emerald-200 bg-white dark:border-emerald-500/20 dark:bg-zinc-950/80" : "border-orange-100 bg-white dark:border-white/10 dark:bg-zinc-950/80"}`, "data-forge-id": "forge-gj4j8i-936-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:936:24:979:30", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-3", "data-forge-id": "forge-gjkhwr-940-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:940:26:978:32", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1 text-sm", "data-forge-id": "forge-gjl4wc-941-28", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:941:28:960:34", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-gjlrwi-942-30", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:942:30:942:112", children: entry.marketTitle }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-gjmew1-943-30", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:943:30:943:124", children: formatWalletAddress(entry.walletAddress) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-gjn1vk-944-30", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:944:30:946:34", children: [
                "Selection: ",
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-gjnow1-945-43", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:945:43:945:135", children: entry.selectionLabel })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-gjoyu5-947-30", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:947:30:949:34", children: [
                "Net reward: ",
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-semibold text-emerald-600 dark:text-emerald-400", "data-forge-id": "forge-gjplun-948-44", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:948:44:948:155", children: formatCurrency(entry.netReward) })
              ] }),
              entry.claimedAt ? /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-zinc-400 dark:text-zinc-500", "data-forge-id": "forge-gk4xie-951-32", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:951:32:953:36", children: [
                "Claimed: ",
                formatMoment(entry.claimedAt)
              ] }) : null,
              isPaid && entry.paidAt ? /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-emerald-600 dark:text-emerald-400", "data-forge-id": "forge-gk84g1-956-32", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:956:32:958:36", children: [
                "Paid: ",
                formatMoment(entry.paidAt)
              ] }) : null
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-col items-end gap-2", "data-forge-id": "forge-gkoq32-961-28", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:961:28:977:34", children: isPaid ? /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-emerald-200 bg-emerald-100 text-emerald-700 dark:border-emerald-500/20 dark:bg-emerald-500/15 dark:text-emerald-300", "data-forge-id": "forge-gkq02t-963-32", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:963:32:965:40", children: "Paid" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", size: "sm", disabled: isMarkingThis, className: "rounded-xl bg-emerald-500 text-white hover:bg-emerald-400 disabled:opacity-60", onClick: () => void handleMarkAsPaid(entry.id), "data-forge-id": "forge-gksk0x-967-32", "data-component": "Button", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:967:32:975:41", children: isMarkingThis ? "Saving…" : "Mark as paid" }) })
          ] }) }, entry.id);
        }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-dashed border-emerald-200 bg-white px-4 py-5 text-sm text-zinc-600 dark:border-emerald-500/20 dark:bg-zinc-950/80 dark:text-zinc-400", "data-forge-id": "forge-gltl8m-983-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:983:20:985:26", children: "No claims yet. When a user wins a bet and clicks Claim, it appears here." }) })
      ] }) : null,
      rejectedNotifications.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-gmcqtp-992-14", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:992:14:994:18", children: "Rejected payments stay visible so both the admin and the player see the final decision clearly." }) : null,
      /* @__PURE__ */ jsxRuntimeExports.jsx(AdminPaymentsManualConfirm, { walletAddress, initialPending: pendingNotifications, "data-forge-id": "forge-gmfxra-997-12", "data-component": "AdminPaymentsManualConfirm", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:997:12:997:110" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-orange-200 bg-orange-50/70 p-5 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-gmh7qc-999-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:999:12:1192:18", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-wnjw10-1000-14", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1000:14:1000:106", children: "AI listing moderation" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-wnj91h-1001-14", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1001:14:1003:18", children: "Review every submitted AI listing, validate the product, approve or reject the listing, and control the blue badge directly from the admin side." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 rounded-3xl border border-orange-100 bg-white p-4 dark:border-white/10 dark:bg-zinc-950/80", "data-forge-id": "forge-wnhc2w-1004-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1004:14:1114:20", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3", "data-forge-id": "forge-wngp3b-1005-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1005:16:1020:22", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-wng23q-1006-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1006:18:1011:24", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-wnff3k-1007-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1007:20:1007:102", children: "Admin free AI listing" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-wnes41-1008-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1008:20:1010:24", children: "Publish an AI directly from the admin panel with 0 fee. The listing becomes visible immediately on the platform." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", className: "rounded-2xl border-orange-200 bg-white text-zinc-950 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-900 dark:text-white dark:hover:bg-zinc-800", onClick: () => setShowAdminListingForm((currentValue) => !currentValue), "data-forge-id": "forge-wmytgh-1012-18", "data-component": "Button", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1012:18:1019:27", children: showAdminListingForm ? "Close" : "Add free AI" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-wmfnup-1021-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1021:16:1021:108", children: adminListingStatusMessage }),
          showAdminListingForm ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 grid gap-4 lg:grid-cols-2", "data-forge-id": "forge-wmedvl-1023-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1023:18:1112:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", "data-forge-id": "forge-wmdqvf-1024-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1024:20:1057:26", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: adminListingDraft.displayName, onChange: (event) => setAdminListingDraft((currentValue) => ({
                ...currentValue,
                displayName: event.target.value
              })), placeholder: "AI name", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-wmd3vu-1025-22", "data-component": "Input", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1025:22:1032:24" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: adminListingDraft.twitterHandle, onChange: (event) => setAdminListingDraft((currentValue) => ({
                ...currentValue,
                twitterHandle: event.target.value
              })), placeholder: "X / Twitter handle", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-wlul9j-1033-22", "data-component": "Input", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1033:22:1040:24" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: adminListingDraft.websiteUrl, onChange: (event) => setAdminListingDraft((currentValue) => ({
                ...currentValue,
                websiteUrl: event.target.value
              })), placeholder: "Website URL", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-wlc2n8-1041-22", "data-component": "Input", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1041:22:1048:24" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: adminListingDraft.socialUrl, onChange: (event) => setAdminListingDraft((currentValue) => ({
                ...currentValue,
                socialUrl: event.target.value
              })), placeholder: "Social URL", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-wl6yr0-1049-22", "data-component": "Input", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1049:22:1056:24" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", "data-forge-id": "forge-wknt58-1058-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1058:20:1091:26", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: adminListingDraft.description, onChange: (event) => setAdminListingDraft((currentValue) => ({
                ...currentValue,
                description: event.target.value
              })), placeholder: "AI description", className: "min-h-28 border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-wkn65n-1059-22", "data-component": "Textarea", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1059:22:1066:24" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block rounded-2xl border border-dashed border-orange-200 bg-orange-50/70 px-4 py-3 text-sm text-zinc-700 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300", "data-forge-id": "forge-wk4njc-1067-22", "data-component": "label", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1067:22:1078:30", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium", "data-forge-id": "forge-wk40jr-1068-24", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1068:24:1068:68", children: "AI icon" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", accept: "image/*", className: "mt-2 block w-full text-xs", onChange: (event) => {
                  void handleAdminListingFileUpload("iconSrc", "iconName", event.target.files);
                }, "data-forge-id": "forge-wk3dk8-1069-24", "data-component": "input", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1069:24:1076:26" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mt-2 block text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-wjkuxx-1077-24", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1077:24:1077:156", children: adminListingDraft.iconName || "Optional image upload" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block rounded-2xl border border-dashed border-orange-200 bg-orange-50/70 px-4 py-3 text-sm text-zinc-700 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300", "data-forge-id": "forge-wjjkyx-1079-22", "data-component": "label", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1079:22:1090:30", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium", "data-forge-id": "forge-wj5j99-1080-24", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1080:24:1080:70", children: "Guide PDF" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", accept: "application/pdf", className: "mt-2 block w-full text-xs", onChange: (event) => {
                  void handleAdminListingFileUpload("guideFileUrl", "guideFileName", event.target.files);
                }, "data-forge-id": "forge-wj4w9q-1081-24", "data-component": "input", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1081:24:1088:26" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mt-2 block text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-wizsdi-1089-24", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1089:24:1089:159", children: adminListingDraft.guideFileName || "Optional PDF upload" })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-2 flex flex-wrap items-center gap-3", "data-forge-id": "forge-wikgoy-1092-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1092:20:1111:26", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", className: "rounded-2xl bg-emerald-600 text-white hover:bg-emerald-500", onClick: handleCreateAdminListing, "data-forge-id": "forge-wijtpd-1093-22", "data-component": "Button", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1093:22:1099:31", children: "Publish free AI" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", className: "rounded-2xl border-orange-200 bg-white text-zinc-950 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-900 dark:text-white dark:hover:bg-zinc-800", onClick: () => {
                setShowAdminListingForm(false);
                setAdminListingStatusMessage("Admin can publish an AI listing with 0 fee and make it visible immediately on the platform.");
              }, "data-forge-id": "forge-w6i9m0-1100-22", "data-component": "Button", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1100:22:1110:31", children: "Cancel" })
            ] })
          ] }) : null
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-5 space-y-3", "data-forge-id": "forge-w5va3t-1115-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1115:14:1191:20", children: pendingAIListings.length > 0 ? pendingAIListings.map((listing) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-white px-4 py-4 dark:border-white/10 dark:bg-zinc-950/80", "data-forge-id": "forge-w5td4h-1118-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1118:20:1184:26", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-3", "data-forge-id": "forge-w5deg8-1122-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1122:22:1133:28", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", "data-forge-id": "forge-w5crgn-1123-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1123:24:1129:30", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: listing.iconSrc, alt: listing.displayName, className: "size-12 rounded-2xl object-cover", "data-forge-id": "forge-w5c4h2-1124-26", "data-component": "img", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1124:26:1124:126" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-w5bhhj-1125-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1125:26:1128:32", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-w5auhy-1126-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1126:28:1126:112", children: listing.displayName }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-w5a7if-1127-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1127:28:1127:139", children: [
                  listing.twitterHandle,
                  " · ",
                  listing.websiteUrl
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-orange-100 text-orange-700 hover:bg-orange-100 dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-w4uvtv-1130-24", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1130:24:1132:32", children: listing.planId === "starter" ? "Starter" : "Builder" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-sm leading-7 text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-w4sbvt-1134-22", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1134:22:1134:118", children: listing.description }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex flex-wrap items-center gap-3 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-w4rowa-1135-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1135:22:1139:28", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-w4r1wp-1136-24", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1136:24:1136:82", children: [
              "Submitted ",
              formatMoment(listing.submittedAt)
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-w4qex6-1137-24", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1137:24:1137:88", children: [
              "Wallet ",
              formatWalletAddress(listing.walletAddress)
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-w4prxn-1138-24", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1138:24:1138:99", children: [
              "Auto renew ",
              listing.autoRenewEnabled ? "enabled" : "disabled"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 flex flex-wrap items-center gap-3", "data-forge-id": "forge-w4b38k-1140-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1140:22:1183:28", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", className: "rounded-2xl bg-emerald-600 text-white hover:bg-emerald-500", onClick: () => updateAIListingSubmission(listing.id, (currentListing) => ({
              ...currentListing,
              status: "approved",
              badge: currentListing.badge,
              updatedAt: Date.now()
            })), "data-forge-id": "forge-w4ag8z-1141-24", "data-component": "Button", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1141:24:1154:33", children: "Approve listing" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", className: "rounded-2xl border-red-200 bg-white text-red-600 hover:bg-red-50 dark:border-red-500/30 dark:bg-zinc-950 dark:text-red-300 dark:hover:bg-red-500/10", onClick: () => updateAIListingSubmission(listing.id, (currentListing) => ({
              ...currentListing,
              status: "rejected",
              updatedAt: Date.now()
            })), "data-forge-id": "forge-w3o3pi-1155-24", "data-component": "Button", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1155:24:1168:33", children: "Reject listing" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", className: "rounded-2xl border-orange-200 bg-white text-zinc-900 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900", onClick: () => updateAIListingSubmission(listing.id, (currentListing) => ({
              ...currentListing,
              badge: currentListing.badge === "blue" ? "none" : "blue",
              updatedAt: Date.now()
            })), "data-forge-id": "forge-w31r61-1169-24", "data-component": "Button", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1169:24:1182:33", children: "Toggle blue badge" })
          ] })
        ] }, listing.id)) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-dashed border-orange-200 bg-white px-4 py-5 text-sm text-zinc-600 dark:border-white/10 dark:bg-zinc-950/80 dark:text-zinc-400", "data-forge-id": "forge-w1zfz4-1187-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-control-center.tsx:1187:18:1189:24", children: "No AI listing is waiting for admin review." }) })
      ] })
    ] })
  ] }) }) });
}
export {
  AdminControlCenter
};
