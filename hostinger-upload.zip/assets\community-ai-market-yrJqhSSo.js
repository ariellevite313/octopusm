import { r as reactExports, t as subscribeToAIListings, v as readAIListings, j as jsxRuntimeExports, B as Badge, C as Card, a as CardHeader, b as CardTitle, z as CardDescription, e as CardContent, d as Button, Y as ExternalLink, Z as trackAIListingVisit, _ as Globe } from "./index-C-7_nSR2.js";
import { AIToolSocialPanel } from "./ai-tool-social-panel-Br8hLZNe.js";
import { S as Sparkles } from "./sparkles-CaH_qrgu.js";
function CommunityAIMarket({
  actorKey,
  actorLabel
}) {
  const [refreshIndex, setRefreshIndex] = reactExports.useState(0);
  reactExports.useEffect(() => {
    return subscribeToAIListings(() => {
      setRefreshIndex((currentValue) => currentValue + 1);
    });
  }, []);
  const visibleListings = reactExports.useMemo(() => {
    return readAIListings().filter((listing) => listing.visibleInExplore && listing.status !== "rejected");
  }, [refreshIndex]);
  if (visibleListings.length === 0) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-10 space-y-5", "data-forge-id": "forge-mzabtx-38-4", "data-component": "div", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:38:4:130:10", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-3xl border border-orange-200 bg-white p-5 dark:border-white/10 dark:bg-zinc-950/70", "data-forge-id": "forge-mzab36-39-6", "data-component": "div", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:39:6:51:12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-3", "data-forge-id": "forge-mz9uru-40-8", "data-component": "div", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:40:8:47:14", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-orange-100 text-orange-700 hover:bg-orange-100 dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-22cbcw-41-10", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:41:10:43:18", children: "Community AI submissions" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-white text-zinc-700 hover:bg-white dark:border-white/10 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-900", "data-forge-id": "forge-22aeeb-44-10", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:44:10:46:18", children: "Visible immediately in Explore AI" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 max-w-3xl text-sm leading-7 text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-mz9oua-48-8", "data-component": "p", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:48:8:50:12", children: "Newly submitted AI products appear here right away, while admin review, blue badge activation, and moderation still stay available in the admin interface." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-5 lg:grid-cols-2 xl:grid-cols-3", "data-forge-id": "forge-mz95ka-53-6", "data-component": "div", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:53:6:129:12", children: visibleListings.map((listing) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 shadow-sm dark:border-white/10 dark:bg-white/5 dark:text-white", "data-forge-id": "forge-21pytf-55-10", "data-component": "Card", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:55:10:127:17", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { "data-forge-id": "forge-21pbtu-56-12", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:56:12:76:25", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", "data-forge-id": "forge-21oou9-57-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:57:14:75:20", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", "data-forge-id": "forge-21o1uo-58-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:58:16:66:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: listing.iconSrc, alt: listing.displayName, className: "size-12 rounded-2xl object-cover", "data-forge-id": "forge-21nev3-59-18", "data-component": "img", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:59:18:59:118" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-219d5h-60-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:60:18:65:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-xl", "data-forge-id": "forge-218q5b-61-20", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:61:20:61:84", children: listing.displayName }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { className: "mt-1 text-sm text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-21835s-62-20", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:62:20:64:38", children: listing.twitterHandle || "No X profile" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-2 text-right", "data-forge-id": "forge-214w8u-67-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:67:16:74:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-white text-orange-700 hover:bg-white dark:border-white/10 dark:bg-zinc-900 dark:text-orange-300 dark:hover:bg-zinc-900", "data-forge-id": "forge-214999-68-18", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:68:18:70:26", children: listing.planId === "free" ? "Free" : listing.planId === "starter" ? "Starter" : "Builder" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-orange-100 text-orange-700 hover:bg-orange-100 dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-20oxkl-71-18", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:71:18:73:26", children: listing.status })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4", "data-forge-id": "forge-20l3nl-77-12", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:77:12:126:26", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm leading-7 text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-20kgo0-78-14", "data-component": "p", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:78:14:78:105", children: listing.description }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-2 text-sm text-zinc-700 dark:text-zinc-300 sm:grid-cols-2", "data-forge-id": "forge-20jtoh-79-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:79:14:88:20", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50/80 px-4 py-3 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-205ryt-80-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:80:16:83:22", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-2054z8-81-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:81:18:81:114", children: "Visitors" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-204hzp-82-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:82:18:82:108", children: listing.visitorCount })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50/80 px-4 py-3 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-20380p-84-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:84:16:87:22", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-202l14-85-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:85:18:85:120", children: "Listing status" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-201y1l-86-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:86:18:86:102", children: listing.status })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(AIToolSocialPanel, { toolName: `ai-listing:${listing.id}:${listing.displayName}`, actorKey, actorLabel, "data-forge-id": "forge-200134-89-14", "data-component": "AIToolSocialPanel", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:89:14:93:16" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-3", "data-forge-id": "forge-1zjffe-94-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:94:14:117:20", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, className: "rounded-2xl bg-orange-500 text-white hover:bg-orange-400", onClick: () => {
            trackAIListingVisit(listing.id);
          }, "data-forge-id": "forge-1zisft-95-16", "data-component": "Button", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:95:16:106:25", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: listing.websiteUrl, target: "_blank", rel: "noreferrer", "data-forge-id": "forge-5kooy2-102-18", "data-component": "a", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:102:18:105:22", children: [
            "Open AI website",
            /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "size-4", "data-forge-id": "forge-5kpyxr-104-20", "data-component": "ExternalLink", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:104:20:104:55" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, variant: "outline", className: "rounded-2xl border-orange-200 bg-white text-zinc-950 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-900 dark:text-white dark:hover:bg-zinc-800", "data-forge-id": "forge-5krvvn-107-16", "data-component": "Button", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:107:16:116:25", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: listing.socialUrl, target: "_blank", rel: "noreferrer", "data-forge-id": "forge-5l8hjf-112-18", "data-component": "a", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:112:18:115:22", children: [
            "Social profile",
            /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "size-4", "data-forge-id": "forge-5l9rj4-114-20", "data-component": "Globe", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:114:20:114:48" })
          ] }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-orange-100 bg-orange-50/80 px-4 py-3 text-xs text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300", "data-forge-id": "forge-5lcbgh-118-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:118:14:125:20", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", "data-forge-id": "forge-5lcyg2-119-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:119:16:124:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "mt-0.5 size-4 shrink-0 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-5lr05q-120-18", "data-component": "Sparkles", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:120:18:120:102" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "data-forge-id": "forge-5lrn59-121-18", "data-component": "span", "data-source-pos": "src/components/octopus-market/community-ai-market.tsx:121:18:123:25", children: "Admin review still applies. Blue badge activation stays manual, and gold badge remains locked until the long-term requirement is met." })
        ] }) })
      ] })
    ] }, listing.id)) })
  ] });
}
export {
  CommunityAIMarket
};
