import { r as reactExports, j as jsxRuntimeExports, C as Card, a as CardHeader, d as Button, a0 as X, B as Badge, b as CardTitle, e as CardContent, I as Input, a1 as registerCentralWalletProfile } from "./index-C-7_nSR2.js";
function persistDismissed(walletAddress) {
  try {
    window.localStorage.setItem(`octopus-market-onboarding-dismissed-${walletAddress}`, "1");
  } catch (e) {
  }
}
function OctopusOnboardingDialog({
  walletAddress,
  walletRecord,
  onProfileSaved
}) {
  const [isDismissed, setIsDismissed] = reactExports.useState(false);
  const [displayName, setDisplayName] = reactExports.useState("");
  const [twitterHandle, setTwitterHandle] = reactExports.useState("");
  const [errorMessage, setErrorMessage] = reactExports.useState(null);
  const [isSaving, setIsSaving] = reactExports.useState(false);
  reactExports.useEffect(() => {
    if (!walletAddress) {
      setIsDismissed(false);
      return;
    }
    const storageKey = `octopus-market-onboarding-dismissed-${walletAddress}`;
    try {
      setIsDismissed(window.localStorage.getItem(storageKey) === "1");
    } catch (e) {
      setIsDismissed(false);
    }
  }, [walletAddress]);
  const isVisible = reactExports.useMemo(() => {
    if ((walletRecord == null ? void 0 : walletRecord.displayName) || (walletRecord == null ? void 0 : walletRecord.username)) return false;
    return Boolean(walletAddress) && !isDismissed;
  }, [isDismissed, walletAddress, walletRecord == null ? void 0 : walletRecord.displayName, walletRecord == null ? void 0 : walletRecord.username]);
  const handleSaveProfile = async () => {
    if (!walletAddress || isSaving) {
      return;
    }
    const trimmedDisplayName = displayName.trim();
    const trimmedTwitterHandle = twitterHandle.trim();
    if (trimmedDisplayName.length < 2) {
      setErrorMessage("Enter a valid name.");
      return;
    }
    if (!/^@[A-Za-z0-9_]{1,15}$/.test(trimmedTwitterHandle)) {
      setErrorMessage("Enter a valid X identifier in the format @username.");
      return;
    }
    try {
      setIsSaving(true);
      setErrorMessage(null);
      const nextRecord = await registerCentralWalletProfile(walletAddress, {
        displayName: trimmedDisplayName,
        twitterHandle: trimmedTwitterHandle,
        role: "user"
      });
      if (nextRecord) {
        onProfileSaved(nextRecord);
        persistDismissed(walletAddress);
        setIsDismissed(true);
      }
    } catch (error) {
      if (error instanceof Error && error.message === "username-taken") {
        setErrorMessage("This name is already linked to another wallet.");
      } else if (error instanceof Error && error.message === "username-locked") {
        setErrorMessage("This wallet already has a permanent name.");
      } else {
        setErrorMessage("Profile registration failed.");
      }
    } finally {
      setIsSaving(false);
    }
  };
  if (!isVisible) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/45 px-4 backdrop-blur-sm", "data-forge-id": "forge-dujdp-105-4", "data-component": "div", "data-source-pos": "src/components/octopus-market/octopus-onboarding-dialog.tsx:105:4:157:10", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "w-full max-w-xl border-orange-200 bg-white text-zinc-950 shadow-[0_28px_90px_rgba(249,115,22,0.22)] dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-duimy-106-6", "data-component": "Card", "data-source-pos": "src/components/octopus-market/octopus-onboarding-dialog.tsx:106:6:156:13", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { className: "relative pr-14", "data-forge-id": "forge-duhw7-107-8", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/octopus-onboarding-dialog.tsx:107:8:121:21", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "ghost", size: "icon", className: "absolute right-4 top-4 rounded-full", onClick: () => {
        if (walletAddress) persistDismissed(walletAddress);
        setIsDismissed(true);
      }, "data-forge-id": "forge-bx8rv7-108-10", "data-component": "Button", "data-source-pos": "src/components/octopus-market/octopus-onboarding-dialog.tsx:108:10:116:19", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "size-4", "data-forge-id": "forge-bwqw8d-115-12", "data-component": "X", "data-source-pos": "src/components/octopus-market/octopus-onboarding-dialog.tsx:115:12:115:36" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "w-fit border border-orange-200 bg-orange-100 text-orange-700 hover:bg-orange-100 dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-bwpm9d-117-10", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/octopus-onboarding-dialog.tsx:117:10:119:18", children: "New Phantom registration" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-2xl", "data-forge-id": "forge-bwaakp-120-10", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/octopus-onboarding-dialog.tsx:120:10:120:90", children: "Complete your Octopus Market profile" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4", "data-forge-id": "forge-dtbmm-122-8", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/octopus-onboarding-dialog.tsx:122:8:155:22", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: displayName, onChange: (event) => setDisplayName(event.target.value), placeholder: "Your name", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-900 dark:text-white", autoCorrect: "off", autoCapitalize: "words", spellCheck: false, "data-forge-id": "forge-bw8dm4-123-10", "data-component": "Input", "data-source-pos": "src/components/octopus-market/octopus-onboarding-dialog.tsx:123:10:131:12" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: twitterHandle, onChange: (event) => setTwitterHandle(event.target.value), placeholder: "@yourxhandle", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-900 dark:text-white", autoCorrect: "off", autoCapitalize: "none", spellCheck: false, "data-forge-id": "forge-bvp80a-132-10", "data-component": "Input", "data-source-pos": "src/components/octopus-market/octopus-onboarding-dialog.tsx:132:10:140:12" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: walletAddress || "", readOnly: true, className: "border-orange-200 bg-orange-50 text-zinc-950 dark:border-white/10 dark:bg-black/20 dark:text-white", "data-forge-id": "forge-bv62eg-141-10", "data-component": "Input", "data-source-pos": "src/components/octopus-market/octopus-onboarding-dialog.tsx:141:10:145:12" }),
      errorMessage ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-orange-600 dark:text-orange-300", "data-forge-id": "forge-bv2vfs-146-26", "data-component": "p", "data-source-pos": "src/components/octopus-market/octopus-onboarding-dialog.tsx:146:26:146:104", children: errorMessage }) : null,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", className: "w-full rounded-2xl bg-orange-500 text-white hover:bg-orange-400", onClick: () => void handleSaveProfile(), disabled: isSaving, "data-forge-id": "forge-bv28ha-147-10", "data-component": "Button", "data-source-pos": "src/components/octopus-market/octopus-onboarding-dialog.tsx:147:10:154:19", children: isSaving ? "Saving..." : "Save profile and continue" })
    ] })
  ] }) });
}
export {
  OctopusOnboardingDialog
};
