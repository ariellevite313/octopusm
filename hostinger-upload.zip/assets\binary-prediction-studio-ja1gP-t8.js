const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/solana-pay-PUUwvoir.js","assets/index-C-7_nSR2.js","assets/index-s_vVowBZ.css","assets/index-CE1PewnY.js"])))=>i.map(i=>d[i]);
import { c as createLucideIcon, r as reactExports, a6 as predictionMarketCategories, a2 as readPredictionHistory, g as readPredictionResolutions, n as readAdminPaymentNotifications, a7 as readAdminCreatedPredictionMarkets, o as subscribeToAdminStorage, q as subscribeToPredictionMarketStorage, a8 as predictionMarketQuestions, a9 as appendPredictionHistoryEntry, aa as notifyAdminForValidatedPayment, ab as syncPredictionHistoryToCentralRegistry, ac as syncPaymentRecordToCentralRegistry, ad as persistAdminNotificationsStateToServer, y as toast, j as jsxRuntimeExports, C as Card, a as CardHeader, B as Badge, b as CardTitle, z as CardDescription, ae as paymentTokenSymbol, e as CardContent, W as Wallet, D as formatWalletAddress, af as readCachedCentralWalletRecord, d as Button, ag as calculatePercentageAmount, I as Input, ah as predictionMarketMinStakeUsd, ai as predictionMarketMaxStakeUsd, J as predictionMarketFeeRate, aj as predictionMarketReserveFeeRate, S as ShieldCheck, ak as __vitePreload, al as getSolanaProvider, am as solanaUsdcMintAddress, p as predictionMarketTreasuryAddress, an as createPredictionMarketOnServer, ao as appendCentralAdminLog, ap as deletePredictionMarketOnServer, aq as resolvePredictionMarketOnServer, ar as syncPredictionEntriesForResolvedMarket } from "./index-C-7_nSR2.js";
import { A as Alert, a as AlertTitle, b as AlertDescription, L as LoaderCircle } from "./alert-KqzOsNqQ.js";
import { T as Textarea } from "./textarea-6tc707H_.js";
import { C as CircleCheck } from "./circle-check-DVTHR8mg.js";
import { S as Signature } from "./signature-CN2G_ivN.js";
const __iconNode$3 = [
  ["path", { d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", key: "1357e3" }],
  ["path", { d: "M3 3v5h5", key: "1xhq8a" }],
  ["path", { d: "M12 7v5l4 2", key: "1fdv2h" }]
];
const History = createLucideIcon("history", __iconNode$3);
const __iconNode$2 = [
  ["path", { d: "M5 12h14", key: "1ays0h" }],
  ["path", { d: "M12 5v14", key: "s699le" }]
];
const Plus = createLucideIcon("plus", __iconNode$2);
const __iconNode$1 = [
  ["path", { d: "M10 11v6", key: "nco0om" }],
  ["path", { d: "M14 11v6", key: "outv1u" }],
  ["path", { d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6", key: "miytrc" }],
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
  ["path", { d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2", key: "e791ji" }]
];
const Trash2 = createLucideIcon("trash-2", __iconNode$1);
const __iconNode = [
  ["path", { d: "M16 7h6v6", key: "box55l" }],
  ["path", { d: "m22 7-8.5 8.5-5-5L2 17", key: "1t1m79" }]
];
const TrendingUp = createLucideIcon("trending-up", __iconNode);
let paymentModulePromise = null;
function loadPaymentModule() {
  if (!paymentModulePromise) {
    paymentModulePromise = __vitePreload(() => import("./solana-pay-PUUwvoir.js"), true ? __vite__mapDeps([0,1,2,3]) : void 0).catch((err) => {
      paymentModulePromise = null;
      throw err;
    });
  }
  return paymentModulePromise;
}
const contractCapabilities = ["Every prediction section stays inside Octopus Market, with a wallet-gated deposit flow and local user history.", "No market is seeded by default anymore, so every live market shown here now comes directly from admin publication.", "Each validated payment creates an admin notification so the receiver wallet can approve or reject the incoming deposit.", "Winning users see claim access only after admin approval and final outcome resolution on the platform.", "The owner wallet can resolve each market directly inside the owner panel once payment review is complete."];
const roadmapItems = ["Connect the local approval flow to a production admin dashboard and a persistent backend.", "Sync exact live market pools with on-chain escrow balances and real settlement logic.", "Route approved winner claims to a production payout transaction from the owner treasury.", "Expand sports and event markets with more custom three-way or multi-outcome cards."];
function formatCurrency(amount) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 2
  }).format(amount);
}
function formatMoment(timestamp) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(timestamp));
}
function clampValue(value, min, max) {
  return Math.min(max, Math.max(min, value));
}
function getDemandSplit(index) {
  const yesShare = 52 + index * 7 % 21;
  return {
    yesShare,
    noShare: 100 - yesShare,
    volume: 240 + index * 42
  };
}
function getDefaultMarketOptions(index) {
  const demand = getDemandSplit(index);
  const yesOdds = Number(clampValue(0.96 / (demand.yesShare / 100), 1.18, 3.2).toFixed(2));
  const noOdds = Number(clampValue(0.96 / (demand.noShare / 100), 1.18, 3.4).toFixed(2));
  return [{
    id: "yes",
    label: "Yes",
    oddsMultiplier: yesOdds,
    description: "Choose the yes side.",
    initialVolumeUsd: Number((demand.volume * (demand.yesShare / 100)).toFixed(2))
  }, {
    id: "no",
    label: "No",
    oddsMultiplier: noOdds,
    description: "Choose the no side.",
    initialVolumeUsd: Number((demand.volume * (demand.noShare / 100)).toFixed(2))
  }];
}
function getMarketOptions(question, index) {
  var _a;
  return ((_a = question.options) == null ? void 0 : _a.length) ? question.options : getDefaultMarketOptions(index);
}
function buildOptionSummaries(question, marketOptions, allHistoryEntries, paymentNotifications, amount) {
  return marketOptions.map((option) => {
    var _a;
    const relevantEntries = allHistoryEntries.filter((entry) => {
      if (entry.marketId !== question.id || entry.selectionId !== option.id) {
        return false;
      }
      const paymentNotification = paymentNotifications.find((notification) => notification.paymentReference === entry.paymentReference);
      return (paymentNotification == null ? void 0 : paymentNotification.status) !== "rejected";
    });
    const liveVolumeUsd = Number((((_a = option.initialVolumeUsd) != null ? _a : 0) + relevantEntries.reduce((total, entry) => total + entry.amount, 0)).toFixed(2));
    const grossReturnUsd = Number((amount * option.oddsMultiplier).toFixed(2));
    const netReturnUsd = Number((grossReturnUsd * (1 - predictionMarketFeeRate / 100)).toFixed(2));
    return {
      ...option,
      liveVolumeUsd,
      grossReturnUsd,
      netReturnUsd
    };
  });
}
function getSelectionTone(optionId) {
  if (optionId === "x-draw") {
    return "amber";
  }
  if (optionId === "b-win" || optionId === "no") {
    return "red";
  }
  return "green";
}
function getSelectionClasses(optionId, isActive) {
  const tone = getSelectionTone(optionId);
  if (isActive) {
    if (tone === "red") {
      return "border-red-300 bg-red-600 text-white hover:bg-red-500";
    }
    if (tone === "amber") {
      return "border-amber-300 bg-amber-500 text-white hover:bg-amber-400";
    }
    return "border-emerald-300 bg-emerald-600 text-white hover:bg-emerald-500";
  }
  return "border-orange-200 bg-white text-zinc-950 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900";
}
function readStringMetadataValue(value, fallback = "") {
  return typeof value === "string" ? value : fallback;
}
function readNumberMetadataValue(value, fallback = 0) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}
function redirectToPredictionHistory() {
  if (typeof window === "undefined") {
    return;
  }
  window.history.replaceState(null, "", "#prediction-player-history");
  window.setTimeout(() => {
    var _a;
    (_a = window.document.getElementById("prediction-player-history")) == null ? void 0 : _a.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  }, 120);
}
function buildPredictionHistoryEntryFromPaymentRequest(paymentRequest) {
  var _a, _b;
  const metadata = (_a = paymentRequest.metadata) != null ? _a : {};
  const paymentReference = paymentRequest.reference;
  return {
    id: `${readStringMetadataValue(metadata.marketId, paymentRequest.id)}-${paymentReference}`,
    marketId: readStringMetadataValue(metadata.marketId, paymentRequest.id),
    marketTitle: readStringMetadataValue(metadata.marketTitle, paymentRequest.message || "Prediction market"),
    categoryLabel: readStringMetadataValue(metadata.categoryLabel, "Prediction market"),
    selectionId: readStringMetadataValue(metadata.selectionId),
    selectionLabel: readStringMetadataValue(metadata.selectionLabel, paymentRequest.memo || "Market side"),
    amount: readNumberMetadataValue(metadata.stake, paymentRequest.amount),
    reserveFee: readNumberMetadataValue(metadata.reserveFee),
    totalCharged: readNumberMetadataValue(metadata.totalChargeUsdc, paymentRequest.amount),
    claimFeeRate: readNumberMetadataValue(metadata.claimFeeRate, predictionMarketFeeRate),
    payoutMultiple: readNumberMetadataValue(metadata.payoutMultiple, 1),
    grossReward: readNumberMetadataValue(metadata.grossReward),
    netReward: readNumberMetadataValue(metadata.netReward),
    walletAddress: paymentRequest.walletAddress,
    paymentReference,
    paymentRequestId: paymentRequest.id,
    createdAt: (_b = paymentRequest.validatedAt) != null ? _b : paymentRequest.createdAt,
    reportedAt: Date.now(),
    adminDecisionStatus: "pending",
    resultStatus: "pending_review"
  };
}
function createInitialAdminMarketDraft() {
  var _a, _b;
  return {
    categoryId: (_b = (_a = predictionMarketCategories[0]) == null ? void 0 : _a.id) != null ? _b : "crypto",
    title: "",
    resolutionLabel: "Resolved by Octopus Market admin after the event result is confirmed",
    eventDateLabel: "",
    mode: "vs",
    enableThirdOption: false,
    leftCompetitorName: "",
    leftCompetitorImageSrc: "",
    rightCompetitorName: "",
    rightCompetitorImageSrc: "",
    singleName: "",
    singleImageSrc: "",
    firstOdds: "1.8",
    secondOdds: "1.8",
    thirdOptionLabel: "X",
    thirdOptionOdds: "3.2",
    thirdOptionImageSrc: "",
    extraNotes: ""
  };
}
function readImageFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        resolve(reader.result);
        return;
      }
      reject(new Error("image-read-failed"));
    };
    reader.onerror = () => reject(new Error("image-read-failed"));
    reader.readAsDataURL(file);
  });
}
function buildAdminCreatedMarketId(title) {
  return `admin-market-${title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "")}-${Date.now().toString(36)}`;
}
function buildAdminCreatedMarketOptions(draft) {
  if (draft.mode === "vs") {
    const nextOptions2 = [{
      id: "left-win",
      label: `${draft.leftCompetitorName.trim() || "Team A"} Win`,
      oddsMultiplier: Number(draft.firstOdds),
      description: draft.extraNotes.trim() || "Admin-created left team side.",
      logoSrc: draft.leftCompetitorImageSrc.trim() || void 0,
      initialVolumeUsd: 0
    }, {
      id: "right-win",
      label: `${draft.rightCompetitorName.trim() || "Team B"} Win`,
      oddsMultiplier: Number(draft.secondOdds),
      description: draft.extraNotes.trim() || "Admin-created right team side.",
      logoSrc: draft.rightCompetitorImageSrc.trim() || void 0,
      initialVolumeUsd: 0
    }];
    if (draft.enableThirdOption) {
      nextOptions2.splice(1, 0, {
        id: "third-option",
        label: draft.thirdOptionLabel.trim() || "X",
        oddsMultiplier: Number(draft.thirdOptionOdds),
        description: draft.extraNotes.trim() || "Admin-created third option.",
        logoSrc: draft.thirdOptionImageSrc.trim() || void 0,
        initialVolumeUsd: 0
      });
    }
    return nextOptions2;
  }
  const nextOptions = [{
    id: "yes",
    label: "Yes",
    oddsMultiplier: Number(draft.firstOdds),
    description: draft.extraNotes.trim() || "Admin-created yes side.",
    initialVolumeUsd: 0
  }, {
    id: "no",
    label: "No",
    oddsMultiplier: Number(draft.secondOdds),
    description: draft.extraNotes.trim() || "Admin-created no side.",
    initialVolumeUsd: 0
  }];
  if (draft.enableThirdOption) {
    nextOptions.push({
      id: "third-option",
      label: draft.thirdOptionLabel.trim() || "Third option",
      oddsMultiplier: Number(draft.thirdOptionOdds),
      description: draft.extraNotes.trim() || "Admin-created third option.",
      logoSrc: draft.thirdOptionImageSrc.trim() || void 0,
      initialVolumeUsd: 0
    });
  }
  return nextOptions;
}
function BinaryPredictionStudio({
  isWalletConnected,
  walletAddress,
  walletUsername,
  onConnectWallet,
  selectedCategoryId,
  selectedMarketId
}) {
  var _a, _b, _c, _d;
  const [activeCategoryId, setActiveCategoryId] = reactExports.useState((_b = (_a = predictionMarketCategories[0]) == null ? void 0 : _a.id) != null ? _b : "crypto");
  const [amounts, setAmounts] = reactExports.useState({});
  const [selections, setSelections] = reactExports.useState({});
  const [history, setHistory] = reactExports.useState(() => readPredictionHistory());
  const [resolutions, setResolutions] = reactExports.useState(() => readPredictionResolutions());
  const [adminNotifications, setAdminNotifications] = reactExports.useState(() => readAdminPaymentNotifications());
  const [adminCreatedMarkets, setAdminCreatedMarkets] = reactExports.useState(() => readAdminCreatedPredictionMarkets());
  const [signingMarketId, setSigningMarketId] = reactExports.useState(null);
  const [claimingEntryId, setClaimingEntryId] = reactExports.useState(null);
  const [latestPaymentRequest, setLatestPaymentRequest] = reactExports.useState(null);
  const [isRecoveringPendingPayments, setIsRecoveringPendingPayments] = reactExports.useState(false);
  const reportedReferencesRef = reactExports.useRef(/* @__PURE__ */ new Set());
  const [showAdminMarketForm, setShowAdminMarketForm] = reactExports.useState(false);
  const [adminMarketDraft, setAdminMarketDraft] = reactExports.useState(() => createInitialAdminMarketDraft());
  reactExports.useEffect(() => {
    return subscribeToAdminStorage(() => {
      setAdminNotifications(readAdminPaymentNotifications());
    });
  }, []);
  reactExports.useEffect(() => {
    return subscribeToPredictionMarketStorage(() => {
      setAdminCreatedMarkets(readAdminCreatedPredictionMarkets());
      setHistory(readPredictionHistory());
      setResolutions(readPredictionResolutions());
    });
  }, []);
  reactExports.useEffect(() => {
    if (!selectedCategoryId) {
      return;
    }
    setActiveCategoryId(selectedCategoryId);
  }, [selectedCategoryId]);
  reactExports.useEffect(() => {
    if (!selectedMarketId || typeof window === "undefined") {
      return;
    }
    const frame = window.requestAnimationFrame(() => {
      var _a2;
      (_a2 = window.document.getElementById(`prediction-market-card-${selectedMarketId}`)) == null ? void 0 : _a2.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    });
    return () => {
      window.cancelAnimationFrame(frame);
    };
  }, [selectedMarketId, activeCategoryId]);
  const activeCategory = (_c = predictionMarketCategories.find((category) => category.id === activeCategoryId)) != null ? _c : predictionMarketCategories[0];
  const allPredictionMarkets = reactExports.useMemo(() => [...predictionMarketQuestions, ...adminCreatedMarkets], [adminCreatedMarkets]);
  const visibleQuestions = reactExports.useMemo(() => allPredictionMarkets.filter((question) => question.categoryId === activeCategoryId), [activeCategoryId, allPredictionMarkets]);
  const ownerWalletConnected = walletAddress === predictionMarketTreasuryAddress;
  const derivedHistory = reactExports.useMemo(() => history.map((entry) => {
    var _a2;
    const resolution = resolutions[entry.marketId];
    const paymentNotification = adminNotifications.find((notification) => notification.paymentReference === entry.paymentReference);
    const adminStatus = (_a2 = paymentNotification == null ? void 0 : paymentNotification.status) != null ? _a2 : "pending";
    const isResolved = Boolean(resolution);
    const isWinner = isResolved && resolution.outcomeId === entry.selectionId && adminStatus === "approved";
    const isLoser = isResolved && resolution.outcomeId !== entry.selectionId && adminStatus === "approved";
    const canClaim = isWinner && !entry.claimedAt;
    return {
      ...entry,
      resolution,
      adminStatus,
      isResolved,
      isWinner,
      isLoser,
      canClaim
    };
  }), [adminNotifications, history, resolutions]);
  const totalPositioned = reactExports.useMemo(() => history.reduce((total, entry) => total + entry.amount, 0), [history]);
  const totalReserveFees = reactExports.useMemo(() => history.reduce((total, entry) => total + entry.reserveFee, 0), [history]);
  const totalClaimable = reactExports.useMemo(() => derivedHistory.reduce((total, entry) => {
    if (!entry.canClaim || walletAddress !== entry.walletAddress) {
      return total;
    }
    return total + entry.netReward;
  }, 0), [derivedHistory, walletAddress]);
  const handleReportValidatedPayment = reactExports.useCallback((paymentRequest) => {
    if (reportedReferencesRef.current.has(paymentRequest.reference)) {
      return;
    }
    reportedReferencesRef.current.add(paymentRequest.reference);
    const historyEntry = buildPredictionHistoryEntryFromPaymentRequest(paymentRequest);
    appendPredictionHistoryEntry(historyEntry);
    const notification = notifyAdminForValidatedPayment(paymentRequest);
    void (async () => {
      await Promise.allSettled([syncPredictionHistoryToCentralRegistry(), syncPaymentRecordToCentralRegistry(notification), persistAdminNotificationsStateToServer()]);
      setHistory(readPredictionHistory());
      setAdminNotifications(readAdminPaymentNotifications());
      setLatestPaymentRequest(null);
      toast.success(`Pari enregistré · ${historyEntry.marketTitle}`, {
        description: `Position sur "${historyEntry.selectionLabel}" en attente de validation admin.`,
        duration: 5e3
      });
      redirectToPredictionHistory();
    })();
  }, []);
  const recoverPredictionPayments = reactExports.useCallback(async () => {
    if (isRecoveringPendingPayments || !latestPaymentRequest || latestPaymentRequest.kind !== "prediction") {
      return;
    }
    if (history.some((entry) => entry.paymentReference === latestPaymentRequest.reference) || reportedReferencesRef.current.has(latestPaymentRequest.reference)) {
      return;
    }
    try {
      setIsRecoveringPendingPayments(true);
      const paymentModule = await loadPaymentModule();
      const foundReference = await paymentModule.findReference(latestPaymentRequest.reference);
      if (!(foundReference == null ? void 0 : foundReference.signature)) {
        return;
      }
      await paymentModule.validateTransfer(foundReference.signature, {
        recipient: latestPaymentRequest.recipient,
        amount: latestPaymentRequest.amount,
        reference: latestPaymentRequest.reference,
        currency: latestPaymentRequest.currency,
        tokenMint: latestPaymentRequest.tokenMint,
        tokenDecimals: latestPaymentRequest.tokenDecimals
      });
      const validatedPaymentRequest = await paymentModule.fetchTransaction(latestPaymentRequest.id);
      if ((validatedPaymentRequest == null ? void 0 : validatedPaymentRequest.status) === "validated") {
        handleReportValidatedPayment(validatedPaymentRequest);
      }
    } catch (e) {
      return;
    } finally {
      setIsRecoveringPendingPayments(false);
    }
  }, [handleReportValidatedPayment, history, isRecoveringPendingPayments, latestPaymentRequest]);
  reactExports.useEffect(() => {
    void recoverPredictionPayments();
  }, [recoverPredictionPayments]);
  reactExports.useEffect(() => {
    if (typeof window === "undefined") {
      return;
    }
    const handleVisibilityChange = () => {
      if (!document.hidden) {
        void recoverPredictionPayments();
      }
    };
    window.addEventListener("focus", handleVisibilityChange);
    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => {
      window.removeEventListener("focus", handleVisibilityChange);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, [recoverPredictionPayments]);
  const handleChooseSelection = (marketId, selectionId) => {
    setSelections((currentSelections) => ({
      ...currentSelections,
      [marketId]: selectionId
    }));
  };
  const handleAmountChange = (marketId, value) => {
    setAmounts((currentAmounts) => ({
      ...currentAmounts,
      [marketId]: value
    }));
  };
  function handleAdminDraftChange(key, value) {
    setAdminMarketDraft((currentValue) => ({
      ...currentValue,
      [key]: value
    }));
  }
  const handleAdminMarketImageUpload = async (key, fileList) => {
    const nextFile = fileList == null ? void 0 : fileList[0];
    if (!nextFile) {
      return;
    }
    try {
      const nextImageSrc = await readImageFileAsDataUrl(nextFile);
      handleAdminDraftChange(key, nextImageSrc);
    } catch (e) {
      toast.error("Image invalide", {
        description: "L'image n'a pas pu être chargée. Essayez un autre fichier."
      });
    }
  };
  const renderMarketHeadline = (market) => {
    var _a2, _b2, _c2, _d2, _e, _f;
    if (market.visualType === "vs") {
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-c5hsn9-725-8", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:725:8:743:14", children: [
        market.leftCompetitorImageSrc ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: market.leftCompetitorImageSrc, alt: `${(_a2 = market.leftCompetitorName) != null ? _a2 : "Left team"} logo`, className: "size-8 rounded-full border border-white/60 object-cover", "data-forge-id": "forge-lkq4as-727-12", "data-component": "img", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:727:12:731:14" }) : null,
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "data-forge-id": "forge-lk8vnl-733-10", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:733:10:733:62", children: (_b2 = market.leftCompetitorName) != null ? _b2 : "Team A" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-zinc-400 dark:text-zinc-500", "data-forge-id": "forge-lk88o2-734-10", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:734:10:734:70", children: "vs" }),
        market.rightCompetitorImageSrc ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: market.rightCompetitorImageSrc, alt: `${(_c2 = market.rightCompetitorName) != null ? _c2 : "Right team"} logo`, className: "size-8 rounded-full border border-white/60 object-cover", "data-forge-id": "forge-lk6yoy-736-12", "data-component": "img", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:736:12:740:14" }) : null,
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "data-forge-id": "forge-ljpq1r-742-10", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:742:10:742:63", children: (_d2 = market.rightCompetitorName) != null ? _d2 : "Team B" })
      ] });
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-3 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-c5ggg6-748-6", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:748:6:757:12", children: [
      market.singleImageSrc ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: market.singleImageSrc, alt: `${(_e = market.singleName) != null ? _e : market.title} logo`, className: "size-8 rounded-full border border-white/60 object-cover", "data-forge-id": "forge-lj77fg-750-10", "data-component": "img", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:750:10:754:12" }) : null,
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "data-forge-id": "forge-c5fuxz-756-8", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:756:8:756:56", children: (_f = market.singleName) != null ? _f : market.title })
    ] });
  };
  const handleCreateAdminMarket = async () => {
    var _a2, _b2, _c2;
    if (!ownerWalletConnected || !walletAddress) {
      toast.error("Accès refusé", {
        description: "Seul le wallet admin peut créer un marché."
      });
      return;
    }
    const trimmedTitle = adminMarketDraft.title.trim();
    const trimmedResolution = adminMarketDraft.resolutionLabel.trim();
    if (!trimmedTitle || !trimmedResolution) {
      toast.error("Champs manquants", {
        description: "Ajoutez un titre et une règle de résolution avant de publier."
      });
      return;
    }
    if (adminMarketDraft.mode === "vs") {
      if (!adminMarketDraft.leftCompetitorName.trim() || !adminMarketDraft.rightCompetitorName.trim()) {
        toast.error("Noms manquants", {
          description: "Ajoutez les deux noms d'équipe pour un marché VS."
        });
        return;
      }
    }
    if (adminMarketDraft.mode === "simple" && !adminMarketDraft.singleName.trim()) {
      toast.error("Nom manquant", {
        description: "Ajoutez le nom du sujet pour ce marché simple."
      });
      return;
    }
    const nextOptions = buildAdminCreatedMarketOptions(adminMarketDraft);
    if (nextOptions.some((option) => !Number.isFinite(option.oddsMultiplier) || option.oddsMultiplier <= 1)) {
      toast.error("Cotes invalides", {
        description: "Chaque option doit avoir une cote valide supérieure à 1."
      });
      return;
    }
    const nextMarket = {
      id: buildAdminCreatedMarketId(trimmedTitle),
      categoryId: adminMarketDraft.categoryId,
      title: trimmedTitle,
      marketType: adminMarketDraft.enableThirdOption ? "three-way" : adminMarketDraft.mode === "vs" ? "threshold" : "yes-no",
      visualType: adminMarketDraft.mode,
      leftCompetitorName: adminMarketDraft.mode === "vs" ? adminMarketDraft.leftCompetitorName.trim() : void 0,
      leftCompetitorImageSrc: adminMarketDraft.mode === "vs" && adminMarketDraft.leftCompetitorImageSrc.trim() ? adminMarketDraft.leftCompetitorImageSrc.trim() : void 0,
      rightCompetitorName: adminMarketDraft.mode === "vs" ? adminMarketDraft.rightCompetitorName.trim() : void 0,
      rightCompetitorImageSrc: adminMarketDraft.mode === "vs" && adminMarketDraft.rightCompetitorImageSrc.trim() ? adminMarketDraft.rightCompetitorImageSrc.trim() : void 0,
      singleName: adminMarketDraft.mode === "simple" ? adminMarketDraft.singleName.trim() : void 0,
      singleImageSrc: adminMarketDraft.mode === "simple" && adminMarketDraft.singleImageSrc.trim() ? adminMarketDraft.singleImageSrc.trim() : void 0,
      resolutionLabel: trimmedResolution,
      eventDateLabel: adminMarketDraft.eventDateLabel.trim() || void 0,
      options: nextOptions,
      createdAt: Date.now(),
      createdByWallet: walletAddress,
      isAdminCreated: true
    };
    const commitResult = await createPredictionMarketOnServer(nextMarket, walletAddress);
    if (!commitResult) {
      toast.error("Erreur base de données", {
        description: "Le marché n'a pas pu être enregistré. Réessayez."
      });
      return;
    }
    setAdminCreatedMarkets(commitResult.markets);
    setResolutions(commitResult.resolutions);
    void appendCentralAdminLog({
      adminWallet: walletAddress,
      action: "create_prediction",
      targetId: nextMarket.id,
      details: JSON.stringify({
        categoryId: nextMarket.categoryId,
        title: nextMarket.title,
        marketType: nextMarket.marketType,
        visualType: nextMarket.visualType,
        options: (_a2 = nextMarket.options) == null ? void 0 : _a2.map((option) => ({
          id: option.id,
          label: option.label,
          oddsMultiplier: option.oddsMultiplier
        }))
      })
    });
    setActiveCategoryId(nextMarket.categoryId);
    setShowAdminMarketForm(false);
    setAdminMarketDraft(createInitialAdminMarketDraft());
    toast.success(`Marché publié`, {
      description: `${nextMarket.title} est maintenant visible dans la section ${(_c2 = (_b2 = predictionMarketCategories.find((c) => c.id === nextMarket.categoryId)) == null ? void 0 : _b2.label) != null ? _c2 : "sélectionnée"}.`
    });
  };
  const handleResolveMarket = async (market, outcomeId) => {
    var _a2, _b2;
    if (!ownerWalletConnected || !walletAddress) {
      toast.error("Accès refusé", {
        description: "Seul le wallet admin peut résoudre un marché."
      });
      return;
    }
    const resolvedOption = getMarketOptions(market, 0).find((option) => option.id === outcomeId);
    const commitResult = await resolvePredictionMarketOnServer(market.id, outcomeId, walletAddress);
    if (!commitResult) {
      toast.error("Erreur base de données", {
        description: "Le résultat n'a pas pu être enregistré. Réessayez."
      });
      return;
    }
    setAdminCreatedMarkets(commitResult.markets);
    setResolutions(commitResult.resolutions);
    const resolvedRecord = commitResult.resolutions[market.id];
    if (resolvedRecord) {
      syncPredictionEntriesForResolvedMarket({
        marketId: market.id,
        outcomeId: resolvedRecord.outcomeId,
        resolvedAt: resolvedRecord.resolvedAt,
        resolvedByWallet: resolvedRecord.resolvedByWallet
      });
    }
    void appendCentralAdminLog({
      adminWallet: walletAddress,
      action: "resolve_prediction",
      targetId: market.id,
      details: JSON.stringify({
        marketTitle: market.title,
        outcomeId,
        outcomeLabel: (_a2 = resolvedOption == null ? void 0 : resolvedOption.label) != null ? _a2 : outcomeId
      })
    });
    toast.success(`Marché résolu`, {
      description: `${market.title} — côté gagnant : ${(_b2 = resolvedOption == null ? void 0 : resolvedOption.label) != null ? _b2 : outcomeId}. Les gains sont maintenant réclamables.`
    });
  };
  const handleDeleteMarket = async (market) => {
    if (!ownerWalletConnected || !walletAddress) {
      toast.error("Accès refusé", {
        description: "Seul le wallet admin peut supprimer un marché."
      });
      return;
    }
    const commitResult = await deletePredictionMarketOnServer(market.id, walletAddress);
    if (!commitResult) {
      toast.error("Erreur base de données", {
        description: "Le marché n'a pas pu être supprimé. Réessayez."
      });
      return;
    }
    setAdminCreatedMarkets(commitResult.markets);
    setResolutions(commitResult.resolutions);
    void appendCentralAdminLog({
      adminWallet: walletAddress,
      action: "remove_prediction",
      targetId: market.id,
      details: JSON.stringify({
        marketTitle: market.title,
        categoryId: market.categoryId
      })
    });
    toast.success(`Marché supprimé`, {
      description: `${market.title} a été retiré de la base de données.`
    });
  };
  const handleConfirmPosition = async (market, marketIndex) => {
    var _a2, _b2;
    if (walletAddress && ((_a2 = readCachedCentralWalletRecord(walletAddress)) == null ? void 0 : _a2.status) === "suspended") {
      toast.error("Wallet suspendu", {
        description: "Ce wallet est suspendu et ne peut pas placer de pari."
      });
      return;
    }
    const rawAmount = (_b2 = amounts[market.id]) != null ? _b2 : "";
    const amount = Number(rawAmount);
    const selectedOptionId = selections[market.id];
    const marketOptions = getMarketOptions(market, marketIndex);
    const selectedOption = marketOptions.find((option) => option.id === selectedOptionId);
    if (!selectedOption) {
      toast.error("Sélection manquante", {
        description: `Choisissez une option pour ${market.title}.`
      });
      return;
    }
    if (!Number.isFinite(amount) || amount < predictionMarketMinStakeUsd || amount > predictionMarketMaxStakeUsd) {
      toast.error("Montant invalide", {
        description: `Entrez un montant entre ${formatCurrency(predictionMarketMinStakeUsd)} et ${formatCurrency(predictionMarketMaxStakeUsd)}.`
      });
      return;
    }
    let connectedWallet = walletAddress;
    if (!connectedWallet) {
      connectedWallet = await onConnectWallet();
    }
    if (!connectedWallet) {
      toast.error("Wallet requis", {
        description: "Connectez un wallet Solana pour confirmer votre position."
      });
      return;
    }
    const provider = getSolanaProvider();
    if (!(provider == null ? void 0 : provider.signAndSendTransaction) && !(provider == null ? void 0 : provider.signTransaction)) {
      toast.error(`Wallet incompatible`, {
        description: `Ce wallet ne peut pas envoyer de ${paymentTokenSymbol} pour le moment.`
      });
      return;
    }
    const reserveFee = calculatePercentageAmount(amount, predictionMarketReserveFeeRate);
    const totalChargeUsd = Number((amount + reserveFee).toFixed(2));
    const grossReward = Number((amount * selectedOption.oddsMultiplier).toFixed(2));
    const netReward = Number((grossReward * (1 - predictionMarketFeeRate / 100)).toFixed(2));
    const paymentModule = await loadPaymentModule();
    const transferRequest = await paymentModule.buildTransaction({
      kind: "prediction",
      recipient: predictionMarketTreasuryAddress,
      amount: totalChargeUsd,
      walletAddress: connectedWallet,
      currency: "USDC",
      tokenMint: solanaUsdcMintAddress,
      tokenDecimals: 6,
      label: "Octopus Market prediction market",
      message: `${market.title} · ${selectedOption.label}`,
      memo: `${activeCategory.label} market position`,
      metadata: {
        onChainTransfer: true,
        marketId: market.id,
        marketTitle: market.title,
        categoryLabel: activeCategory.label,
        selectionId: selectedOption.id,
        selectionLabel: selectedOption.label,
        payoutMultiple: selectedOption.oddsMultiplier,
        grossReward,
        netReward,
        claimFeeRate: predictionMarketFeeRate,
        stake: amount,
        reserveFee,
        totalChargeUsd,
        totalChargeUsdc: totalChargeUsd,
        ...(walletUsername == null ? void 0 : walletUsername.trim()) ? {
          username: walletUsername.trim()
        } : {}
      }
    });
    setLatestPaymentRequest(transferRequest);
    try {
      setSigningMarketId(market.id);
      await paymentModule.submitSolanaTransfer(transferRequest);
      const foundReference = await paymentModule.findReference(transferRequest.reference);
      if (!(foundReference == null ? void 0 : foundReference.signature)) {
        throw new Error("reference-not-found");
      }
      await paymentModule.validateTransfer(foundReference.signature, {
        recipient: predictionMarketTreasuryAddress,
        amount: totalChargeUsd,
        reference: transferRequest.reference,
        currency: "USDC",
        tokenMint: solanaUsdcMintAddress,
        tokenDecimals: 6
      });
      const storedValidatedTransfer = await paymentModule.fetchTransaction(transferRequest.id);
      if (!storedValidatedTransfer || storedValidatedTransfer.status !== "validated") {
        throw new Error("validated-transfer-required");
      }
      handleReportValidatedPayment(storedValidatedTransfer);
    } catch (error) {
      const msg = error instanceof Error ? error.message.toLowerCase() : String(error).toLowerCase();
      if (msg.includes("insufficient") || msg.includes("0x1") || msg.includes("custom program error: 0x1") || msg.includes("not enough")) {
        toast.error("Fonds USDC insuffisants", {
          description: "Vérifiez votre solde USDC avant de placer ce pari."
        });
      } else if (msg.includes("reference-not-found") || msg.includes("timeout") || msg.includes("timed out")) {
        toast.error("Confirmation expirée", {
          description: "La transaction n'a pas été confirmée à temps. Si le montant a été débité, il réapparaîtra automatiquement à la reconnexion.",
          duration: 7e3
        });
      } else if (msg.includes("cancel") || msg.includes("rejected") || msg.includes("user rejected") || msg.includes("denied")) {
        toast.error("Transaction annulée", {
          description: "Le paiement a été refusé dans Phantom."
        });
      } else if (msg.includes("failed to fetch") || msg.includes("dynamically imported") || msg.includes("load failed") || msg.includes("networkerror")) {
        toast.error("Erreur réseau", {
          description: "Le module de paiement n'a pas pu être chargé. Vérifiez votre connexion et réessayez."
        });
      } else {
        toast.error("Échec du paiement", {
          description: "Le transfert Phantom a échoué ou n'a pas pu être validé on-chain."
        });
      }
    } finally {
      setSigningMarketId(null);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", "data-forge-id": "forge-ofl1gq-1154-4", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1154:4:1854:10", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { id: "prediction-market-studio", className: "scroll-mt-32", "data-forge-id": "forge-ofl0pz-1155-6", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1155:6:1155:68" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-6 xl:grid-cols-[1.2fr_0.8fr]", "data-forge-id": "forge-ofkzza-1156-6", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1156:6:1853:12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 shadow-sm dark:border-white/10 dark:bg-white/5 dark:text-white", "data-forge-id": "forge-ofkz8j-1157-8", "data-component": "Card", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1157:8:1368:15", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-nx6w8p-1158-10", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1158:10:1171:23", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-3", "data-forge-id": "forge-nx7j8a-1159-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1159:12:1166:18", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-orange-100 text-orange-700 hover:bg-orange-100 dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-nxlkxy-1160-14", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1160:14:1162:22", children: "Prediction market sections" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-white text-zinc-700 hover:bg-white dark:border-white/10 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-900", "data-forge-id": "forge-nxnhwj-1163-14", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1163:14:1165:22", children: "Wallet approval required" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-2xl", "data-forge-id": "forge-nxq1ul-1167-12", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1167:12:1167:103", children: "Take positions by section inside Octopus Market" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardDescription, { className: "text-base leading-7 text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-nxqou4-1168-12", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1168:12:1170:30", children: [
            "Choose one section at a time, pick a prediction, enter a stake between ",
            formatCurrency(predictionMarketMinStakeUsd),
            " and ",
            formatCurrency(predictionMarketMaxStakeUsd),
            ", then confirm the ",
            paymentTokenSymbol,
            " debit in Phantom."
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-6", "data-forge-id": "forge-ny6ni9-1172-10", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1172:10:1367:24", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Alert, { className: "border-orange-200 bg-orange-50/70 text-zinc-950 dark:border-white/10 dark:bg-white/5 dark:text-white", "data-forge-id": "forge-ny7ahu-1173-12", "data-component": "Alert", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1173:12:1181:20", children: [
            isWalletConnected ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "size-4", "data-forge-id": "forge-ny7xj6-1174-35", "data-component": "CheckCircle2", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1174:35:1174:70" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Wallet, { className: "size-4", "data-forge-id": "forge-ny7xmk-1174-73", "data-component": "Wallet", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1174:73:1174:102" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(AlertTitle, { "data-forge-id": "forge-ny8kgy-1175-14", "data-component": "AlertTitle", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1175:14:1175:131", children: isWalletConnected ? "Wallet unlocked for utilities" : "Connect wallet to unlock utilities" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDescription, { "data-forge-id": "forge-ny97gh-1176-14", "data-component": "AlertDescription", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1176:14:1180:33", children: isWalletConnected ? `Connected wallet: ${formatWalletAddress(walletAddress)}${((_d = readCachedCentralWalletRecord(walletAddress != null ? walletAddress : "")) == null ? void 0 : _d.status) === "suspended" ? " · suspended" : ""}` : "Prediction positions, launch actions, and assistant interactions are gated until a Solana wallet is connected." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", "data-forge-id": "forge-nyr337-1183-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1183:12:1206:18", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-zinc-900 dark:text-zinc-100", "data-forge-id": "forge-nyrq2s-1184-14", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1184:14:1184:109", children: "Choose a market section" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-3", "data-forge-id": "forge-nysd2b-1185-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1185:14:1201:20", children: predictionMarketCategories.map((category) => /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: category.id === activeCategoryId ? "default" : "outline", className: category.id === activeCategoryId ? "rounded-2xl bg-orange-500 text-white hover:bg-orange-400" : "rounded-2xl border-orange-200 bg-white text-zinc-950 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900", onClick: () => setActiveCategoryId(category.id), "data-forge-id": "forge-nytn1h-1187-18", "data-component": "Button", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1187:18:1199:27", children: category.label }, category.id)) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-200 bg-orange-50 px-4 py-4 text-sm leading-6 text-zinc-700 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300", "data-forge-id": "forge-obdpr1-1202-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1202:14:1205:20", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-obecqm-1203-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1203:16:1203:100", children: activeCategory == null ? void 0 : activeCategory.label }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1", "data-forge-id": "forge-obezq5-1204-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1204:16:1204:69", children: activeCategory == null ? void 0 : activeCategory.description })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", "data-forge-id": "forge-obhjo5-1208-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1208:12:1366:18", children: [
            visibleQuestions.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-dashed border-orange-200 bg-white px-5 py-6 text-sm leading-7 text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-400", "data-forge-id": "forge-obw8de-1210-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1210:16:1212:22", children: "No live bets are open in this section yet. Add a new market from the admin panel and it will appear here automatically." }) : null,
            visibleQuestions.map((market, index) => {
              var _a2;
              const amountValue = (_a2 = amounts[market.id]) != null ? _a2 : "";
              const chosenSelectionId = selections[market.id];
              const numericAmount = Number(amountValue);
              const stakePreviewAmount = Number.isFinite(numericAmount) && numericAmount >= predictionMarketMinStakeUsd ? numericAmount : predictionMarketMinStakeUsd;
              const reserveFee = Number.isFinite(numericAmount) ? calculatePercentageAmount(numericAmount, predictionMarketReserveFeeRate) : 0;
              const totalCharge = Number.isFinite(numericAmount) ? Number((numericAmount + reserveFee).toFixed(2)) : 0;
              const marketOptions = getMarketOptions(market, index);
              const optionSummaries = buildOptionSummaries(market, marketOptions, history, adminNotifications, stakePreviewAmount);
              const isSigning = signingMarketId === market.id;
              const resolution = resolutions[market.id];
              const resolvedOption = resolution ? marketOptions.find((option) => option.id === resolution.outcomeId) : void 0;
              return /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { id: `prediction-market-card-${market.id}`, className: `text-zinc-950 shadow-none dark:text-white ${selectedMarketId === market.id ? "border-orange-400 bg-orange-100/80 ring-1 ring-orange-300 dark:border-orange-400/50 dark:bg-orange-500/10 dark:ring-orange-400/30" : "border-orange-200 bg-orange-50/60 dark:border-white/10 dark:bg-black/20"}`, "data-forge-id": "forge-odkw4l-1242-18", "data-component": "Card", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1242:18:1363:25", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4 p-5", "data-forge-id": "forge-oe41r2-1251-20", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1251:20:1362:34", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-3", "data-forge-id": "forge-oe4oqn-1252-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1252:22:1277:28", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-oe5bq8-1253-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1253:24:1266:30", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-semibold uppercase tracking-[0.16em] text-orange-600 dark:text-orange-300", "data-forge-id": "forge-oe5ypt-1254-26", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1254:26:1256:30", children: market.title }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2", "data-forge-id": "forge-oe7voe-1257-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1257:26:1259:32", children: renderMarketHeadline(market) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm leading-6 text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-oen7d2-1260-26", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1260:26:1260:125", children: market.resolutionLabel }),
                    market.eventDateLabel ? /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-2 text-sm font-medium text-orange-600 dark:text-orange-300", "data-forge-id": "forge-oeohc6-1262-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1262:28:1264:32", children: [
                      "Match date: ",
                      market.eventDateLabel
                    ] }) : null
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", "data-forge-id": "forge-oero9p-1267-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1267:24:1276:30", children: [
                    resolvedOption ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Badge, { className: "border border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-50 dark:border-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-300 dark:hover:bg-emerald-500/10", "data-forge-id": "forge-oesy8v-1269-28", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1269:28:1271:36", children: [
                      "Resolved · ",
                      resolvedOption.label
                    ] }) : null,
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-white text-orange-700 hover:bg-white dark:border-white/10 dark:bg-zinc-950 dark:text-orange-300 dark:hover:bg-zinc-950", "data-forge-id": "forge-of8wx0-1273-26", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1273:26:1275:34", children: marketOptions.length === 3 ? "Three-way market" : "Binary market" })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid gap-3 ${marketOptions.length === 3 ? "lg:grid-cols-3" : "lg:grid-cols-2"}`, "data-forge-id": "forge-ofcqu2-1279-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1279:22:1328:28", children: optionSummaries.map((option) => {
                  const isSelected = chosenSelectionId === option.id;
                  return /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => handleChooseSelection(market.id, option.id), className: `rounded-2xl border px-4 py-4 text-left transition ${getSelectionClasses(option.id, isSelected)}`, "data-forge-id": "forge-ofspif-1283-28", "data-component": "button", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1283:28:1325:37", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-3", "data-forge-id": "forge-ofwjg8-1289-30", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1289:30:1310:36", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { "data-forge-id": "forge-ogal5w-1290-32", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1290:32:1308:38", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", "data-forge-id": "forge-ogb85h-1291-34", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1291:34:1307:40", children: [
                        option.logoSrc ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: option.logoSrc, alt: `${option.label} logo`, className: "size-9 rounded-full border border-white/60 object-cover", "data-forge-id": "forge-ogci4n-1293-38", "data-component": "img", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1293:38:1297:40" }) : null,
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-oggc1r-1299-36", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1299:36:1306:42", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-base font-semibold", "data-forge-id": "forge-ose280-1300-38", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1300:38:1300:95", children: option.label }),
                          option.description ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `mt-1 text-sm ${isSelected ? "text-white/90" : "text-zinc-600 dark:text-zinc-400"}`, "data-forge-id": "forge-osfc7p-1302-40", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1302:40:1304:44", children: option.description }) : null
                        ] })
                      ] }) }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-lg font-semibold", "data-forge-id": "forge-osjt3l-1309-32", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1309:32:1309:97", children: [
                        "x",
                        option.oddsMultiplier
                      ] })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 grid grid-cols-2 gap-3 text-sm", "data-forge-id": "forge-osyhso-1311-30", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1311:30:1324:36", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `rounded-xl border px-3 py-2 ${isSelected ? "border-white/20 bg-white/10" : "border-orange-100 bg-white/80 dark:border-white/10 dark:bg-zinc-950/80"}`, "data-forge-id": "forge-osz4s9-1312-32", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1312:32:1317:38", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-[11px] uppercase tracking-[0.12em] ${isSelected ? "text-white/70" : "text-zinc-500 dark:text-zinc-400"}`, "data-forge-id": "forge-oszrru-1313-34", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1313:34:1315:38", children: "Live volume" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 font-semibold", "data-forge-id": "forge-ot1oqf-1316-34", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1316:34:1316:110", children: formatCurrency(option.liveVolumeUsd) })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `rounded-xl border px-3 py-2 ${isSelected ? "border-white/20 bg-white/10" : "border-orange-100 bg-white/80 dark:border-white/10 dark:bg-zinc-950/80"}`, "data-forge-id": "forge-ot2ypf-1318-32", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1318:32:1323:38", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-[11px] uppercase tracking-[0.12em] ${isSelected ? "text-white/70" : "text-zinc-500 dark:text-zinc-400"}`, "data-forge-id": "forge-ot3lp0-1319-34", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1319:34:1321:38", children: "Net return" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 font-semibold", "data-forge-id": "forge-otixdo-1322-34", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1322:34:1322:109", children: formatCurrency(option.netReturnUsd) })
                      ] })
                    ] })
                  ] }, option.id);
                }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", "data-forge-id": "forge-ou1fz2-1330-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1330:22:1361:28", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", min: predictionMarketMinStakeUsd, max: predictionMarketMaxStakeUsd, step: "0.01", value: amountValue, onChange: (event) => handleAmountChange(market.id, event.target.value), placeholder: `Enter amount from ${predictionMarketMinStakeUsd} to ${predictionMarketMaxStakeUsd}`, className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-ou22yn-1331-24", "data-component": "Input", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1331:24:1340:26" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-oulvk0-1341-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1341:24:1351:30", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-oumijl-1342-26", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1342:26:1344:33", children: [
                      "Reserve fee preview: ",
                      /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-zinc-950 dark:text-white", "data-forge-id": "forge-oun5kx-1343-49", "data-component": "strong", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1343:49:1343:136", children: formatCurrency(reserveFee) })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-ouofi6-1345-26", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1345:26:1347:33", children: [
                      "Total wallet debit: ",
                      /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { className: "text-zinc-950 dark:text-white", "data-forge-id": "forge-oup2jh-1346-48", "data-component": "strong", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1346:48:1346:207", children: totalCharge > 0 ? `${totalCharge.toFixed(2)} ${paymentTokenSymbol}` : `0.00 ${paymentTokenSymbol}` })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { "data-forge-id": "forge-ouqcgr-1348-26", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1348:26:1350:33", children: [
                      "Claim fee on rewards: ",
                      /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { className: "text-zinc-950 dark:text-white", "data-forge-id": "forge-ouqzip-1349-50", "data-component": "strong", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1349:50:1349:135", children: [
                        predictionMarketFeeRate,
                        "%"
                      ] })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", className: "h-11 rounded-2xl bg-orange-500 text-white hover:bg-orange-400", onClick: () => void handleConfirmPosition(market, index), disabled: isSigning, "data-forge-id": "forge-ov6b4w-1352-24", "data-component": "Button", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1352:24:1360:33", children: [
                    isSigning ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-4 animate-spin", "data-forge-id": "forge-ova532-1358-39", "data-component": "LoaderCircle", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1358:39:1358:87" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Signature, { className: "size-4", "data-forge-id": "forge-ova57z-1358-90", "data-component": "Signature", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1358:90:1358:122" }),
                    isWalletConnected ? "Confirm position" : "Connect & confirm"
                  ] })
                ] })
              ] }) }, market.id);
            })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", "data-forge-id": "forge-oeg99m-1370-8", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1370:8:1852:14", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 shadow-sm dark:border-white/10 dark:bg-zinc-950/70 dark:text-white", "data-forge-id": "forge-ow99b4-1371-10", "data-component": "Card", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1371:10:1415:17", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-ow9wap-1372-12", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1372:12:1377:25", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-xl", "data-forge-id": "forge-owajaa-1373-14", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1373:14:1373:82", children: "Prediction wallet summary" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { className: "text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-owb69t-1374-14", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1374:14:1376:32", children: "The product rules stay visible before the user signs anything." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4 text-sm text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-owdq7v-1378-12", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1378:12:1414:26", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-owed7g-1379-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1379:14:1385:20", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-sm font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-owsex4-1380-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1380:16:1383:22", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Wallet, { className: "size-4 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-owt1wp-1381-18", "data-component": "Wallet", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1381:18:1381:84" }),
                "Connected wallet"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 break-all text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-owuyv8-1384-16", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1384:16:1384:126", children: walletAddress != null ? walletAddress : "Waiting for connection" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 sm:grid-cols-2", "data-forge-id": "forge-oww8u8-1386-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1386:14:1413:20", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-owwvtt-1387-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1387:16:1392:22", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-owxite-1388-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1388:18:1388:113", children: "Minimum" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-owy5sx-1389-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1389:18:1391:22", children: formatCurrency(predictionMarketMinStakeUsd) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-oxe4h2-1393-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1393:16:1398:22", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-oxergn-1394-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1394:18:1394:113", children: "Maximum" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-oxfeg6-1395-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1395:18:1397:22", children: formatCurrency(predictionMarketMaxStakeUsd) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-oxhye8-1399-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1399:16:1404:22", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-p9fokh-1400-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1400:18:1400:117", children: "Reserve fee" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-2 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-p9gbk0-1401-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1401:18:1403:22", children: [
                  predictionMarketReserveFeeRate,
                  "%"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-p9ivi2-1405-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1405:16:1408:22", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-p9jihn-1406-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1406:18:1406:115", children: "Claim fee" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-2 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-p9k5h6-1407-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1407:18:1407:120", children: [
                  predictionMarketFeeRate,
                  "%"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-4 dark:border-white/10 dark:bg-black/20 sm:col-span-2", "data-forge-id": "forge-p9lfg6-1409-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1409:16:1412:22", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-p9zh5u-1410-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1410:18:1410:119", children: "Payment token" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-lg font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-pa045d-1411-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1411:18:1411:114", children: paymentTokenSymbol })
              ] })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 shadow-sm dark:border-white/10 dark:bg-white/5 dark:text-white", "data-forge-id": "forge-pa3y2b-1417-10", "data-component": "Card", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1417:10:1443:17", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-pa4l1w-1418-12", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1418:12:1426:25", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(CardTitle, { className: "flex items-center gap-2 text-xl", "data-forge-id": "forge-pa581h-1419-14", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1419:14:1422:26", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(History, { className: "size-5 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-paj9r5-1420-16", "data-component": "History", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1420:16:1420:83" }),
              "History and claims moved to the wallet dashboard"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { className: "text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-pal6po-1423-14", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1423:14:1425:32", children: "Payment history, active predictions, validation state, total win, total loss, and claims are now accessible from the navigation links: My Bets, My Winnings, and Wallet Dashboard." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { "data-forge-id": "forge-panqnq-1427-12", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1427:12:1442:26", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 sm:grid-cols-3", "data-forge-id": "forge-paodnb-1428-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1428:14:1441:20", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-pap0mw-1429-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1429:16:1432:22", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-pb32ck-1430-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1430:18:1430:122", children: "Total positioned" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-2xl font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-pb3pc3-1431-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1431:18:1431:128", children: formatCurrency(totalPositioned) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-pb4zb3-1433-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1433:16:1436:22", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-pb5mao-1434-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1434:18:1434:126", children: "Reserve fees tracked" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-2xl font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-pb69a7-1435-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1435:18:1435:129", children: formatCurrency(totalReserveFees) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-pb7j97-1437-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1437:16:1440:22", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-pb868s-1438-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1438:18:1438:119", children: "Claimable now" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-2xl font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-pb8t8b-1439-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1439:18:1439:127", children: formatCurrency(totalClaimable) })
            ] })
          ] }) })
        ] }),
        ownerWalletConnected ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 shadow-sm dark:border-white/10 dark:bg-white/5 dark:text-white", "data-forge-id": "forge-pbq1x6-1445-34", "data-component": "Card", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1445:34:1827:17", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-pbqoux-1446-12", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1446:12:1451:25", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-xl", "data-forge-id": "forge-pbrbui-1447-14", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1447:14:1447:79", children: "Owner resolution panel" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { className: "text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-pbryu1-1448-14", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1448:14:1450:32", children: "The admin receiver wallet selects the winning side for each prediction. This unlocks claims for approved winners on the platform." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4 text-sm text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-pc7xi6-1452-12", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1452:12:1826:26", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Alert, { className: "border-orange-200 bg-orange-50/70 text-zinc-950 dark:border-white/10 dark:bg-black/20 dark:text-white", "data-forge-id": "forge-pc8khr-1453-14", "data-component": "Alert", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1453:14:1461:22", children: [
              ownerWalletConnected ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "size-4", "data-forge-id": "forge-pc97jr-1454-40", "data-component": "CheckCircle2", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1454:40:1454:75" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "size-4", "data-forge-id": "forge-pc97mk-1454-78", "data-component": "ShieldCheck", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1454:78:1454:112" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(AlertTitle, { "data-forge-id": "forge-pc9ugv-1455-16", "data-component": "AlertTitle", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1455:16:1455:116", children: ownerWalletConnected ? "Admin wallet connected" : "Admin wallet required" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(AlertDescription, { "data-forge-id": "forge-pcahge-1456-16", "data-component": "AlertDescription", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1456:16:1460:35", children: ownerWalletConnected ? "You can resolve the markets shown below and unlock claims for approved winners." : `Connect the admin wallet ${formatWalletAddress(predictionMarketTreasuryAddress)} to resolve market outcomes.` })
            ] }),
            ownerWalletConnected ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-pcsd36-1463-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1463:16:1767:22", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3", "data-forge-id": "forge-pct02r-1464-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1464:18:1479:24", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-pctn2x-1465-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1465:20:1470:26", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-pcua2i-1466-22", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1466:22:1466:105", children: "Admin market extension" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-pcux21-1467-22", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1467:22:1469:26", children: "Use the + button to add a new market inside any prediction section. This action stays available only to the admin wallet." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", className: "h-10 rounded-2xl bg-orange-500 px-4 text-white hover:bg-orange-400", onClick: () => setShowAdminMarketForm((currentValue) => !currentValue), "data-forge-id": "forge-pdavq6-1471-20", "data-component": "Button", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1471:20:1478:29", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "size-4", "data-forge-id": "forge-pde2nv-1476-22", "data-component": "Plus", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1476:22:1476:49" }),
                  showAdminMarketForm ? "Close" : "Add market"
                ] })
              ] }),
              showAdminMarketForm ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 grid gap-4 lg:grid-cols-2", "data-forge-id": "forge-pdvbb2-1482-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1482:20:1765:26", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 rounded-2xl border border-orange-100 bg-white p-4 dark:border-white/10 dark:bg-zinc-950/70", "data-forge-id": "forge-pdvyan-1483-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1483:22:1573:28", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-pdwla8-1484-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1484:24:1489:30", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-pdx89t-1485-26", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1485:26:1485:110", children: "Market basics" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs leading-5 text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-pdxv9c-1486-26", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1486:26:1488:30", children: "Choose the section, set the market title, then add the date and resolution rule users will see." })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-peegx0-1491-24", "data-component": "label", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1491:24:1493:32", children: "Section" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("select", { value: adminMarketDraft.categoryId, onChange: (event) => handleAdminDraftChange("categoryId", event.target.value), className: "flex h-10 w-full rounded-2xl border border-orange-200 bg-white px-3 text-sm text-zinc-950 outline-none transition focus:border-orange-300 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-pegdvl-1494-24", "data-component": "select", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1494:24:1504:33", children: predictionMarketCategories.map((category) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: category.id, "data-forge-id": "forge-pqhazj-1500-28", "data-component": "option", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1500:28:1502:37", children: category.label }, category.id)) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: adminMarketDraft.title, onChange: (event) => handleAdminDraftChange("title", event.target.value), placeholder: "Market title", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-pql4wl-1506-24", "data-component": "Input", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1506:24:1511:26" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: adminMarketDraft.eventDateLabel, onChange: (event) => handleAdminDraftChange("eventDateLabel", event.target.value), placeholder: "Visible event date", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-pr30jd-1513-24", "data-component": "Input", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1513:24:1518:26" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: adminMarketDraft.resolutionLabel, onChange: (event) => handleAdminDraftChange("resolutionLabel", event.target.value), placeholder: "Resolution details", className: "min-h-24 border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-prkw65-1520-24", "data-component": "Textarea", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1520:24:1525:26" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 rounded-2xl border border-orange-100 bg-orange-50/70 p-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-prpd2u-1527-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1527:24:1572:30", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-prq02f-1528-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1528:26:1533:32", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-prqn20-1529-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1529:28:1529:112", children: "Market format" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs leading-5 text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-ps4orm-1530-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1530:28:1532:32", children: "Pick the market structure first, then activate a third outcome only if this event needs three choices." })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-3", "data-forge-id": "forge-ps78po-1534-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1534:26:1571:32", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", variant: adminMarketDraft.mode === "vs" ? "default" : "outline", className: adminMarketDraft.mode === "vs" ? "min-h-14 w-full justify-start rounded-2xl bg-orange-500 px-4 py-3 text-left text-white hover:bg-orange-400" : "min-h-14 w-full justify-start rounded-2xl border-orange-200 bg-white px-4 py-3 text-left text-zinc-950 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900", onClick: () => handleAdminDraftChange("mode", "vs"), "data-forge-id": "forge-ps7vp9-1535-28", "data-component": "Button", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1535:28:1543:37", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-sm font-semibold", "data-forge-id": "forge-psp4d5-1541-30", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1541:30:1541:92", children: "VS market" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mt-1 block text-xs opacity-80", "data-forge-id": "forge-psprco-1542-30", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1542:30:1542:126", children: "Two teams, two logos, head-to-head event." })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", variant: adminMarketDraft.mode === "simple" ? "default" : "outline", className: adminMarketDraft.mode === "simple" ? "min-h-14 w-full justify-start rounded-2xl bg-orange-500 px-4 py-3 text-left text-white hover:bg-orange-400" : "min-h-14 w-full justify-start rounded-2xl border-orange-200 bg-white px-4 py-3 text-left text-zinc-950 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900", onClick: () => handleAdminDraftChange("mode", "simple"), "data-forge-id": "forge-psr1b3-1544-28", "data-component": "Button", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1544:28:1552:37", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-sm font-semibold", "data-forge-id": "forge-pt89yz-1550-30", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1550:30:1550:96", children: "Simple market" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mt-1 block text-xs opacity-80", "data-forge-id": "forge-pt8wyi-1551-30", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1551:30:1551:137", children: "One subject, one circular logo, simple outcome flow." })
                      ] }),
                      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", variant: adminMarketDraft.enableThirdOption ? "default" : "outline", className: adminMarketDraft.enableThirdOption ? "min-h-14 w-full justify-start rounded-2xl bg-orange-500 px-4 py-3 text-left text-white hover:bg-orange-400" : "min-h-14 w-full justify-start rounded-2xl border-orange-200 bg-white px-4 py-3 text-left text-zinc-950 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900", onClick: () => setAdminMarketDraft((currentValue) => ({
                        ...currentValue,
                        enableThirdOption: !currentValue.enableThirdOption,
                        thirdOptionLabel: currentValue.thirdOptionLabel || (currentValue.mode === "vs" ? "X" : "Third option")
                      })), "data-forge-id": "forge-pta6wx-1553-28", "data-component": "Button", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1553:28:1570:37", children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-sm font-semibold", "data-forge-id": "forge-ptvwhi-1566-30", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1566:30:1568:37", children: adminMarketDraft.enableThirdOption ? "3 choices active" : "Enable 3 choices" }),
                        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mt-1 block text-xs opacity-80", "data-forge-id": "forge-ptxtg3-1569-30", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1569:30:1569:136", children: "Add a third outcome like X, draw, or a custom side." })
                      ] })
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 rounded-2xl border border-orange-100 bg-white p-4 dark:border-white/10 dark:bg-zinc-950/70", "data-forge-id": "forge-puf22j-1575-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1575:22:1764:28", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-pufp24-1576-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1576:24:1581:30", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-pugc1p-1577-26", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1577:26:1577:111", children: "Market options" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs leading-5 text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-pugz18-1578-26", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1578:26:1580:30", children: "Add the names, circular images, and odds that will appear on the live market card." })
                  ] }),
                  adminMarketDraft.mode === "vs" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 sm:grid-cols-2", "data-forge-id": "forge-puyuo2-1585-28", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1585:28:1600:34", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: adminMarketDraft.leftCompetitorName, onChange: (event) => handleAdminDraftChange("leftCompetitorName", event.target.value), placeholder: "First team name", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-puzho8-1586-30", "data-component": "Input", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1586:30:1591:32" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "file", accept: "image/*", onChange: (event) => {
                        void handleAdminMarketImageUpload("leftCompetitorImageSrc", event.target.files);
                      }, className: "border-orange-200 bg-white text-zinc-950 file:mr-3 file:rounded-full file:border-0 file:bg-orange-100 file:px-3 file:py-1 file:text-xs file:font-medium file:text-orange-700 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:file:bg-orange-500/15 dark:file:text-orange-300", "data-forge-id": "forge-pvgqbh-1592-30", "data-component": "Input", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1592:30:1599:32" })
                    ] }),
                    adminMarketDraft.leftCompetitorImageSrc ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 rounded-2xl border border-orange-100 bg-white px-3 py-3 dark:border-white/10 dark:bg-zinc-950/80", "data-forge-id": "forge-q7k7df-1602-30", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1602:30:1605:36", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: adminMarketDraft.leftCompetitorImageSrc, alt: "First team preview", className: "size-12 rounded-full object-cover", "data-forge-id": "forge-q7kud0-1603-32", "data-component": "img", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1603:32:1603:156" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-q7lhcj-1604-32", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1604:32:1604:125", children: "First team circular preview" })
                    ] }) : null,
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 sm:grid-cols-2", "data-forge-id": "forge-q7neaf-1607-28", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1607:28:1622:34", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: adminMarketDraft.rightCompetitorName, onChange: (event) => handleAdminDraftChange("rightCompetitorName", event.target.value), placeholder: "Second team name", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-q7o1al-1608-30", "data-component": "Input", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1608:30:1613:32" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "file", accept: "image/*", onChange: (event) => {
                        void handleAdminMarketImageUpload("rightCompetitorImageSrc", event.target.files);
                      }, className: "border-orange-200 bg-white text-zinc-950 file:mr-3 file:rounded-full file:border-0 file:bg-orange-100 file:px-3 file:py-1 file:text-xs file:font-medium file:text-orange-700 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:file:bg-orange-500/15 dark:file:text-orange-300", "data-forge-id": "forge-q859xu-1614-30", "data-component": "Input", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1614:30:1621:32" })
                    ] }),
                    adminMarketDraft.rightCompetitorImageSrc ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 rounded-2xl border border-orange-100 bg-white px-3 py-3 dark:border-white/10 dark:bg-zinc-950/80", "data-forge-id": "forge-q8p2j7-1624-30", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1624:30:1627:36", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: adminMarketDraft.rightCompetitorImageSrc, alt: "Second team preview", className: "size-12 rounded-full object-cover", "data-forge-id": "forge-q8ppis-1625-32", "data-component": "img", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1625:32:1625:158" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-q8qcib-1626-32", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1626:32:1626:126", children: "Second team circular preview" })
                    ] }) : null,
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 sm:grid-cols-2", "data-forge-id": "forge-q8s9g7-1629-28", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1629:28:1648:34", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", min: "1.01", step: "0.01", value: adminMarketDraft.firstOdds, onChange: (event) => handleAdminDraftChange("firstOdds", event.target.value), placeholder: "First team odds", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-q96b6g-1630-30", "data-component": "Input", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1630:30:1638:32" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", min: "1.01", step: "0.01", value: adminMarketDraft.secondOdds, onChange: (event) => handleAdminDraftChange("secondOdds", event.target.value), placeholder: "Second team odds", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-q9c227-1639-30", "data-component": "Input", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1639:30:1647:32" })
                    ] })
                  ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 sm:grid-cols-2", "data-forge-id": "forge-qab6bl-1652-28", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1652:28:1667:34", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: adminMarketDraft.singleName, onChange: (event) => handleAdminDraftChange("singleName", event.target.value), placeholder: "Single market name", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-qabtbr-1653-30", "data-component": "Input", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1653:30:1658:32" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "file", accept: "image/*", onChange: (event) => {
                        void handleAdminMarketImageUpload("singleImageSrc", event.target.files);
                      }, className: "border-orange-200 bg-white text-zinc-950 file:mr-3 file:rounded-full file:border-0 file:bg-orange-100 file:px-3 file:py-1 file:text-xs file:font-medium file:text-orange-700 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:file:bg-orange-500/15 dark:file:text-orange-300", "data-forge-id": "forge-qafn8x-1659-30", "data-component": "Input", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1659:30:1666:32" })
                    ] }),
                    adminMarketDraft.singleImageSrc ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 rounded-2xl border border-orange-100 bg-white px-3 py-3 dark:border-white/10 dark:bg-zinc-950/80", "data-forge-id": "forge-qazfua-1669-30", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1669:30:1672:36", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: adminMarketDraft.singleImageSrc, alt: "Single market preview", className: "size-12 rounded-full object-cover", "data-forge-id": "forge-qbdhjy-1670-32", "data-component": "img", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1670:32:1670:151" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-qbe4jh-1671-32", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1671:32:1671:126", children: "Single logo circular preview" })
                    ] }) : null,
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 sm:grid-cols-2", "data-forge-id": "forge-qbg1hd-1674-28", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1674:28:1693:34", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", min: "1.01", step: "0.01", value: adminMarketDraft.firstOdds, onChange: (event) => handleAdminDraftChange("firstOdds", event.target.value), placeholder: "Yes odds", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-qbgohj-1675-30", "data-component": "Input", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1675:30:1683:32" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", min: "1.01", step: "0.01", value: adminMarketDraft.secondOdds, onChange: (event) => handleAdminDraftChange("secondOdds", event.target.value), placeholder: "No odds", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-qbzu3d-1684-30", "data-component": "Input", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1684:30:1692:32" })
                    ] })
                  ] }),
                  adminMarketDraft.enableThirdOption ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 rounded-2xl border border-orange-100 bg-orange-50/80 p-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-qcm6m5-1698-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1698:26:1733:32", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-medium uppercase tracking-[0.14em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-qcmtlq-1699-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1699:28:1701:32", children: "Third option details" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 sm:grid-cols-2", "data-forge-id": "forge-qoltqz-1702-28", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1702:28:1718:34", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: adminMarketDraft.thirdOptionLabel, onChange: (event) => handleAdminDraftChange("thirdOptionLabel", event.target.value), placeholder: adminMarketDraft.mode === "vs" ? "Draw label, for example X" : "Third choice label", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-qomgr5-1703-30", "data-component": "Input", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1703:30:1708:32" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", min: "1.01", step: "0.01", value: adminMarketDraft.thirdOptionOdds, onChange: (event) => handleAdminDraftChange("thirdOptionOdds", event.target.value), placeholder: "Third option odds", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-qoqaob-1709-30", "data-component": "Input", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1709:30:1717:32" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "file", accept: "image/*", onChange: (event) => {
                      void handleAdminMarketImageUpload("thirdOptionImageSrc", event.target.files);
                    }, className: "border-orange-200 bg-white text-zinc-950 file:mr-3 file:rounded-full file:border-0 file:bg-orange-100 file:px-3 file:py-1 file:text-xs file:font-medium file:text-orange-700 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:file:bg-orange-500/15 dark:file:text-orange-300", "data-forge-id": "forge-qpa391-1719-28", "data-component": "Input", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1719:28:1726:30" }),
                    adminMarketDraft.thirdOptionImageSrc ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 rounded-2xl border border-orange-100 bg-white px-3 py-3 dark:border-white/10 dark:bg-zinc-950/80", "data-forge-id": "forge-qpt8vi-1728-30", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1728:30:1731:36", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: adminMarketDraft.thirdOptionImageSrc, alt: "Third option preview", className: "size-12 rounded-full object-cover", "data-forge-id": "forge-qptvv3-1729-32", "data-component": "img", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1729:32:1729:155" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-qq7xkp-1730-32", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1730:32:1730:127", children: "Third option circular preview" })
                    ] }) : null
                  ] }) : null,
                  /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { value: adminMarketDraft.extraNotes, onChange: (event) => handleAdminDraftChange("extraNotes", event.target.value), placeholder: "Optional option notes shown inside the market", className: "min-h-24 border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-qqbrh2-1736-24", "data-component": "Textarea", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1736:24:1741:26" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-3 pt-1", "data-forge-id": "forge-qqtn3u-1743-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1743:24:1763:30", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", className: "h-11 rounded-2xl bg-orange-500 px-4 text-white hover:bg-orange-400", onClick: () => void handleCreateAdminMarket(), "data-forge-id": "forge-qqua3f-1744-26", "data-component": "Button", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1744:26:1751:35", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "size-4", "data-forge-id": "forge-qqxh14-1749-28", "data-component": "Plus", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1749:28:1749:55" }),
                      "Publish market"
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", className: "h-11 rounded-2xl border-orange-200 bg-white px-4 text-zinc-950 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900", onClick: () => {
                      setAdminMarketDraft(createInitialAdminMarketDraft());
                      setShowAdminMarketForm(false);
                    }, "data-forge-id": "forge-qrcspq-1752-26", "data-component": "Button", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1752:26:1762:35", children: "Cancel" })
                  ] })
                ] })
              ] }) : null
            ] }) : null,
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", "data-forge-id": "forge-qs126v-1769-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1769:14:1825:20", children: visibleQuestions.map((market, index) => {
              const resolution = resolutions[market.id];
              const marketOptions = getMarketOptions(market, index);
              const resolvedOption = resolution ? marketOptions.find((option) => option.id === resolution.outcomeId) : void 0;
              return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 px-4 py-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-qsk7tg-1778-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1778:20:1822:26", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-3", "data-forge-id": "forge-qt06hp-1782-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1782:22:1821:28", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-qt0tha-1783-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1783:24:1788:30", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-qt1ggv-1784-26", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1784:26:1784:101", children: market.title }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-500", "data-forge-id": "forge-qt23ge-1785-26", "data-component": "p", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1785:26:1787:30", children: resolvedOption ? `Resolved ${resolvedOption.label} · ${formatMoment(resolution.resolvedAt)}` : "Awaiting admin decision" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2", "data-forge-id": "forge-qt4neg-1789-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1789:24:1820:30", children: [
                  "createdByWallet" in market ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", size: "sm", variant: "outline", className: "rounded-full border-red-200 bg-white text-red-600 hover:bg-red-50 dark:border-red-500/30 dark:bg-zinc-950 dark:text-red-300 dark:hover:bg-red-500/10", disabled: !ownerWalletConnected, onClick: () => void handleDeleteMarket(market), "data-forge-id": "forge-qtjc3p-1791-28", "data-component": "Button", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1791:28:1801:37", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "size-3.5", "data-forge-id": "forge-qtog0k-1799-30", "data-component": "Trash2", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1799:30:1799:61" }),
                    "Delete"
                  ] }) : null,
                  marketOptions.map((option) => /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", size: "sm", variant: (resolution == null ? void 0 : resolution.outcomeId) === option.id ? "default" : "outline", className: (resolution == null ? void 0 : resolution.outcomeId) === option.id ? "rounded-full bg-orange-500 text-white hover:bg-orange-400" : "rounded-full border-orange-200 bg-white text-zinc-950 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900", disabled: !ownerWalletConnected, onClick: () => void handleResolveMarket(market, option.id), "data-forge-id": "forge-r5oq48-1804-28", "data-component": "Button", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1804:28:1818:37", children: option.label }, option.id))
                ] })
              ] }) }, market.id);
            }) })
          ] })
        ] }) : null,
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 shadow-sm dark:border-white/10 dark:bg-white/5 dark:text-white", "data-forge-id": "forge-r6vi7i-1829-10", "data-component": "Card", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1829:10:1850:17", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-r79jx6-1830-12", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1830:12:1835:25", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-xl", "data-forge-id": "forge-r7a6wr-1831-14", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1831:14:1831:73", children: "Product coverage" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { className: "text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-r7atwa-1832-14", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1832:14:1834:32", children: "The current studio already shows the core market logic and the next build steps." })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-3 text-sm text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-r7dduc-1836-12", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1836:12:1849:26", children: [
            contractCapabilities.map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3 rounded-2xl border border-orange-100 bg-orange-50 px-4 py-3 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-r7enti-1838-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1838:16:1841:22", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "mt-0.5 size-4 shrink-0 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-r7fat3-1839-18", "data-component": "CheckCircle2", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1839:18:1839:106" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "data-forge-id": "forge-r7tcip-1840-18", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1840:18:1840:37", children: item })
            ] }, item)),
            roadmapItems.map((item) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3 rounded-2xl border border-orange-100 bg-white px-4 py-3 dark:border-white/10 dark:bg-zinc-950", "data-forge-id": "forge-r7vwgr-1844-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1844:16:1847:22", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { className: "mt-0.5 size-4 shrink-0 text-orange-500 dark:text-orange-300", "data-forge-id": "forge-r7wjgc-1845-18", "data-component": "TrendingUp", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1845:18:1845:104" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "data-forge-id": "forge-r7x6fv-1846-18", "data-component": "span", "data-source-pos": "src/components/octopus-market/binary-prediction-studio.tsx:1846:18:1846:37", children: item })
            ] }, item))
          ] })
        ] })
      ] })
    ] })
  ] });
}
export {
  BinaryPredictionStudio
};
