import { c as createLucideIcon, j as jsxRuntimeExports, aw as cn, a_ as cva } from "./index-C-7_nSR2.js";
const __iconNode = [["path", { d: "M21 12a9 9 0 1 1-6.219-8.56", key: "13zald" }]];
const LoaderCircle = createLucideIcon("loader-circle", __iconNode);
const alertVariants = cva("relative w-full rounded-lg border px-4 py-3 text-sm grid has-[>svg]:grid-cols-[calc(var(--spacing)*4)_1fr] grid-cols-[0_1fr] has-[>svg]:gap-x-3 gap-y-0.5 items-start [&>svg]:size-4 [&>svg]:translate-y-0.5 [&>svg]:text-current", {
  variants: {
    variant: {
      default: "bg-card text-card-foreground",
      destructive: "text-destructive bg-card [&>svg]:text-current *:data-[slot=alert-description]:text-destructive/90"
    }
  },
  defaultVariants: {
    variant: "default"
  }
});
function Alert({
  className,
  variant,
  ...props
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { "data-slot": "alert", role: "alert", className: cn(alertVariants({
    variant
  }), className), "data-forge-id": "forge-oq8tn1-28-4", "data-component": "div", "data-source-pos": "src/components/ui/alert.tsx:28:4:33:6", ...props });
}
function AlertTitle({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { "data-slot": "alert-title", className: cn("col-start-2 line-clamp-1 min-h-4 font-medium tracking-tight", className), "data-forge-id": "forge-oq85wt-39-4", "data-component": "div", "data-source-pos": "src/components/ui/alert.tsx:39:4:46:6", ...props });
}
function AlertDescription({
  className,
  ...props
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { "data-slot": "alert-description", className: cn("text-muted-foreground col-start-2 grid justify-items-start gap-1 text-sm [&_p]:leading-relaxed", className), "data-forge-id": "forge-oq6ywj-55-4", "data-component": "div", "data-source-pos": "src/components/ui/alert.tsx:55:4:62:6", ...props });
}
export {
  Alert as A,
  LoaderCircle as L,
  AlertTitle as a,
  AlertDescription as b
};
