import { r as reactExports, s as subscribeToCentralRegistry, j as jsxRuntimeExports, B as Badge, C as Card, a as CardHeader, z as CardDescription, b as CardTitle, e as CardContent, D as formatWalletAddress, p as predictionMarketTreasuryAddress, h as readCentralWalletRecords, i as readCentralPaymentRecords, a$ as getAllPredictionHistoryAdmin, b0 as readCentralAdminLogs } from "./index-C-7_nSR2.js";
function formatMoment(value) {
  if (!value) {
    return "—";
  }
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(value));
}
function formatAmount(value) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(value != null ? value : 0);
}
async function loadDatabaseSnapshot() {
  const [wallets, payments, history, adminLogs] = await Promise.all([readCentralWalletRecords(), readCentralPaymentRecords(), getAllPredictionHistoryAdmin(), readCentralAdminLogs()]);
  return {
    wallets,
    payments,
    history,
    adminLogs
  };
}
function AdminDatabasePanel({
  walletAddress
}) {
  const [snapshot, setSnapshot] = reactExports.useState({
    wallets: [],
    payments: [],
    history: [],
    adminLogs: []
  });
  const [isLoading, setIsLoading] = reactExports.useState(true);
  const isAdminWallet = walletAddress === predictionMarketTreasuryAddress;
  reactExports.useEffect(() => {
    if (!isAdminWallet) {
      setSnapshot({
        wallets: [],
        payments: [],
        history: [],
        adminLogs: []
      });
      setIsLoading(false);
      return;
    }
    const hydrate = async () => {
      const nextSnapshot = await loadDatabaseSnapshot();
      {
        setSnapshot(nextSnapshot);
        setIsLoading(false);
      }
    };
    setIsLoading(true);
    void hydrate();
    return subscribeToCentralRegistry(() => {
      void hydrate();
    });
  }, [isAdminWallet]);
  const totals = reactExports.useMemo(() => {
    const approvedVolume = snapshot.payments.filter((payment) => payment.status === "approved").reduce((total, payment) => total + payment.totalPaidUsdc, 0);
    return {
      wallets: snapshot.wallets.length,
      payments: snapshot.payments.length,
      history: snapshot.history.length,
      adminLogs: snapshot.adminLogs.length,
      approvedVolume
    };
  }, [snapshot]);
  if (!isAdminWallet) {
    return null;
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "space-y-6", "data-forge-id": "forge-jfb191-121-4", "data-component": "section", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:121:4:388:14", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3", "data-forge-id": "forge-jfb1zs-122-6", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:122:6:136:12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-jfb2qj-123-8", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:123:8:131:14", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-orange-100 text-orange-700 hover:bg-orange-100 dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-xxnjwb-124-10", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:124:10:126:18", children: "Shared registry" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-3 text-2xl font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-xxpguw-127-10", "data-component": "h2", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:127:10:127:106", children: "Platform database" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-zinc-600 dark:text-zinc-400", "data-forge-id": "forge-xxq3uf-128-10", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:128:10:130:14", children: "Read the shared Octopus Market data store for wallets, payments, user history, and admin actions." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-200 bg-white px-4 py-3 text-right dark:border-white/10 dark:bg-zinc-900", "data-forge-id": "forge-jfbozd-132-8", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:132:8:135:14", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.18em] text-orange-600 dark:text-orange-300", "data-forge-id": "forge-xy6pi5-133-10", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:133:10:133:114", children: "Admin wallet" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-xy7cho-134-10", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:134:10:134:99", children: walletAddress })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-5", "data-forge-id": "forge-jfbtfh-138-6", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:138:6:169:12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "border-orange-200 bg-white dark:border-white/10 dark:bg-zinc-900/80", "data-forge-id": "forge-jfbu68-139-8", "data-component": "Card", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:139:8:144:15", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { className: "pb-3", "data-forge-id": "forge-xyol4x-140-10", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:140:10:143:23", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { "data-forge-id": "forge-xyp84i-141-12", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:141:12:141:60", children: "Total wallets" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-2xl", "data-forge-id": "forge-xypv41-142-12", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:142:12:142:72", children: totals.wallets })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "border-orange-200 bg-white dark:border-white/10 dark:bg-zinc-900/80", "data-forge-id": "forge-jfce6z-145-8", "data-component": "Card", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:145:8:150:15", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { className: "pb-3", "data-forge-id": "forge-xysf23-146-10", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:146:10:149:23", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { "data-forge-id": "forge-xyt21o-147-12", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:147:12:147:61", children: "Total payments" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-2xl", "data-forge-id": "forge-xytp17-148-12", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:148:12:148:73", children: totals.payments })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "border-orange-200 bg-white dark:border-white/10 dark:bg-zinc-900/80", "data-forge-id": "forge-jfcy7q-151-8", "data-component": "Card", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:151:8:156:15", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { className: "pb-3", "data-forge-id": "forge-xz9npc-152-10", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:152:10:155:23", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { "data-forge-id": "forge-xzaaox-153-12", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:153:12:153:65", children: "Total history rows" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-2xl", "data-forge-id": "forge-xzaxog-154-12", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:154:12:154:72", children: totals.history })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "border-orange-200 bg-white dark:border-white/10 dark:bg-zinc-900/80", "data-forge-id": "forge-jfd2nw-157-8", "data-component": "Card", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:157:8:162:15", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { className: "pb-3", "data-forge-id": "forge-xzdhmi-158-10", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:158:10:161:23", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { "data-forge-id": "forge-xze4m3-159-12", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:159:12:159:57", children: "Admin logs" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-2xl", "data-forge-id": "forge-xzs6bp-160-12", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:160:12:160:74", children: totals.adminLogs })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "border-orange-200 bg-white dark:border-white/10 dark:bg-zinc-900/80", "data-forge-id": "forge-jfdmon-163-8", "data-component": "Card", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:163:8:168:15", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { className: "pb-3", "data-forge-id": "forge-xzuq9r-164-10", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:164:10:167:23", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { "data-forge-id": "forge-xzvd9c-165-12", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:165:12:165:62", children: "Approved volume" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-2xl", "data-forge-id": "forge-xzw08v-166-12", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:166:12:166:93", children: formatAmount(totals.approvedVolume) })
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-6 xl:grid-cols-2", "data-forge-id": "forge-jfe86q-171-6", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:171:6:253:12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white dark:border-white/10 dark:bg-zinc-900/80", "data-forge-id": "forge-jfe8xh-172-8", "data-component": "Card", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:172:8:211:15", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-y0dvvl-173-10", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:173:10:176:23", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-xl", "data-forge-id": "forge-y0eiv6-174-12", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:174:12:174:69", children: "Wallet records" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { "data-forge-id": "forge-y0f5up-175-12", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:175:12:175:97", children: "All tracked wallets stored in the shared registry." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { "data-forge-id": "forge-y0gftp-177-10", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:177:10:210:24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-[22rem] overflow-y-auto rounded-2xl border border-orange-100 dark:border-white/10", "data-forge-id": "forge-y0h2ta-178-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:178:12:209:18", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-sm", "data-forge-id": "forge-y0hpsv-179-14", "data-component": "table", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:179:14:208:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "sticky top-0 bg-orange-50 dark:bg-zinc-950", "data-forge-id": "forge-y0vrij-180-16", "data-component": "thead", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:180:16:187:24", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "text-left text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-y0wei4-181-18", "data-component": "tr", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:181:18:186:23", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-y0x1ia-182-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:182:20:182:69", children: "Wallet" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-y0xoht-183-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:183:20:183:67", children: "Role" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-y0ybhc-184-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:184:20:184:69", children: "Status" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-y0yygv-185-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:185:20:185:78", children: "Latest activity" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { "data-forge-id": "forge-y10ver-188-16", "data-component": "tbody", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:188:16:207:24", children: [
            snapshot.wallets.map((wallet) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-t border-orange-100 dark:border-white/10", "data-forge-id": "forge-y1fk4l-190-20", "data-component": "tr", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:190:20:198:25", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "px-4 py-3 align-top text-zinc-950 dark:text-white", "data-forge-id": "forge-y1g746-191-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:191:22:194:27", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-medium", "data-forge-id": "forge-y1gu3r-192-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:192:24:192:137", children: wallet.displayName || wallet.username || formatWalletAddress(wallet.address) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-y1hh3a-193-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:193:24:193:109", children: wallet.address })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top capitalize text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-y1ir2a-195-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:195:22:195:120", children: wallet.role }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top capitalize text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-y1je1t-196-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:196:22:196:122", children: wallet.status }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-y1k11c-197-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:197:22:197:135", children: formatMoment(wallet.latestActivityAt) })
            ] }, wallet.address)),
            !snapshot.wallets.length ? /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { "data-forge-id": "forge-ydjo62-201-20", "data-component": "tr", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:201:20:205:25", children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 4, className: "px-4 py-6 text-center text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-ydkb5n-202-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:202:22:204:27", children: isLoading ? "Loading wallets..." : "No wallet records yet." }) }) : null
          ] })
        ] }) }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white dark:border-white/10 dark:bg-zinc-900/80", "data-forge-id": "forge-jfu8cd-213-8", "data-component": "Card", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:213:8:252:15", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-ye5dp5-214-10", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:214:10:217:23", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-xl", "data-forge-id": "forge-ye60oq-215-12", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:215:12:215:70", children: "Payment records" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { "data-forge-id": "forge-ye6no9-216-12", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:216:12:216:97", children: "Latest shared payment rows available to the admin." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { "data-forge-id": "forge-ye7xn9-218-10", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:218:10:251:24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-[22rem] overflow-y-auto rounded-2xl border border-orange-100 dark:border-white/10", "data-forge-id": "forge-ye8kmu-219-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:219:12:250:18", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-sm", "data-forge-id": "forge-yemmci-220-14", "data-component": "table", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:220:14:249:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "sticky top-0 bg-orange-50 dark:bg-zinc-950", "data-forge-id": "forge-yen9c3-221-16", "data-component": "thead", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:221:16:228:24", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "text-left text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-yenwbo-222-18", "data-component": "tr", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:222:18:227:23", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-yeojbu-223-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:223:20:223:67", children: "User" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-yep6bd-224-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:224:20:224:67", children: "Flow" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-yeptaw-225-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:225:20:225:69", children: "Amount" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-yeqgaf-226-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:226:20:226:69", children: "Status" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { "data-forge-id": "forge-yesd8b-229-16", "data-component": "tbody", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:229:16:248:24", children: [
            snapshot.payments.map((payment) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-t border-orange-100 dark:border-white/10", "data-forge-id": "forge-yf71y5-231-20", "data-component": "tr", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:231:20:239:25", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "px-4 py-3 align-top text-zinc-950 dark:text-white", "data-forge-id": "forge-yf7oxq-232-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:232:22:235:27", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-medium", "data-forge-id": "forge-yf8bxb-233-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:233:24:233:120", children: payment.username || formatWalletAddress(payment.userWallet) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-yf8ywu-234-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:234:24:234:126", children: formatMoment(payment.createdAt) })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top capitalize text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-yfa8vu-236-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:236:22:236:121", children: payment.flow }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-yfavvd-237-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:237:22:237:133", children: formatAmount(payment.totalPaidUsdc) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top capitalize text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-yfbiuw-238-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:238:22:238:123", children: payment.status })
            ] }, payment.id)),
            !snapshot.payments.length ? /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { "data-forge-id": "forge-yfrhj1-242-20", "data-component": "tr", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:242:20:246:25", children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 4, className: "px-4 py-6 text-center text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-yfs4im-243-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:243:22:245:27", children: isLoading ? "Loading payments..." : "No payment records yet." }) }) : null
          ] })
        ] }) }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-6 xl:grid-cols-[1.35fr_0.65fr]", "data-forge-id": "forge-jfwtrt-255-6", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:255:6:387:12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white dark:border-white/10 dark:bg-zinc-900/80 xl:col-span-2", "data-forge-id": "forge-jfwuik-256-8", "data-component": "Card", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:256:8:320:15", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-ygeh16-257-10", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:257:10:262:23", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-xl", "data-forge-id": "forge-ygf40r-258-12", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:258:12:258:70", children: "User bets table" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { "data-forge-id": "forge-ygfr0a-259-12", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:259:12:261:30", children: "Every bet stored in the shared database, with the exact market, chosen side, wallet, amount, total charged, and payment reference." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { "data-forge-id": "forge-ygvpof-263-10", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:263:10:319:24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-[24rem] overflow-y-auto rounded-2xl border border-orange-100 dark:border-white/10", "data-forge-id": "forge-ygwco0-264-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:264:12:318:18", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-sm", "data-forge-id": "forge-ygwznl-265-14", "data-component": "table", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:265:14:317:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "sticky top-0 bg-orange-50 dark:bg-zinc-950", "data-forge-id": "forge-ygxmn6-266-16", "data-component": "thead", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:266:16:280:24", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "text-left text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-ygy9mr-267-18", "data-component": "tr", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:267:18:279:23", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-ygywmx-268-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:268:20:268:67", children: "User" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-ygzjmg-269-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:269:20:269:69", children: "Wallet" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-yhdlc2-270-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:270:20:270:69", children: "Market" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-yhe8bl-271-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:271:20:271:70", children: "Section" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-yhevb4-272-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:272:20:272:69", children: "Choice" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-yhfian-273-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:273:20:273:66", children: "Bet" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-yhg5a6-274-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:274:20:274:73", children: "Total paid" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-yhgs9p-275-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:275:20:275:68", children: "Admin" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-yhhf98-276-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:276:20:276:69", children: "Result" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-yhi28r-277-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:277:20:277:72", children: "Reference" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-yhip8a-278-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:278:20:278:72", children: "Placed at" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { "data-forge-id": "forge-yhy0w9-281-16", "data-component": "tbody", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:281:16:316:24", children: [
            snapshot.history.map((bet) => {
              var _a, _b;
              const ownerRecord = snapshot.wallets.find((w) => w.address === bet.wallet_address);
              return /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-t border-orange-100 dark:border-white/10", "data-forge-id": "forge-yi0kv4-285-22", "data-component": "tr", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:285:22:306:27", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "px-4 py-3 align-top text-zinc-950 dark:text-white", "data-forge-id": "forge-yi17up-286-24", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:286:24:289:29", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-medium", "data-forge-id": "forge-yi1uua-287-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:287:26:287:155", children: (ownerRecord == null ? void 0 : ownerRecord.displayName) || (ownerRecord == null ? void 0 : ownerRecord.username) || formatWalletAddress(bet.wallet_address) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-yi2htt-288-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:288:26:288:147", children: (ownerRecord == null ? void 0 : ownerRecord.twitterHandle) || "No X profile saved" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top text-xs text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-yih6iw-290-24", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:290:24:292:29", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "break-all", "data-forge-id": "forge-yihtih-291-26", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:291:26:291:81", children: bet.wallet_address }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-yij3hh-293-24", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:293:24:293:116", children: bet.market_title }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-yijqh0-294-24", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:294:24:294:118", children: bet.category_label }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top text-zinc-950 dark:text-white", "data-forge-id": "forge-yikdgj-295-24", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:295:24:295:116", children: bet.selection_label }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-yil0g2-296-24", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:296:24:296:132", children: formatAmount(Number(bet.amount)) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-yilnfl-297-24", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:297:24:297:139", children: formatAmount(Number(bet.total_charged)) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top capitalize text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-yimaf4-298-24", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:298:24:298:149", children: (_a = bet.admin_decision_status) != null ? _a : "pending" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-yimxen-299-24", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:299:24:301:29", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-medium text-zinc-950 dark:text-white", "data-forge-id": "forge-yuknkw-300-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:300:26:300:120", children: (_b = bet.result_status) != null ? _b : "open" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top text-xs text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-yulxjw-302-24", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:302:24:304:29", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "break-all", "data-forge-id": "forge-yumkjh-303-26", "data-component": "span", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:303:26:303:84", children: bet.payment_reference }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-yunuih-305-24", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:305:24:305:148", children: formatMoment(new Date(bet.created_at).getTime()) })
              ] }, bet.id);
            }),
            !snapshot.history.length ? /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { "data-forge-id": "forge-yv4g63-310-20", "data-component": "tr", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:310:20:314:25", children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 11, className: "px-4 py-6 text-center text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-yv535o-311-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:311:22:313:27", children: isLoading ? "Loading bets..." : "No user bets stored yet." }) }) : null
          ] })
        ] }) }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white dark:border-white/10 dark:bg-zinc-900/80", "data-forge-id": "forge-jgen6k-322-8", "data-component": "Card", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:322:8:360:15", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-yvq5p6-323-10", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:323:10:326:23", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-xl", "data-forge-id": "forge-yvqsor-324-12", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:324:12:324:73", children: "Prediction history" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { "data-forge-id": "forge-yvrfoa-325-12", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:325:12:325:98", children: "Latest history rows synced from the live user flow." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { "data-forge-id": "forge-yvspna-327-10", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:327:10:359:24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-[20rem] overflow-y-auto rounded-2xl border border-orange-100 dark:border-white/10", "data-forge-id": "forge-yvtcmv-328-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:328:12:358:18", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-sm", "data-forge-id": "forge-yvtzmg-329-14", "data-component": "table", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:329:14:357:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "sticky top-0 bg-orange-50 dark:bg-zinc-950", "data-forge-id": "forge-yw81c4-330-16", "data-component": "thead", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:330:16:338:24", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "text-left text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-yw8obp-331-18", "data-component": "tr", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:331:18:337:23", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-yw9bbv-332-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:332:20:332:67", children: "User" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-yw9ybe-333-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:333:20:333:69", children: "Market" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-ywalax-334-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:334:20:334:73", children: "Net reward" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-ywb8ag-335-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:335:20:335:69", children: "Result" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-4 py-3 font-medium", "data-forge-id": "forge-ywbv9z-336-20", "data-component": "th", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:336:20:336:71", children: "Reported" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { "data-forge-id": "forge-ywds7v-339-16", "data-component": "tbody", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:339:16:356:24", children: [
            snapshot.history.map((entry) => {
              var _a, _b;
              return /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-t border-orange-100 dark:border-white/10", "data-forge-id": "forge-ywsgxp-341-20", "data-component": "tr", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:341:20:347:25", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top text-zinc-950 dark:text-white", "data-forge-id": "forge-ywt3xa-342-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:342:22:342:136", children: formatWalletAddress(entry.wallet_address) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-ywtqwt-343-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:343:22:343:116", children: entry.market_title }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-ywudwc-344-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:344:22:344:136", children: formatAmount(Number(entry.net_reward)) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-ywv0vv-345-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:345:22:345:127", children: (_a = entry.result_status) != null ? _a : "open" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-4 py-3 align-top text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-ywvnve-346-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:346:22:346:169", children: formatMoment(new Date((_b = entry.reported_at) != null ? _b : entry.created_at).getTime()) })
              ] }, entry.id);
            }),
            !snapshot.history.length ? /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { "data-forge-id": "forge-yxbmjj-350-20", "data-component": "tr", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:350:20:354:25", children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 5, className: "px-4 py-6 text-center text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-yxc9j4-351-22", "data-component": "td", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:351:22:353:27", children: isLoading ? "Loading history..." : "No prediction history yet." }) }) : null
          ] })
        ] }) }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white dark:border-white/10 dark:bg-zinc-900/80", "data-forge-id": "forge-jgh74o-362-8", "data-component": "Card", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:362:8:386:15", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-yxxc2m-363-10", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:363:10:366:23", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-xl", "data-forge-id": "forge-yxxz27-364-12", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:364:12:364:65", children: "Admin logs" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { "data-forge-id": "forge-yxym1q-365-12", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:365:12:365:99", children: "Tracked admin actions stored in the shared registry." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { "data-forge-id": "forge-yxzw0q-367-10", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:367:10:385:24", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", "data-forge-id": "forge-yy0j0b-368-12", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:368:12:384:18", children: [
          snapshot.adminLogs.map((log) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50/70 px-4 py-3 dark:border-white/10 dark:bg-zinc-950/70", "data-forge-id": "forge-yyf7pk-370-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:370:16:377:22", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3", "data-forge-id": "forge-yyfup5-371-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:371:18:374:24", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium capitalize text-zinc-950 dark:text-white", "data-forge-id": "forge-yyghpb-372-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:372:20:372:125", children: log.action.replaceAll("_", " ") }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-yyh4ou-373-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:373:20:373:109", children: formatMoment(log.createdAt) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-zinc-600 dark:text-zinc-300", "data-forge-id": "forge-yyien9-375-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:375:18:375:96", children: log.details }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-yyj1ms-376-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:376:18:376:105", children: [
              "Target: ",
              log.targetId
            ] })
          ] }, log.id)),
          !snapshot.adminLogs.length ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-dashed border-orange-200 px-4 py-6 text-center text-zinc-500 dark:border-white/10 dark:text-zinc-400", "data-forge-id": "forge-yyz0ax-380-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/admin-database-panel.tsx:380:16:382:22", children: isLoading ? "Loading admin logs..." : "No admin logs yet." }) : null
        ] }) })
      ] })
    ] })
  ] });
}
export {
  AdminDatabasePanel
};
