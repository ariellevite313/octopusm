import { c as createLucideIcon, $ as supabase, r as reactExports, j as jsxRuntimeExports, d as Button, I as Input } from "./index-C-7_nSR2.js";
const __iconNode$5 = [
  [
    "path",
    {
      d: "M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z",
      key: "96xj49"
    }
  ]
];
const Flame = createLucideIcon("flame", __iconNode$5);
const __iconNode$4 = [
  [
    "path",
    {
      d: "M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",
      key: "mvr1a0"
    }
  ]
];
const Heart = createLucideIcon("heart", __iconNode$4);
const __iconNode$3 = [
  [
    "path",
    {
      d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
      key: "18887p"
    }
  ]
];
const MessageSquare = createLucideIcon("message-square", __iconNode$3);
const __iconNode$2 = [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ],
  ["path", { d: "M12 8v4", key: "1got3b" }],
  ["path", { d: "M12 16h.01", key: "1drbdi" }]
];
const ShieldAlert = createLucideIcon("shield-alert", __iconNode$2);
const __iconNode$1 = [
  [
    "path",
    {
      d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
      key: "r04s7s"
    }
  ]
];
const Star = createLucideIcon("star", __iconNode$1);
const __iconNode = [
  ["path", { d: "M7 10v12", key: "1qc93n" }],
  [
    "path",
    {
      d: "M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2a3.13 3.13 0 0 1 3 3.88Z",
      key: "emmmcr"
    }
  ]
];
const ThumbsUp = createLucideIcon("thumbs-up", __iconNode);
async function getOrCreateToolSocial(toolName) {
  const { data: existing } = await supabase.from("ai_tool_social").select("*").eq("tool_name", toolName).maybeSingle();
  if (existing) return existing;
  const { data: created, error } = await supabase.from("ai_tool_social").insert({ tool_name: toolName }).select().single();
  if (error) {
    console.error("[social-service] getOrCreateToolSocial:", error.message);
    return null;
  }
  return created;
}
async function rateTooling(toolName, actorKey, rating) {
  if (rating < 1 || rating > 5) {
    return { success: false, error: "La note doit être entre 1 et 5." };
  }
  const { error: ratingError } = await supabase.from("tool_ratings").upsert(
    { tool_name: toolName, actor_key: actorKey, rating },
    { onConflict: "tool_name,actor_key" }
  );
  if (ratingError) return { success: false, error: ratingError.message };
  const { data: allRatings } = await supabase.from("tool_ratings").select("rating").eq("tool_name", toolName);
  if (allRatings && allRatings.length > 0) {
    const avg = allRatings.reduce((sum, r) => sum + r.rating, 0) / allRatings.length;
    await supabase.from("ai_tool_social").update({
      rating_average: Math.round(avg * 10) / 10,
      rating_count: allRatings.length
    }).eq("tool_name", toolName);
  }
  return { success: true };
}
async function reactToTool$1(toolName, actorKey, reactionType) {
  const { error } = await supabase.from("tool_reactions").upsert(
    { tool_name: toolName, actor_key: actorKey, reaction_type: reactionType },
    { onConflict: "tool_name,actor_key" }
  );
  if (error) return { success: false, error: error.message };
  return { success: true };
}
async function removeReaction(toolName, actorKey) {
  const { error } = await supabase.from("tool_reactions").delete().eq("tool_name", toolName).eq("actor_key", actorKey);
  if (error) return { success: false, error: error.message };
  return { success: true };
}
async function addComment(toolName, author, content) {
  const trimmed = content.trim();
  if (!trimmed) return { success: false, error: "Le commentaire est vide." };
  if (trimmed.length > 500) {
    return { success: false, error: "Le commentaire ne doit pas dépasser 500 caractères." };
  }
  const id = `comment-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const { data, error } = await supabase.from("tool_comments").insert({ id, tool_name: toolName, author, content: trimmed }).select().single();
  if (error) return { success: false, error: error.message };
  return { success: true, data };
}
async function reportTool$1(toolName) {
  var _a;
  const { data: current } = await supabase.from("ai_tool_social").select("reports").eq("tool_name", toolName).maybeSingle();
  if (!current) await getOrCreateToolSocial(toolName);
  const { error } = await supabase.from("ai_tool_social").update({ reports: ((_a = current == null ? void 0 : current.reports) != null ? _a : 0) + 1 }).eq("tool_name", toolName);
  if (error) return { success: false, error: error.message };
  return { success: true };
}
let toolSocialCache = {};
const toolSocialEventName = "octopus-market-tool-social-updated";
function emitUpdate() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent(toolSocialEventName));
  }
}
function readToolSocial(toolName) {
  var _a;
  return (_a = toolSocialCache[toolName]) != null ? _a : null;
}
async function rateToolByActor(toolName, actorKey, rating) {
  const result = await rateTooling(toolName, actorKey, rating);
  if (result.success) {
    const current = toolSocialCache[toolName];
    if (current) {
      const newRatings = { ...current.userRatings, [actorKey]: rating };
      const values = Object.values(newRatings);
      const avg = values.reduce((s, v) => s + v, 0) / values.length;
      toolSocialCache[toolName] = {
        ...current,
        userRatings: newRatings,
        ratingAverage: Math.round(avg * 10) / 10,
        ratingCount: values.length
      };
      emitUpdate();
    }
  }
  return result;
}
async function reactToToolByActor(toolName, actorKey, reactionType) {
  var _a, _b, _c;
  const current = toolSocialCache[toolName];
  const existingReaction = current == null ? void 0 : current.userReactions[actorKey];
  if (existingReaction === reactionType) {
    const result2 = await removeReaction(toolName, actorKey);
    if (result2.success && current) {
      const newUserReactions = { ...current.userReactions };
      delete newUserReactions[actorKey];
      toolSocialCache[toolName] = {
        ...current,
        userReactions: newUserReactions,
        reactions: {
          ...current.reactions,
          [reactionType]: Math.max(0, ((_a = current.reactions[reactionType]) != null ? _a : 0) - 1)
        }
      };
      emitUpdate();
    }
    return result2;
  }
  const result = await reactToTool$1(toolName, actorKey, reactionType);
  if (result.success && current) {
    const newUserReactions = { ...current.userReactions, [actorKey]: reactionType };
    const newReactions = { ...current.reactions };
    if (existingReaction) {
      newReactions[existingReaction] = Math.max(0, ((_b = newReactions[existingReaction]) != null ? _b : 0) - 1);
    }
    newReactions[reactionType] = ((_c = newReactions[reactionType]) != null ? _c : 0) + 1;
    toolSocialCache[toolName] = {
      ...current,
      userReactions: newUserReactions,
      reactions: newReactions
    };
    emitUpdate();
  }
  return result;
}
async function addToolComment(toolName, author, content) {
  const result = await addComment(toolName, author, content);
  if (result.success && result.data) {
    const current = toolSocialCache[toolName];
    if (current) {
      const newComment = {
        id: result.data.id,
        author: result.data.author,
        content: result.data.content,
        createdAt: new Date(result.data.created_at).getTime()
      };
      toolSocialCache[toolName] = {
        ...current,
        comments: [newComment, ...current.comments].slice(0, 50)
      };
      emitUpdate();
    }
  }
  return { success: result.success, error: result.error };
}
async function reportToolByActor(toolName) {
  const result = await reportTool$1(toolName);
  if (result.success) {
    const current = toolSocialCache[toolName];
    if (current) {
      toolSocialCache[toolName] = { ...current, reports: current.reports + 1 };
      emitUpdate();
    }
  }
  return result;
}
function subscribeToToolSocialStore(listener) {
  if (typeof window === "undefined") return () => void 0;
  window.addEventListener(toolSocialEventName, listener);
  return () => window.removeEventListener(toolSocialEventName, listener);
}
const getToolSocialRecord = readToolSocial;
const rateTool = rateToolByActor;
const reactToTool = reactToToolByActor;
const reportTool = reportToolByActor;
const commentOnTool = addToolComment;
const subscribeToToolSocialRecords = subscribeToToolSocialStore;
function formatMoment(timestamp) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(timestamp));
}
function AIToolSocialPanel({
  toolName,
  actorKey,
  actorLabel
}) {
  const [commentDraft, setCommentDraft] = reactExports.useState("");
  const [commentsVisible, setCommentsVisible] = reactExports.useState(false);
  const [refreshIndex, setRefreshIndex] = reactExports.useState(0);
  reactExports.useEffect(() => {
    return subscribeToToolSocialRecords(() => {
      setRefreshIndex((currentValue) => currentValue + 1);
    });
  }, []);
  const socialRecord = reactExports.useMemo(() => getToolSocialRecord(toolName), [refreshIndex, toolName]);
  const activeReaction = socialRecord.userReactions[actorKey];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 rounded-2xl border border-orange-100 bg-orange-50/80 p-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-n619u4-45-4", "data-component": "div", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:45:4:173:10", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3", "data-forge-id": "forge-n61akv-46-6", "data-component": "div", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:46:6:97:12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-1", "data-forge-id": "forge-n61bbm-47-8", "data-component": "div", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:47:8:64:14", children: [
        [1, 2, 3, 4, 5].map((rating) => /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => rateTool(toolName, actorKey, rating), className: "rounded-full p-1 text-orange-500 transition hover:scale-105 dark:text-orange-300", "aria-label": `Rate ${toolName} ${rating} stars`, "data-forge-id": "forge-7w1h39-49-12", "data-component": "button", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:49:12:57:21", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Star, { className: "size-4 fill-current", "data-forge-id": "forge-7wjcq3-56-14", "data-component": "Star", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:56:14:56:54" }) }, rating)),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-2 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-7wl9ok-59-10", "data-component": "span", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:59:10:63:17", children: socialRecord.ratingCount > 0 ? `${socialRecord.ratingAverage}/5 from ${socialRecord.ratingCount} ratings` : "No ratings yet" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", "data-forge-id": "forge-n62jta-65-8", "data-component": "div", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:65:8:96:14", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", variant: "outline", size: "sm", className: `rounded-full border-orange-200 bg-white text-zinc-800 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900 ${activeReaction === "heart" ? "ring-2 ring-red-300" : ""}`, onClick: () => reactToTool(toolName, actorKey, "heart"), "data-forge-id": "forge-7x35bc-66-10", "data-component": "Button", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:66:10:75:19", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Heart, { className: "size-4 text-red-500", "data-forge-id": "forge-7xl0y6-73-12", "data-component": "Heart", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:73:12:73:53" }),
          socialRecord.reactions.heart
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", variant: "outline", size: "sm", className: `rounded-full border-orange-200 bg-white text-zinc-800 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900 ${activeReaction === "thumbs-up" ? "ring-2 ring-sky-300" : ""}`, onClick: () => reactToTool(toolName, actorKey, "thumbs-up"), "data-forge-id": "forge-7xmxwp-76-10", "data-component": "Button", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:76:10:85:19", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ThumbsUp, { className: "size-4 text-sky-500", "data-forge-id": "forge-7y4tjj-83-12", "data-component": "ThumbsUp", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:83:12:83:56" }),
          socialRecord.reactions["thumbs-up"]
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", variant: "outline", size: "sm", className: `rounded-full border-orange-200 bg-white text-zinc-800 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900 ${activeReaction === "flame" ? "ring-2 ring-orange-300" : ""}`, onClick: () => reactToTool(toolName, actorKey, "flame"), "data-forge-id": "forge-7y6qi2-86-10", "data-component": "Button", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:86:10:95:19", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Flame, { className: "size-4 text-orange-500", "data-forge-id": "forge-7yom4w-93-12", "data-component": "Flame", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:93:12:93:56" }),
          socialRecord.reactions.flame
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-n64jql-99-6", "data-component": "div", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:99:6:101:12", children: "One reaction per user is stored for each AI card." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2", "data-forge-id": "forge-7u87gf-103-6", "data-component": "div", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:103:6:127:12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", variant: "outline", size: "sm", className: "rounded-full border-orange-200 bg-white text-zinc-800 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900", onClick: () => setCommentsVisible((currentValue) => !currentValue), "data-forge-id": "forge-7u8876-104-8", "data-component": "Button", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:104:8:113:17", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "size-4", "data-forge-id": "forge-ty8rqx-111-10", "data-component": "MessageSquare", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:111:10:111:46" }),
        commentsVisible ? "Hide comments" : "Show comments"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", variant: "outline", size: "sm", className: "rounded-full border-orange-200 bg-white text-zinc-800 hover:bg-orange-50 dark:border-white/10 dark:bg-zinc-950 dark:text-white dark:hover:bg-zinc-900", onClick: () => reportTool(toolName), "data-forge-id": "forge-7u8v6p-114-8", "data-component": "Button", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:114:8:123:17", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldAlert, { className: "size-4 text-orange-500", "data-forge-id": "forge-tyskca-121-10", "data-component": "ShieldAlert", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:121:10:121:60" }),
        "Report"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-7u9i68-124-8", "data-component": "span", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:124:8:126:15", children: [
        socialRecord.reports,
        " safety report",
        socialRecord.reports > 1 ? "s" : ""
      ] })
    ] }),
    commentsVisible ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 rounded-2xl border border-orange-100 bg-white p-3 dark:border-white/10 dark:bg-zinc-950/70", "data-forge-id": "forge-7ua26z-130-8", "data-component": "div", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:130:8:171:14", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", "data-forge-id": "forge-tzccxn-131-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:131:10:149:16", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: commentDraft, onChange: (event) => setCommentDraft(event.target.value), placeholder: "Share your opinion about this AI", className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-zinc-950 dark:text-white", "data-forge-id": "forge-tzczx8-132-12", "data-component": "Input", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:132:12:137:14" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", className: "rounded-xl bg-orange-500 text-white hover:bg-orange-400", onClick: () => {
          commentOnTool(toolName, actorLabel, commentDraft);
          setCommentDraft("");
        }, disabled: !commentDraft.trim(), "data-forge-id": "forge-tzgtue-138-12", "data-component": "Button", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:138:12:148:21", children: "Post" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-48 space-y-2 overflow-y-auto pr-1", "data-forge-id": "forge-u0fy4d-151-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:151:10:170:16", children: socialRecord.comments.length > 0 ? socialRecord.comments.map((comment) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border border-orange-100 bg-orange-50/80 px-3 py-3 text-sm dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-u0hv34-154-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:154:16:163:22", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-u0kf1a-158-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:158:18:161:24", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "data-forge-id": "forge-u0l21g-159-20", "data-component": "span", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:159:20:159:49", children: comment.author }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "data-forge-id": "forge-u0z3r2-160-20", "data-component": "span", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:160:20:160:66", children: formatMoment(comment.createdAt) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-zinc-700 dark:text-zinc-300", "data-forge-id": "forge-u10dph-162-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:162:18:162:92", children: comment.content })
      ] }, comment.id)) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-xl border border-dashed border-orange-200 bg-white px-3 py-3 text-sm text-zinc-500 dark:border-white/10 dark:bg-zinc-950/70 dark:text-zinc-400", "data-forge-id": "forge-u12xnh-166-14", "data-component": "div", "data-source-pos": "src/components/octopus-market/ai-tool-social-panel.tsx:166:14:168:20", children: "No comments yet." }) })
    ] }) : null
  ] });
}
export {
  AIToolSocialPanel
};
