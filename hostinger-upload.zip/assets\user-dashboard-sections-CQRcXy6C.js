import { r as reactExports, t as subscribeToAIListings, s as subscribeToCentralRegistry, q as subscribeToPredictionMarketStorage, a2 as readPredictionHistory, v as readAIListings, j as jsxRuntimeExports, C as Card, a as CardHeader, b as CardTitle, z as CardDescription, e as CardContent, d as Button, W as Wallet, B as Badge, i as readCentralPaymentRecords, a3 as claimPredictionEntry, y as toast } from "./index-C-7_nSR2.js";
import { O as OctopusAIListingDialog } from "./octopus-ai-listing-dialog-Cw8KzkBF.js";
import { C as Coins } from "./coins-Cw0iSkkx.js";
import "./alert-KqzOsNqQ.js";
import "./textarea-6tc707H_.js";
import "./solana-pay-PUUwvoir.js";
import "./index-CE1PewnY.js";
function formatCurrency(amount) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 2
  }).format(amount);
}
function formatMoment(timestamp) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(timestamp));
}
function UserDashboardSections({
  walletAddress,
  walletRecord,
  launchedTokens,
  onConnectWallet,
  visibleSections
}) {
  const [aiRefreshIndex, setAiRefreshIndex] = reactExports.useState(0);
  const [adminRefreshIndex, setAdminRefreshIndex] = reactExports.useState(0);
  const [claimingId, setClaimingId] = reactExports.useState(null);
  const [paymentRecords, setPaymentRecords] = reactExports.useState([]);
  const [betRecords, setBetRecords] = reactExports.useState([]);
  reactExports.useEffect(() => {
    return subscribeToAIListings(() => {
      setAiRefreshIndex((currentValue) => currentValue + 1);
    });
  }, []);
  reactExports.useEffect(() => {
    const loadPayments = () => {
      setPaymentRecords(readCentralPaymentRecords());
    };
    loadPayments();
    const unsubRegistry = subscribeToCentralRegistry(() => {
      loadPayments();
      setAdminRefreshIndex((currentValue) => currentValue + 1);
    });
    const unsubPrediction = subscribeToPredictionMarketStorage(() => {
      setBetRecords([...readPredictionHistory()]);
    });
    setBetRecords([...readPredictionHistory()]);
    return () => {
      unsubRegistry();
      unsubPrediction();
    };
  }, []);
  const predictionHistory = reactExports.useMemo(() => {
    if (!walletAddress) {
      return [];
    }
    return betRecords.filter((entry) => entry.walletAddress === walletAddress);
  }, [betRecords, walletAddress]);
  const paymentNotifications = reactExports.useMemo(() => paymentRecords, [paymentRecords, adminRefreshIndex]);
  const aiListings = reactExports.useMemo(() => {
    if (!walletAddress) {
      return [];
    }
    return readAIListings().filter((listing) => listing.walletAddress === walletAddress);
  }, [aiRefreshIndex, walletAddress]);
  const derivedHistory = reactExports.useMemo(() => predictionHistory.map((entry) => {
    var _a;
    const payment = paymentNotifications.find((item) => item.paymentReference === entry.paymentReference);
    const canClaim = Boolean(walletAddress) && walletAddress === entry.walletAddress && entry.resultStatus === "win" && !entry.claimedAt;
    return {
      ...entry,
      adminStatus: (_a = payment == null ? void 0 : payment.status) != null ? _a : "pending",
      statusLabel: entry.resultStatus === "paid" ? "Paid" : entry.resultStatus === "claimed" ? "Claimed" : entry.resultStatus === "win" ? "Win" : entry.resultStatus === "lose" ? "Lose" : entry.resultStatus === "rejected" ? "Rejected" : entry.resultStatus === "approved_pending_result" ? "Approved" : "Pending review",
      canClaim
    };
  }), [paymentNotifications, predictionHistory, walletAddress]);
  const totals = reactExports.useMemo(() => {
    return derivedHistory.reduce((summary, entry) => ({
      totalBets: summary.totalBets + entry.amount,
      totalWins: summary.totalWins + (entry.statusLabel === "Win" || entry.statusLabel === "Claimed" || entry.statusLabel === "Paid" ? entry.netReward : 0),
      totalLosses: summary.totalLosses + (entry.statusLabel === "Lose" ? entry.totalCharged : 0),
      claimable: summary.claimable + (entry.canClaim ? entry.netReward : 0)
    }), {
      totalBets: 0,
      totalWins: 0,
      totalLosses: 0,
      claimable: 0
    });
  }, [derivedHistory]);
  const allowedSections = reactExports.useMemo(() => {
    if (visibleSections && visibleSections.length > 0) {
      return visibleSections;
    }
    return ["wallet", "bets", "gains", "listed-ai", "token-launch"];
  }, [visibleSections]);
  const showSection = (sectionId) => allowedSections.includes(sectionId);
  const handleClaim = async (entryId) => {
    const targetEntry = derivedHistory.find((entry) => entry.id === entryId);
    if (!(targetEntry == null ? void 0 : targetEntry.canClaim)) {
      return;
    }
    try {
      setClaimingId(entryId);
      const claimReference = `CLAIM-${Date.now().toString(36).toUpperCase()}`;
      await claimPredictionEntry(entryId, claimReference);
      toast.success("Gain réclamé", {
        description: `${targetEntry.marketTitle} — en attente de paiement admin.`,
        duration: 5e3
      });
    } catch (e) {
      toast.error("Échec de la réclamation", {
        description: "Réessayez ou contactez l'admin."
      });
    } finally {
      setClaimingId(null);
    }
  };
  if (!walletAddress) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "py-20", "data-forge-id": "forge-iq9zuv-195-6", "data-component": "section", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:195:6:212:16", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8", "data-forge-id": "forge-iq9z44-196-8", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:196:8:211:14", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-white/5 dark:text-white", "data-forge-id": "forge-cdo5vq-197-10", "data-component": "Card", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:197:10:210:17", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-cdniw5-198-12", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:198:12:203:25", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-2xl", "data-forge-id": "forge-cdmvwk-199-14", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:199:14:199:100", children: "Connect your wallet to open your dashboard" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { "data-forge-id": "forge-c1p5qd-200-14", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:200:14:202:32", children: "My Bets, My Winnings, My Listed AI, and Wallet Dashboard become available after the wallet is connected." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { "data-forge-id": "forge-c1mlsb-204-12", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:204:12:209:26", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "rounded-2xl bg-orange-500 text-white hover:bg-orange-400", onClick: () => void onConnectWallet(), "data-forge-id": "forge-c1lysq-205-14", "data-component": "Button", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:205:14:208:23", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Wallet, { className: "size-4", "data-forge-id": "forge-c1lbt5-206-16", "data-component": "Wallet", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:206:16:206:45" }),
        "Connect wallet"
      ] }) })
    ] }) }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "border-y border-orange-100 bg-orange-50/70 py-20 dark:border-white/10 dark:bg-zinc-900/70", "data-forge-id": "forge-ipv9oe-217-4", "data-component": "section", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:217:4:472:14", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-7xl space-y-10 px-4 sm:px-6 lg:px-8", "data-forge-id": "forge-ipv8xn-218-6", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:218:6:471:12", children: [
    showSection("wallet") ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { id: "wallet-dashboard", className: "scroll-mt-28", "data-forge-id": "forge-c0lkjr-220-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:220:10:251:16", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-white/5 dark:text-white", "data-forge-id": "forge-c0kxk6-221-12", "data-component": "Card", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:221:12:250:19", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-c0kakl-222-14", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:222:14:235:27", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-3", "data-forge-id": "forge-c0jnl0-223-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:223:16:230:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-orange-100 text-orange-700 hover:bg-orange-100 dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-c0j0lf-224-18", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:224:18:226:26", children: "Wallet dashboard" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-white text-zinc-700 hover:bg-white dark:border-white/10 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-900", "data-forge-id": "forge-c0h3mu-227-18", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:227:18:229:26", children: (walletRecord == null ? void 0 : walletRecord.status) === "suspended" ? "Suspended" : "Active" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-2xl", "data-forge-id": "forge-c014yp-231-16", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:231:16:231:91", children: "Wallet profile and access state" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { "data-forge-id": "forge-c00hz6-232-16", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:232:16:234:34", children: "Your wallet identity, X profile, and current account status are tracked here after connection." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "grid gap-4 md:grid-cols-4", "data-forge-id": "forge-bzxy14-236-14", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:236:14:249:28", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 p-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-bzxb1j-237-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:237:16:240:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-bzwo1y-238-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:238:18:238:112", children: "Pseudo" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-bzw12f-239-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:239:18:239:152", children: (walletRecord == null ? void 0 : walletRecord.displayName) || (walletRecord == null ? void 0 : walletRecord.username) || "Unnamed" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 p-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-bzhcdc-241-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:241:16:244:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-bzgpdr-242-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:242:18:242:115", children: "X profile" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-bzg2e8-243-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:243:18:243:130", children: (walletRecord == null ? void 0 : walletRecord.twitterHandle) || "Not added" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 p-4 dark:border-white/10 dark:bg-black/20 md:col-span-2", "data-forge-id": "forge-bzesf8-245-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:245:16:248:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-bze5fn-246-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:246:18:246:119", children: "Solana wallet" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 break-all font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-bzdig4-247-18", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:247:18:247:111", children: walletAddress })
        ] })
      ] })
    ] }) }) : null,
    showSection("bets") ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { id: "my-bets", className: "scroll-mt-28", "data-forge-id": "forge-byuzu1-255-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:255:10:303:16", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-white/5 dark:text-white", "data-forge-id": "forge-byucug-256-12", "data-component": "Card", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:256:12:302:19", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-bytpuv-257-14", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:257:14:262:27", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-2xl", "data-forge-id": "forge-byt2va-258-16", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:258:16:258:67", children: "My Bets" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { "data-forge-id": "forge-bysfvr-259-16", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:259:16:261:34", children: "Review your payment history, selected side, odds, total charged amount, and deposit review status." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "space-y-4", "data-forge-id": "forge-bych7m-263-14", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:263:14:301:28", children: derivedHistory.length > 0 ? derivedHistory.map((entry) => {
        var _a, _b;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50/80 p-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-byak8a-266-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:266:20:294:26", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-3", "data-forge-id": "forge-by9x8p-267-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:267:22:283:28", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-by9a94-268-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:268:24:273:30", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-by8n9j-269-26", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:269:26:269:108", children: entry.marketTitle }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-bxuljx-270-26", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:270:26:272:30", children: [
                entry.categoryLabel,
                " · ",
                entry.selectionLabel,
                " · ",
                formatMoment(entry.createdAt)
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: entry.statusLabel === "Win" || entry.statusLabel === "Claimed" || entry.statusLabel === "Paid" ? "border border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-50 dark:border-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-300 dark:hover:bg-emerald-500/10" : entry.statusLabel === "Lose" || entry.statusLabel === "Rejected" ? "border border-red-200 bg-red-50 text-red-700 hover:bg-red-50 dark:border-red-500/20 dark:bg-red-500/10 dark:text-red-300 dark:hover:bg-red-500/10" : "border border-orange-200 bg-white text-orange-700 hover:bg-white dark:border-white/10 dark:bg-zinc-950 dark:text-orange-300 dark:hover:bg-zinc-950", "data-forge-id": "forge-bxs1lv-274-24", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:274:24:282:32", children: entry.statusLabel })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 grid gap-2 text-sm text-zinc-700 dark:text-zinc-300 sm:grid-cols-2 xl:grid-cols-4", "data-forge-id": "forge-bx890k-284-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:284:22:293:28", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-bx7m0z-285-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:285:24:285:77", children: [
              "Bet amount: ",
              formatCurrency(entry.amount)
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-bx6z1g-286-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:286:24:286:82", children: [
              "Reserve fee: ",
              formatCurrency(entry.reserveFee)
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-bx6c1x-287-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:287:24:287:83", children: [
              "Total paid: ",
              formatCurrency(entry.totalCharged)
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-bx5p2e-288-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:288:24:288:64", children: [
              "Odds: x",
              entry.payoutMultiple
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-bx522v-289-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:289:24:289:91", children: [
              "Admin decision: ",
              (_a = entry.adminDecisionStatus) != null ? _a : "pending"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-bwr0d9-290-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:290:24:290:76", children: [
              "Result from database: ",
              entry.statusLabel
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-bwqddq-291-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:291:24:291:119", children: [
              "Resolved at: ",
              entry.resolvedAt ? formatMoment(entry.resolvedAt) : "Awaiting result"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-bwpqe7-292-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:292:24:292:100", children: [
              "Winning choice: ",
              (_b = entry.winningChoiceLabel) != null ? _b : "Not a winning bet"
            ] })
          ] })
        ] }, entry.id);
      }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-dashed border-orange-200 bg-white p-4 text-sm text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-400", "data-forge-id": "forge-bwmjhb-297-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:297:18:299:24", children: "No bets recorded yet." }) })
    ] }) }) : null,
    showSection("gains") ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { id: "my-gains", className: "scroll-mt-28", "data-forge-id": "forge-bkj2fl-307-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:307:10:375:16", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-white/5 dark:text-white", "data-forge-id": "forge-bkifg0-308-12", "data-component": "Card", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:308:12:374:19", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-bkhsgf-309-14", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:309:14:314:27", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-2xl", "data-forge-id": "forge-bk3qqr-310-16", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:310:16:310:71", children: "My Winnings" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { "data-forge-id": "forge-bk33r8-311-16", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:311:16:313:34", children: "Follow your total wins, losses, claimable rewards, and claim actions after an admin-approved result." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "space-y-4", "data-forge-id": "forge-bk0jt6-315-14", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:315:14:373:28", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 md:grid-cols-4", "data-forge-id": "forge-bjzwtl-316-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:316:16:333:22", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 p-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-bjz9u0-317-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:317:18:320:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-bjymtu-318-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:318:20:318:124", children: "Total bet volume" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-xl font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-bjxzub-319-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:319:20:319:130", children: formatCurrency(totals.totalBets) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 p-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-bjjb5t-321-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:321:18:324:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-bjio5n-322-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:322:20:322:117", children: "Total win" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-xl font-semibold text-emerald-600 dark:text-emerald-300", "data-forge-id": "forge-bji164-323-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:323:20:323:139", children: formatCurrency(totals.totalWins) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 p-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-bjgr7p-325-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:325:18:328:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-bjg47j-326-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:326:20:326:118", children: "Total loss" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-xl font-semibold text-red-600 dark:text-red-300", "data-forge-id": "forge-bjfh80-327-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:327:20:327:133", children: formatCurrency(totals.totalLosses) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50 p-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-bje79l-329-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:329:18:332:24", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.16em] text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-bj05jc-330-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:330:20:330:121", children: "Claimable now" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-xl font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-bizijt-331-20", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:331:20:331:130", children: formatCurrency(totals.claimable) })
          ] })
        ] }),
        derivedHistory.filter((entry) => entry.canClaim || entry.claimedAt || entry.payoutStatus === "paid").length > 0 ? derivedHistory.filter((entry) => entry.canClaim || entry.claimedAt || entry.payoutStatus === "paid").map((entry) => {
          var _a, _b;
          return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-orange-100 bg-orange-50/80 p-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-biuenj-339-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:339:22:366:28", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-3", "data-forge-id": "forge-bigcxv-340-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:340:24:365:30", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-bifpya-341-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:341:26:346:32", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-bif2yp-342-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:342:28:342:110", children: entry.marketTitle }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-biefz6-343-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:343:28:345:32", children: [
                "Net reward ",
                formatCurrency(entry.netReward),
                " · Won on ",
                (_a = entry.winningChoiceLabel) != null ? _a : entry.selectionLabel,
                " · ",
                formatMoment((_b = entry.resolvedAt) != null ? _b : entry.createdAt)
              ] })
            ] }),
            entry.canClaim ? /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", className: "rounded-2xl bg-orange-500 text-white hover:bg-orange-400", disabled: claimingId === entry.id, onClick: () => void handleClaim(entry.id), "data-forge-id": "forge-bib91j-348-28", "data-component": "Button", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:348:28:355:37", children: claimingId === entry.id ? "Claiming..." : "Claim" }) : entry.payoutStatus === "paid" ? /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-emerald-300 bg-emerald-100 text-emerald-800 hover:bg-emerald-100 dark:border-emerald-500/30 dark:bg-emerald-500/20 dark:text-emerald-200 dark:hover:bg-emerald-500/20", "data-forge-id": "forge-bhs3fp-357-28", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:357:28:359:36", children: "Paid ✓" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-50 dark:border-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-300 dark:hover:bg-emerald-500/10", "data-forge-id": "forge-bhc4ri-361-28", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:361:28:363:36", children: "Claimed — pending payment" })
          ] }) }, entry.id);
        }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-dashed border-orange-200 bg-white p-4 text-sm text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-400", "data-forge-id": "forge-bh70w5-369-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:369:18:371:24", children: "No winnings are available yet." })
      ] })
    ] }) }) : null,
    showSection("listed-ai") ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { id: "my-listed-ai", className: "scroll-mt-28", "data-forge-id": "forge-bgn8b0-379-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:379:10:433:16", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-white/5 dark:text-white", "data-forge-id": "forge-bg96lc-380-12", "data-component": "Card", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:380:12:432:19", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardHeader, { "data-forge-id": "forge-bg8jlr-381-14", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:381:14:396:27", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center justify-between gap-3", "data-forge-id": "forge-bg7wm6-382-16", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:382:16:395:22", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-bg79ml-383-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:383:18:388:24", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-2xl", "data-forge-id": "forge-bg6mmf-384-20", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:384:20:384:76", children: "My Listed AI" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { "data-forge-id": "forge-bg5zmw-385-20", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:385:20:387:38", children: "Review your submitted AI products and start a new submission if you have not listed one yet." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(OctopusAIListingDialog, { walletAddress, walletRecord, onConnectWallet, triggerLabel: "List my AI", "data-forge-id": "forge-bg3fpf-389-18", "data-component": "OctopusAIListingDialog", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:389:18:394:20" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "space-y-4", "data-forge-id": "forge-bfkx38-397-14", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:397:14:431:28", children: aiListings.length > 0 ? aiListings.map((listing) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-orange-100 bg-orange-50/80 p-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-b3lwx8-400-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:400:20:424:26", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-3", "data-forge-id": "forge-b3l9xn-401-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:401:22:417:28", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", "data-forge-id": "forge-b3kmy2-402-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:402:24:408:30", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: listing.iconSrc, alt: listing.displayName, className: "size-12 rounded-2xl object-cover", "data-forge-id": "forge-b3jzyh-403-26", "data-component": "img", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:403:26:403:126" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-b3jcyy-404-26", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:404:26:407:32", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-b3ipzd-405-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:405:28:405:112", children: listing.displayName }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-b3i2zu-406-28", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:406:28:406:116", children: listing.twitterHandle })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2", "data-forge-id": "forge-b3g61d-409-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:409:24:416:30", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-white text-orange-700 hover:bg-white dark:border-white/10 dark:bg-zinc-950 dark:text-orange-300 dark:hover:bg-zinc-950", "data-forge-id": "forge-b324bp-410-26", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:410:26:412:34", children: listing.planId }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Badge, { className: "border border-orange-200 bg-orange-100 text-orange-700 hover:bg-orange-100 dark:border-orange-400/20 dark:bg-orange-500/15 dark:text-orange-300 dark:hover:bg-orange-500/15", "data-forge-id": "forge-b307d4-413-26", "data-component": "Badge", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:413:26:415:34", children: listing.status })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 grid gap-2 text-sm text-zinc-700 dark:text-zinc-300 sm:grid-cols-2 xl:grid-cols-4", "data-forge-id": "forge-b2x0fl-418-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:418:22:423:28", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-b2wdg0-419-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:419:24:419:66", children: [
            "Billing: ",
            listing.billingLabel
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-b2ibqe-420-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:420:24:420:67", children: [
            "Visitors: ",
            listing.visitorCount
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-b2hoqv-421-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:421:24:421:98", children: [
            "Auto renew: ",
            listing.autoRenewEnabled ? "Enabled" : "Disabled"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-b2h1rc-422-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:422:24:422:99", children: [
            "Visible in Explore AI: ",
            listing.visibleInExplore ? "Yes" : "No"
          ] })
        ] })
      ] }, listing.id)) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-dashed border-orange-200 bg-white p-4 text-sm text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-400", "data-forge-id": "forge-b2duug-427-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:427:18:429:24", children: "No AI submitted yet. Use the button above to start Step 1 and Step 2 of the listing flow." }) })
    ] }) }) : null,
    showSection("token-launch") ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { id: "my-token-launch", className: "scroll-mt-28", "data-forge-id": "forge-b1u29b-437-10", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:437:10:469:16", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-orange-200 bg-white text-zinc-950 dark:border-white/10 dark:bg-white/5 dark:text-white", "data-forge-id": "forge-b1tf9q-438-12", "data-component": "Card", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:438:12:468:19", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { "data-forge-id": "forge-b1ssa5-439-14", "data-component": "CardHeader", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:439:14:444:27", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardTitle, { className: "text-2xl", "data-forge-id": "forge-b1eqkh-440-16", "data-component": "CardTitle", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:440:16:440:77", children: "My Token Launches" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CardDescription, { "data-forge-id": "forge-b1e3ky-441-16", "data-component": "CardDescription", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:441:16:443:34", children: "Tokens launched from this wallet appear here with their logo and token name." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "space-y-4", "data-forge-id": "forge-b1bjmw-445-14", "data-component": "CardContent", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:445:14:467:28", children: launchedTokens.length > 0 ? launchedTokens.map((token) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 rounded-2xl border border-orange-100 bg-orange-50/80 p-4 dark:border-white/10 dark:bg-black/20", "data-forge-id": "forge-b19mnk-448-20", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:448:20:460:26", children: [
        token.logoSrc ? /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: token.logoSrc, alt: token.name, className: "size-10 rounded-full object-cover", "data-forge-id": "forge-b0uxyb-450-24", "data-component": "img", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:450:24:450:114" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex size-10 items-center justify-center rounded-full bg-orange-100 text-orange-600 dark:bg-orange-500/10 dark:text-orange-300", "data-forge-id": "forge-b0tnz9-452-24", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:452:24:454:30", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Coins, { className: "size-4", "data-forge-id": "forge-b0t0zo-453-26", "data-component": "Coins", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:453:26:453:54" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { "data-forge-id": "forge-b0r417-456-22", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:456:22:459:28", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-zinc-950 dark:text-white", "data-forge-id": "forge-b0qh1m-457-24", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:457:24:457:99", children: token.name }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-zinc-500 dark:text-zinc-400", "data-forge-id": "forge-b0pu23-458-24", "data-component": "p", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:458:24:458:103", children: token.ticker })
        ] })
      ] }, token.id)) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border border-dashed border-orange-200 bg-white p-4 text-sm text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-400", "data-forge-id": "forge-b098f4-463-18", "data-component": "div", "data-source-pos": "src/components/octopus-market/user-dashboard-sections.tsx:463:18:465:24", children: "No token launch recorded yet." }) })
    ] }) }) : null
  ] }) });
}
export {
  UserDashboardSections
};
